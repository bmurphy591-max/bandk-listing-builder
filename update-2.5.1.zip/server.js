/**
 * B and K Watches — AI Listing Builder v2 (local server)
 *
 * Pipeline per watch: photos -> Claude vision -> eBay comps (price) -> RESEARCH (web search + other sellers' item specifics + eBay taxonomy)
 *                      -> title/description with the B&K guarantee -> review/approve -> publish
 * Batch queue: many watches -> drafts processed in the background -> review/approve -> publish approved
 * Photos are uploaded to eBay Picture Services automatically (Media API) — no pasted URLs needed.
 *
 * Runs on localhost; keys stay in .env on your machine.
 */
require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileP = promisify(execFile);

const app = express();
const extras = require('./extras');
extras.install(app, { draftLabel: (id) => { const d = readDraft(id); return d ? (d.title || d.analysis?.suggestedTitle || id) : id + ' (deleted)'; } });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 30 * 1024 * 1024, files: 8 } });
app.use(express.json({ limit: '25mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const {
  ANTHROPIC_API_KEY,
  ANTHROPIC_MODEL = 'claude-sonnet-5-5',
  ANTHROPIC_BASE_URL = 'https://api.anthropic.com',
  EBAY_CLIENT_ID,
  EBAY_CLIENT_SECRET,
  EBAY_REFRESH_TOKEN,          // user token w/ sell.inventory scope (see README)
  EBAY_ENV = 'SANDBOX',        // SANDBOX | PRODUCTION
  EBAY_FULFILLMENT_POLICY_ID,
  EBAY_PAYMENT_POLICY_ID,
  EBAY_RETURN_POLICY_ID,
  EBAY_MERCHANT_LOCATION_KEY = 'BANDK-BOISE',
  BATCH_CONCURRENCY = '2',
} = process.env;

const NO_PUBLISH = process.env.NO_PUBLISH === '1'; // test launcher: real AI, publishing hard-disabled
const IS_PROD = EBAY_ENV === 'PRODUCTION';
const EBAY_BASE = process.env.EBAY_API_BASE || (IS_PROD ? 'https://api.ebay.com' : 'https://api.sandbox.ebay.com');
// Media API (picture upload) lives on the "apim" host. Sandbox host is not confirmed in eBay's docs — override with EBAY_MEDIA_BASE if needed.
const EBAY_MEDIA_BASE = process.env.EBAY_MEDIA_BASE || (IS_PROD ? 'https://apim.ebay.com' : 'https://apim.sandbox.ebay.com');
const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), 'BandKListingData');
const DRAFTS_DIR = path.join(DATA_DIR, 'drafts');
const reference = require('./reference');
const REF_DIRS = [path.join(__dirname, 'reference'), path.join(DATA_DIR, 'reference')]; // drop eBay listing-report CSVs here
fs.mkdirSync(DRAFTS_DIR, { recursive: true });

/* ------------------------------------------------------------------ */
/* B and K store conventions — derived from your active-listings CSV   */
/* ------------------------------------------------------------------ */
const STORE_DEFAULTS = {
  categoryId: '31387',                    // Wristwatches — 1,297 of your 1,321 listings
  format: 'FIXED_PRICE',
  currency: 'USD',
  conditionDefault: 'Pre-owned - Good',   // your dominant grade (1,089 listings)
  conditionMap: {                         // eBay Inventory API condition enums
    'Pre-owned - Excellent': { condition: 'USED_EXCELLENT' },
    'Pre-owned - Good':      { condition: 'USED_GOOD' },
    'Pre-owned - Fair':      { condition: 'USED_ACCEPTABLE' },
    'For parts or not working': { condition: 'FOR_PARTS_OR_NOT_WORKING' },
    'New with box and papers':    { condition: 'NEW' },
    'New without box or papers':  { condition: 'NEW_OTHER' },
  },
  titleTemplate: '{Brand} {Model} {Decade\'s if vintage, e.g. 1990\'s} {Gender} Watch {Colors} {one standout feature, e.g. Fluted Bezel / Date / Dive} {Reference # if known} New Battery',
  titleMaxLen: 80,
  batteryPhrase: 'New Battery',           // present on 94% of your titles — your brand promise
  genderTerms: { M: 'Mens', F: 'Womens', U: 'Unisex' }, // no apostrophes, per title standardization
};

/* ------------------------------------------------------------------ */
/* Image helpers                                                       */
/* ------------------------------------------------------------------ */
function sniffMime(b) {
  if (b.length > 12) {
    if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
    if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'image/png';
    if (b.slice(0, 4).toString() === 'GIF8') return 'image/gif';
    if (b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') return 'image/webp';
    if (b.slice(4, 8).toString() === 'ftyp' && /heic|heix|hevc|mif1|msf1/.test(b.slice(8, 12).toString())) return 'image/heic';
  }
  return null;
}

/** Normalize any upload to a JPEG <= 1600px (macOS `sips`, built in). HEIC from iPhone/iPad is converted here. */
async function normalizeImage(buf) {
  const mime = sniffMime(buf);
  if (process.platform === 'darwin') {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-img-'));
    try {
      const inP = path.join(dir, 'in');
      const outP = path.join(dir, 'out.jpg');
      fs.writeFileSync(inP, buf);
      await execFileP('sips', ['-s', 'format', 'jpeg', '-s', 'formatOptions', '85', '-Z', '1600', inP, '--out', outP]);
      return { buffer: fs.readFileSync(outP), mime: 'image/jpeg' };
    } catch (e) {
      if (mime === 'image/jpeg') return { buffer: buf, mime }; // sips failed but it's already a JPEG
      throw new Error(`Could not convert this photo (${mime || 'unknown format'}). Try exporting it as JPEG.`);
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  }
  // Non-macOS: no converter available — accept formats Claude and eBay both take.
  if (mime === 'image/jpeg' || mime === 'image/png' || mime === 'image/webp') return { buffer: buf, mime };
  throw new Error(`Unsupported photo format (${mime || 'unknown'}). Use JPEG or PNG.`);
}
const extFor = (mime) => ({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }[mime] || 'jpg');

/* ------------------------------------------------------------------ */
/* eBay OAuth helpers                                                  */
/* ------------------------------------------------------------------ */
let appTokenCache = { token: null, exp: 0 };
async function getAppToken() { // client-credentials token — Browse API (comps)
  if (!EBAY_CLIENT_ID || !EBAY_CLIENT_SECRET) throw new Error('EBAY_CLIENT_ID / EBAY_CLIENT_SECRET not set in .env');
  if (appTokenCache.token && Date.now() < appTokenCache.exp - 60000) return appTokenCache.token;
  const res = await fetch(`${EBAY_BASE}/identity/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: 'Basic ' + Buffer.from(`${EBAY_CLIENT_ID}:${EBAY_CLIENT_SECRET}`).toString('base64'),
    },
    body: 'grant_type=client_credentials&scope=' + encodeURIComponent('https://api.ebay.com/oauth/api_scope'),
  });
  const data = await res.json();
  if (!data.access_token) throw new Error('eBay app token failed: ' + JSON.stringify(data));
  appTokenCache = { token: data.access_token, exp: Date.now() + data.expires_in * 1000 };
  return appTokenCache.token;
}

/* ---- eBay account connection: RuName + saved refresh token + chosen business policies ---- */
const EBAY_SETTINGS_FILE = process.env.EBAY_SETTINGS_FILE || path.join(__dirname, 'ebay-settings.json');   // not secret: RuName, chosen policy IDs
const EBAY_TOKEN_FILE = process.env.EBAY_TOKEN_FILE || path.join(__dirname, '.ebay-token.json');        // secret: your sign-in token (never shared, never zipped)
const readJsonFile = (f, def) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return def; } };
const ebaySettings = () => ({ runame: '', fulfillmentPolicyId: '', paymentPolicyId: '', returnPolicyId: '', merchantLocationKey: '', ...readJsonFile(EBAY_SETTINGS_FILE, {}) });
const ebayRefreshToken = () => EBAY_REFRESH_TOKEN || readJsonFile(EBAY_TOKEN_FILE, {}).refresh_token || '';
const ebayPolicies = () => { const st = ebaySettings(); return { fulfillment: EBAY_FULFILLMENT_POLICY_ID || st.fulfillmentPolicyId, payment: EBAY_PAYMENT_POLICY_ID || st.paymentPolicyId, returns: EBAY_RETURN_POLICY_ID || st.returnPolicyId }; };
const ebayLocationKey = () => ebaySettings().merchantLocationKey || EBAY_MERCHANT_LOCATION_KEY;
const EBAY_AUTH_BASE = process.env.EBAY_AUTH_BASE || (IS_PROD ? 'https://auth.ebay.com' : 'https://auth.sandbox.ebay.com');
const EBAY_USER_SCOPES = ['https://api.ebay.com/oauth/api_scope/sell.inventory', 'https://api.ebay.com/oauth/api_scope/sell.account'];
const ebayBasic = () => 'Basic ' + Buffer.from(`${EBAY_CLIENT_ID}:${EBAY_CLIENT_SECRET}`).toString('base64');

let userTokenCache = { token: null, exp: 0 };
async function getUserToken() { // refresh-token exchange — Sell/Inventory + Media API (publishing, photo upload)
  const refresh = ebayRefreshToken();
  if (!refresh) throw new Error('eBay account not connected yet — open the "eBay connection" page and press Connect.');
  if (userTokenCache.token && Date.now() < userTokenCache.exp - 60000) return userTokenCache.token;
  const res = await fetch(`${EBAY_BASE}/identity/v1/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Authorization: ebayBasic() },
    body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: refresh, scope: EBAY_USER_SCOPES.join(' ') }),
  });
  const data = await res.json();
  if (!data.access_token) throw new Error('eBay user token failed: ' + JSON.stringify(data));
  userTokenCache = { token: data.access_token, exp: Date.now() + data.expires_in * 1000 };
  return userTokenCache.token;
}
/** Trade the one-time code from eBay's consent page for a long-lived refresh token and save it. */
async function exchangeEbayCode(code) {
  const st = ebaySettings();
  if (!EBAY_CLIENT_ID || !EBAY_CLIENT_SECRET) throw new Error('EBAY_CLIENT_ID / EBAY_CLIENT_SECRET are not set in .env');
  if (!st.runame) throw new Error('RuName missing — set it in ebay-settings.json');
  const res = await fetch(`${EBAY_BASE}/identity/v1/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Authorization: ebayBasic() },
    body: new URLSearchParams({ grant_type: 'authorization_code', code, redirect_uri: st.runame }),
  });
  const data = await res.json();
  if (!data.refresh_token) throw new Error('eBay did not accept the code: ' + (data.error_description || JSON.stringify(data)).slice(0, 300));
  fs.writeFileSync(EBAY_TOKEN_FILE, JSON.stringify({ refresh_token: data.refresh_token, saved: new Date().toISOString(), env: EBAY_ENV, refresh_expires_in: data.refresh_token_expires_in || null }), { mode: 0o600 });
  userTokenCache = { token: data.access_token, exp: Date.now() + (data.expires_in || 7200) * 1000 };
  return true;
}
async function ebayUserGet(pathname) {
  const token = await getUserToken();
  const r = await fetch(`${EBAY_BASE}${pathname}`, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Language': 'en-US', 'Accept-Language': 'en-US' } });
  const text = await r.text();
  let j = null; try { j = JSON.parse(text); } catch { /* not json */ }
  if (!r.ok) { const e0 = j?.errors?.[0]; throw new Error(`${r.status} ${e0 ? [e0.errorId && ('errorId ' + e0.errorId), e0.message, e0.longMessage, (e0.parameters || []).map((q) => q.name + '=' + q.value).join(', ')].filter(Boolean).join(' | ') : text.slice(0, 300)}`); }
  return j;
}

/* ------------------------------------------------------------------ */
/* Titles                                                              */
/* ------------------------------------------------------------------ */
/** Enforce store conventions: no apostrophes (Mens/Womens), <= 80 chars, battery/capacitor suffix matches the movement. */
function cleanTitle(t, movement) {
  t = String(t || '')
    .replace(/\bMen['’]s\b/gi, 'Mens')
    .replace(/\bWomen['’]s\b/gi, 'Womens')
    .replace(/\s+/g, ' ')
    .trim();
  const m = t.match(/\s(New Battery|New Capacitor)$/i);
  let suffix = m ? m[1] : '';
  const body = m ? t.slice(0, t.length - m[0].length) : t;
  const want = { Quartz: 'New Battery', Digital: 'New Battery', Kinetic: 'New Capacitor' }[movement];
  if (want) suffix = want;
  else if (movement === 'Automatic' || movement === 'Manual Wind') suffix = '';
  const words = body.split(' ');
  const total = () => words.join(' ').length + (suffix ? suffix.length + 1 : 0);
  while (words.length > 1 && total() > STORE_DEFAULTS.titleMaxLen) words.pop();
  return (words.join(' ') + (suffix ? ' ' + suffix : '')).trim();
}

/** Make sure a model/reference number the owner typed appears in the title (before the New Battery suffix). */
function ensureInTitle(t, token, movement) {
  token = String(token || '').trim(); t = cleanTitle(t, movement);
  const n = (x) => String(x).toLowerCase().replace(/[^a-z0-9]+/g, '');
  if (!token || n(t).includes(n(token))) return t;
  const m = t.match(/\s(New Battery|New Capacitor)$/i), suffix = m ? m[1] : '';
  const body = (m ? t.slice(0, t.length - m[0].length) : t).split(' ');
  const len = () => body.join(' ').length + 1 + token.length + (suffix ? suffix.length + 1 : 0);
  while (body.length > 2 && len() > STORE_DEFAULTS.titleMaxLen) body.pop();
  return cleanTitle(body.join(' ') + ' ' + token + (suffix ? ' ' + suffix : ''), movement);
}

/* ------------------------------------------------------------------ */
/* Claude                                                              */
/* ------------------------------------------------------------------ */
async function callClaude(content, maxTokens, opts = {}) {
  const raw = await callClaudeRaw(content, maxTokens, opts);
  return raw.text;
}
async function callClaudeRaw(content, maxTokens, opts = {}) {
  if (!ANTHROPIC_API_KEY) throw new Error('ANTHROPIC_API_KEY not set in .env');
  const body = { model: ANTHROPIC_MODEL, max_tokens: maxTokens, messages: [{ role: 'user', content }] };
  if (opts.tools) body.tools = opts.tools;
  const r = await fetch(`${ANTHROPIC_BASE_URL}/v1/messages`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify(body),
  });
  const data = await r.json();
  if (data.error) throw new Error('Anthropic API: ' + (data.error.message || JSON.stringify(data.error)));
  extras.recordUsage(ANTHROPIC_MODEL, data.usage);
  const blocks = data.content || [];
  const text = blocks.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
  const urls = [];
  for (const b of blocks) {
    if (b.type === 'web_search_tool_result' && Array.isArray(b.content)) {
      for (const x of b.content) if (x.url) urls.push({ url: x.url, title: x.title || x.url });
    }
  }
  return { text, urls, stop: data.stop_reason || '' };
}
function parseJsonLoose(text) {
  const fence = text.match(/```json\s*([\s\S]*?)```/i);
  const src = fence ? fence[1] : (text.match(/\{[\s\S]*\}/) || [])[0];
  if (!src) throw new Error('AI did not return JSON');
  return JSON.parse(src);
}

async function analyzeImages(images, hint = {}) { // images: [{buffer, mime}]; hint = owner-typed {model, modelNumber}
  if (!images.length) throw new Error('No photos uploaded');
  const content = images.map((im) => ({
    type: 'image',
    source: { type: 'base64', media_type: im.mime, data: im.buffer.toString('base64') },
  }));
  const prompt = `You are cataloging a pre-owned watch for the eBay store "B and K Watches".
Analyze the photo(s) and return ONLY a JSON object (no markdown fences, no prose) with:
{
  "brand": "", "model": "", "modelNumber": "", "gender": "Mens|Womens|Unisex",
  "movement": "Quartz|Automatic|Manual Wind|Kinetic|Solar|Digital|Unknown",
  "caseSizeMm": null, "caseMaterial": "", "caseColor": "", "dialColor": "",
  "bandType": "", "bandMaterial": "", "bandColor": "",
  "features": [], "style": "", "vintage": true/false,
  "conditionNotes": "", "visibleFlaws": [],
  "confidence": { "brand": 0-1, "model": 0-1, "caseSizeMm": 0-1 },
  "featuresInferred": [],
  "observed": {
    "Bezel Type": "Fixed|Fluted|Rotating|Unidirectional Rotating|Tachymeter|None", "Bezel Color": "",
    "Indices": "Arabic Numerals|Roman Numerals|Stick Indexes|Dots|No Numerals|Mixed (comma list ok, e.g. Roman Numerals, Stick Indexes)", "Closure": "Buckle|Deployant|Deployment Buckle|Jubilee|Expansion|Clasp|Slide|None",
    "Caseback": "Screwback|Snap|Exhibition|Unknown", "Case Finish": "Polished|Brushed|Polished & Brushed|Coated",
    "Band/Strap": "Two-Piece Strap|Bracelet|Expansion|NATO|One-Piece", "Watch Shape": "Round|Square|Rectangle|Tonneau|Oval",
    "Display": "Analog|Digital|Analog & Digital", "Band Width": null, "Crystal": ""
  },
  "suggestedTitle": ""
}
Include a key in "observed" ONLY when it is clearly visible in the photos; otherwise leave it out. Band Width only if measurable. Features = ONLY features you can clearly see in the photos or read printed on the watch (dial, case, buttons, caseback). Do NOT infer features from the watch type or from guesses about what a model usually does. Put anything you are only inferring in "featuresInferred" instead. Use eBay wording, e.g. 12-Hour Dial, Central Second, Date Indicator, Luminous Hands, Luminous Indexes, Push/Pull Crown, Rotating Bezel, Fixed Bezel, Seconds Hand, Water-Resistant, Chronograph. Style = several eBay style terms, e.g. Casual, Classic, Diver, Sport, Standard/Classic. Bezel Color and Indices may list several values, e.g. "Bronze, Silver" / "Arrow Markers, Round Indexes".
Model: only a model NAME actually printed on the watch or case. If only a reference number is printed, leave "model" empty and put the number in modelNumber. Never describe the watch in the model field (e.g. not "Sport Digital Chronograph").
Title rules: max 80 chars; template "${STORE_DEFAULTS.titleTemplate}"; use Mens/Womens (no apostrophe);
end with "New Battery" for quartz, "New Capacitor" for Kinetic, omit for mechanical.
If model number is not legible, leave modelNumber empty — NEVER guess model numbers or case sizes;
set caseSizeMm null unless measurable against a visible reference. List every visible flaw honestly.
The first photo is the main (front/dial) photo; later photos show caseback, band/clasp, or flaws.${(hint.brand || hint.model || hint.modelNumber) ? `\nOWNER-SUPPLIED (treat as correct, put them in the brand / model / modelNumber fields with confidence 1, use the brand in suggestedTitle and include the model number in suggestedTitle): ${[hint.brand ? `brand "${hint.brand}"` : '', hint.model ? `model name "${hint.model}"` : '', hint.modelNumber ? `model number "${hint.modelNumber}"` : ''].filter(Boolean).join(', ')}. Still describe everything else from the photos.` : ''}`;
  let analysis, lastErr;
  for (let attempt = 0; attempt < 2 && !analysis; attempt++) {
    const r = await callClaudeRaw([...content, { type: 'text', text: prompt + (attempt ? '\n\nIMPORTANT: your last reply was not valid JSON. Reply with ONE JSON object only, starting with { and ending with }. If something is unclear, leave that field empty or null — still return the JSON.' : '') }], 3000);
    const m = r.text.match(/\{[\s\S]*\}/);
    if (!m) { lastErr = new Error(`AI did not return JSON (stop: ${r.stop || 'n/a'}). AI said: "${(r.text || '(empty reply)').replace(/\s+/g, ' ').slice(0, 300)}"`); continue; }
    try { analysis = JSON.parse(m[0]); } catch (e) { lastErr = new Error(`AI returned broken JSON (stop: ${r.stop || 'n/a'}): ${e.message}`); }
  }
  if (!analysis) throw lastErr;
  analysis.confidence = analysis.confidence || {};
  analysis.observed = analysis.observed || {};
  for (const k of Object.keys(analysis.observed)) if (!analysis.observed[k]) delete analysis.observed[k];
  if (hint.brand) { analysis.brand = hint.brand; analysis.confidence.brand = 1; }
  if (hint.model) { analysis.model = hint.model; analysis.confidence.model = 1; }
  if (hint.modelNumber) { analysis.modelNumber = hint.modelNumber; analysis.confidence.modelNumber = 1; }
  analysis.suggestedTitle = cleanTitle(analysis.suggestedTitle, analysis.movement);
  if (hint.modelNumber) analysis.suggestedTitle = ensureInTitle(analysis.suggestedTitle, hint.modelNumber, analysis.movement);
  return analysis;
}

/* ------------------------------------------------------------------ */
/* Item specifics + research                                           */
/*  Sources, strongest first:  you > photo > web (manufacturer/spec    */
/*  pages found by Claude web search) > eBay comps (what other sellers */
/*  filled in for the same reference). Everything carries its source.  */
/* ------------------------------------------------------------------ */
const MULTI = new Set(['Features', 'Style']);
/** Item specifics the app never fills by itself (you can still type them): Crystal and Seller Notes stay blank. */
const BLANK_SPECS = new Set(['Crystal', 'Seller Notes']);
const SPEC_ORDER = [ // names exactly as they appear on your live listings
  'Brand', 'Model', 'Reference Number', 'Type', 'Department', 'Movement', 'Year Manufactured', 'Country of Origin', 'Display', 'Watch Shape',
  'Case Material', 'Case Color', 'Case Size', 'Case Thickness', 'Case Finish', 'Caseback', 'Lug Width', 'Crystal',
  'Dial Color', 'Indices', 'Bezel Type', 'Bezel Color',
  'Band/Strap', 'Band Material', 'Band Color', 'Band Width', 'Closure', 'Max Wrist Size',
  'Water Resistance', 'Features', 'Style', 'Number of Jewels', 'Vintage',
  'Seller Notes', 'Seller Warranty', 'With Papers', 'With Original Box/Packaging', 'With Manual/Booklet', 'With Service Records', 'Handmade', 'Customized',
];
const RESEARCH_FIELDS = ['Reference Number', 'Year Manufactured', 'Country of Origin', 'Display', 'Case Size', 'Case Thickness',
  'Case Finish', 'Caseback', 'Lug Width', 'Crystal', 'Indices', 'Bezel Type', 'Bezel Color', 'Band Width', 'Closure',
  'Max Wrist Size', 'Water Resistance', 'Features', 'Style', 'Number of Jewels', 'Watch Shape', 'Band/Strap'];
const norm = (v) => String(v).toLowerCase().replace(/[^a-z0-9.]+/g, ' ').trim();
const htmlToText = (h) => String(h).replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<br\s*\/?>|<\/p>|<\/div>|<\/li>/gi, '\n').replace(/<[^>]+>/g, ' ')
  .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"')
  .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
const wordsOf = (t) => String(t).toLowerCase().replace(/[^a-z0-9' ]+/g, ' ').split(/\s+/).filter(Boolean);
/** True if `text` shares any run of `n` consecutive words with one of the reference texts (copy guard). */
function copiesRef(text, refs, n = 7) {
  const grams = new Set();
  for (const r of refs) { const w = wordsOf(r.text); for (let i = 0; i + n <= w.length; i++) grams.add(w.slice(i, i + n).join(' ')); }
  const w = wordsOf(text);
  for (let i = 0; i + n <= w.length; i++) if (grams.has(w.slice(i, i + n).join(' '))) return w.slice(i, i + n).join(' ');
  return null;
}
const splitMulti = (v) => String(v).split(/\s*[,;]\s*/).filter(Boolean);

/** Other sellers' item specifics for the SAME reference: read the full listings of the closest comps and take the consensus. */
async function compSpecs(a, active) {
  const key = String(a.modelNumber || a.model || '').toLowerCase();
  if (!key || key.length < 3) return null;
  const pool = (active || []).filter((i) => i.itemId && i.title.toLowerCase().includes(key)).slice(0, 6);
  if (!pool.length) return null;
  const token = await getAppToken();
  const H = { Authorization: `Bearer ${token}`, 'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US' };
  const votes = {};
  const refDescs = [];
  let read = 0;
  for (const it of pool) {
    try {
      const r = await fetch(`${EBAY_BASE}/buy/browse/v1/item/${encodeURIComponent(it.itemId)}`, { headers: H });
      if (!r.ok) continue;
      const j = await r.json();
      read++;
      const txt = htmlToText(j.description || '').slice(0, 1500);
      if (txt.length > 80) refDescs.push({ title: it.title, url: it.url, text: txt });
      for (const { name, value } of j.localizedAspects || []) {
        if (!RESEARCH_FIELDS.includes(name) || !value) continue;
        const v = votes[name] || (votes[name] = {});
        const k = norm(value);
        (v[k] = v[k] || { value, n: 0 }).n++;
      }
    } catch { /* skip this listing */ }
  }
  const specs = {};
  for (const [name, v] of Object.entries(votes)) {
    const best = Object.values(v).sort((x, y) => y.n - x.n)[0];
    specs[name] = { value: best.value, n: best.n, of: read };
  }
  return { specs, read, refDescs, urls: pool.map((p) => ({ url: p.url, title: p.title })) };
}

/** Manufacturer / reference-site lookup using Claude's web search tool. Must cite a page for every value. */
async function webResearch(a) {
  if (!a.brand || !(a.modelNumber || a.model)) return null;
  const prompt = `RESEARCH TASK. Find factual specifications for this exact pre-owned watch so an eBay listing can be filled in accurately.
Watch: ${[a.brand, a.model, a.modelNumber && `reference/caliber ${a.modelNumber}`, a.gender, a.movement, a.dialColor && `${a.dialColor} dial`].filter(Boolean).join(', ')}
Use web search (manufacturer pages, catalogs, watch databases, spec sheets). Look for these fields only: ${RESEARCH_FIELDS.join(', ')}.
Rules:
- Include a field ONLY if a page you retrieved states it for this exact brand and reference. If unsure, or if the page is about a different variant, OMIT it. Never guess or fill from general knowledge.
- Write values the way eBay item specifics do: "42 mm", "10 mm", "19 mm", "100 m (10 ATM)", "Japan", "Brushed", "6.76-7 in" (max wrist size), and Year Manufactured as the decade range when only the era is known (e.g. "1990-1999").
- Features and Style may be comma-separated lists.
- "refs": up to 3 pages (NOT ebay.com) from manufacturers, dealers, retailers, watch databases or collectors that describe this exact watch. For each give "url" and "text": a 2-4 sentence factual summary IN YOUR OWN WORDS of what the page says about this model (design, materials, features, era, country of origin, who it suits). Only facts stated on the page, only for the matching variant. Skip if you find none.
- "notes": 1-3 plain sentences of useful background on this model (era, notable design points) that a collector would care about, only if a page states it.
VARIANT CHECK (important): the watch in the photos has case material "${a.caseMaterial || 'unknown'}", case color "${a.caseColor || 'unknown'}", band material "${a.bandMaterial || 'unknown'}", dial color "${a.dialColor || 'unknown'}".
Many references come in several variants (e.g. a resin version and a stainless steel version). Use only pages for the variant that matches these. Report which variant your specs come from. If the only pages you find are a different variant (different case material or color), return empty specs and say so in "variantNote".
Return ONLY a fenced json block:
\`\`\`json
{"specs": {"Case Thickness": {"value": "12 mm", "url": "https://..."}}, "refs": [{"url": "https://...", "text": ""}], "notes": "", "pageVariant": "full reference of the page used", "pageCaseMaterial": "", "pageCaseColor": "", "variantNote": ""}
\`\`\``;
  const out = await callClaudeRaw([{ type: 'text', text: prompt }], 3500, { tools: [{ type: 'web_search_20250305', name: 'web_search', max_uses: 5 }] });
  let j;
  try { j = parseJsonLoose(out.text); } catch (e) { // one bad quote or comma shouldn't lose the research: ask for a corrected copy (no new searching)
    const fixed = await callClaude([{ type: 'text', text: `The text below was meant to be ONE valid JSON object but has a syntax error (${e.message}). Return ONLY the corrected JSON in a fenced json block. Keep all the content. Escape any double quotes inside strings, remove trailing commas and any citation markup.\n\n${out.text}` }], 3500);
    j = parseJsonLoose(fixed);
  }
  const out2 = { specs: j.specs || {}, notes: String(j.notes || ''), refs: (Array.isArray(j.refs) ? j.refs : []).filter((r) => r && r.text && r.url && !/(^|\.)ebay\.[a-z.]+/i.test(String(r.url).replace(/^https?:\/\//, '').split('/')[0])).slice(0, 3).map((r) => ({ title: String(r.url).replace(/^https?:\/\/(www\.)?/, '').slice(0, 60), url: r.url, text: String(r.text).slice(0, 800) })), urls: out.urls, pageVariant: j.pageVariant || '', variantNote: j.variantNote || '' };
  const cls = (m) => { m = String(m || '').toLowerCase(); if (/steel|stainless/.test(m)) return 'steel'; if (/resin|plastic|polymer|carbon/.test(m)) return 'resin'; if (/titanium/.test(m)) return 'titanium'; if (/ceramic/.test(m)) return 'ceramic'; if (/gold/.test(m)) return 'gold'; if (/brass|bronze/.test(m)) return 'brass'; return ''; };
  const photoC = cls(a.caseMaterial), pageC = cls(j.pageCaseMaterial);
  if (photoC && pageC && photoC !== pageC) {
    out2.conflict = `Research found a different variant (${j.pageVariant || 'unknown'}, ${j.pageCaseMaterial} case) than your photos show (${a.caseMaterial}). Its specs were NOT used.`;
  } else if (j.variantNote && !Object.keys(out2.specs).length) out2.conflict = String(j.variantNote);
  return out2;
}

let taxCache = null;
/** eBay's own list of item specifics (and allowed values) for the watch category. */
async function getTaxonomy() {
  if (taxCache && Date.now() - taxCache.t < 24 * 3600 * 1000) return taxCache.map;
  try {
    const token = await getAppToken();
    const r = await fetch(`${EBAY_BASE}/commerce/taxonomy/v1/category_tree/0/get_item_aspects_for_category?category_id=${STORE_DEFAULTS.categoryId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!r.ok) return null;
    const j = await r.json();
    const map = {};
    for (const x of j.aspects || []) {
      map[x.localizedAspectName.toLowerCase()] = {
        name: x.localizedAspectName,
        required: !!x.aspectConstraint?.aspectRequired,
        selectionOnly: x.aspectConstraint?.aspectMode === 'SELECTION_ONLY',
        values: (x.aspectValues || []).map((v) => v.localizedValue),
      };
    }
    taxCache = { t: Date.now(), map };
    return map;
  } catch { return null; }
}

/** Mark each spec valid/invalid against eBay's taxonomy; returns required aspects still missing. */
function applyTaxonomy(specs, tax) {
  const missing = [];
  for (const e of Object.values(specs)) { delete e.valid; delete e.invalidReason; }
  if (!tax) return missing;
  for (const [name, e] of Object.entries(specs)) {
    const info = tax[name.toLowerCase()];
    if (!info) { e.valid = false; e.invalidReason = 'Not an eBay item specific for watches'; continue; }
    if (info.selectionOnly && info.values.length) {
      const pick = (v) => info.values.find((x) => x.toLowerCase() === String(v).toLowerCase());
      if (MULTI.has(name)) {
        const ok = splitMulti(e.value).map(pick).filter(Boolean);
        if (ok.length) e.value = ok.join(', '); else { e.valid = false; e.invalidReason = 'Value not in eBay allowed list'; }
      } else {
        const p = pick(e.value);
        if (p) e.value = p; else { e.valid = false; e.invalidReason = 'Value not in eBay allowed list'; }
      }
    }
  }
  for (const info of Object.values(tax)) {
    if (info.required && !(specs[info.name] && specs[info.name].valid !== false && specs[info.name].value)) missing.push(info.name);
  }
  return missing;
}

/** Combine photo observations, web research and comp consensus into one spec table (each value tagged with where it came from). */
function mergeSpecs(a, web, comps, existing) {
  const S = {};
  const put = (name, value, source, confidence, extra = {}) => {
    if (value === undefined || value === null || value === '' || (Array.isArray(value) && !value.length)) return;
    if (BLANK_SPECS.has(name)) return;
    S[name] = { value: Array.isArray(value) ? value.join(', ') : String(value), source, confidence, ...extra };
  };
  // 1. From the photos
  put('Brand', a.brand, 'photo', a.confidence?.brand >= 0.7 ? 'high' : 'low');
  put('Model', a.model, 'photo', a.confidence?.model >= 0.7 ? 'high' : 'low');
  put('Reference Number', a.modelNumber, 'photo', 'high');
  put('Type', 'Wristwatch', 'store', 'high');
  put('Department', { Mens: 'Men', Womens: 'Women' }[a.gender] || a.gender, 'photo', 'medium');
  put('Movement', a.movement && a.movement !== 'Unknown' ? a.movement : '', 'photo', 'medium');
  put('Case Size', a.caseSizeMm ? `${a.caseSizeMm} mm` : '', 'photo', a.confidence?.caseSizeMm >= 0.7 ? 'high' : 'low');
  put('Case Material', a.caseMaterial, 'photo', 'medium');
  put('Case Color', a.caseColor, 'photo', 'high');
  put('Dial Color', a.dialColor, 'photo', 'high');
  put('Band Material', a.bandMaterial, 'photo', 'medium');
  put('Band Color', a.bandColor, 'photo', 'high');
  put('Style', a.style, 'photo', 'medium');
  if (web?.specs?.Features?.value) { // keep photo-seen features that research agrees with, plus research's own list
    const wl = splitMulti(web.specs.Features.value), wn = wl.map(norm);
    const keep = (a.features || []).filter((f) => wn.some((x) => x.includes(norm(f)) || norm(f).includes(x)));
    put('Features', [...new Set([...keep, ...wl])], 'web', 'medium', { url: web.specs.Features.url });
  } else put('Features', a.features, 'photo', 'low', { note: 'Seen in photos only; not confirmed by research' });
  put('Vintage', a.vintage ? 'Yes' : '', 'photo', 'medium');
  for (const [k, v] of Object.entries(a.observed || {})) put(k, v, 'photo', 'medium');
  // 2. From research: fill gaps, and cross-check web vs comps
  for (const name of RESEARCH_FIELDS) {
    if (name === 'Features' && S.Features && S.Features.source === 'web') continue;
    const w = web?.specs?.[name]?.value ? web.specs[name] : null;
    const c = comps?.specs?.[name] || null;
    const have = S[name];
    if (have && (have.source === 'photo' && have.confidence !== 'low')) {
      const other = w?.value || c?.value;
      if (other && norm(other) !== norm(have.value)) have.alt = `Research says: ${other}`;
      continue;
    }
    if (w && c) {
      if (norm(w.value) === norm(c.value)) put(name, w.value, 'web', 'high', { url: w.url, note: 'Confirmed by web research and other sellers' });
      else put(name, w.value, 'web', 'low', { url: w.url, alt: `Other sellers list: ${c.value}`, note: 'Web research and other sellers disagree — verify' });
    } else if (w) put(name, w.value, 'web', 'medium', { url: w.url });
    else if (c) put(name, c.value, 'ebay-comps', c.n >= 2 ? 'medium' : 'low', { note: `${c.n} of ${c.of} matching listings` });
    else if (have) { /* keep weak photo value */ }
  }
  // 3. Store facts (true unless you say otherwise)
  for (const k of ['With Papers', 'With Original Box/Packaging', 'With Manual/Booklet', 'With Service Records', 'Seller Warranty', 'Handmade', 'Customized']) put(k, 'No', 'store', 'high');
  // 4. Anything you typed by hand always wins
  for (const [k, e] of Object.entries(existing || {})) if (e.source === 'you') S[k] = e;
  return S;
}

async function runResearch(a, compsActive, existingSpecs) {
  const research = { at: new Date().toISOString(), web: false, compListings: 0, sources: [], notes: '', errors: [] };
  const [w, c] = await Promise.allSettled([webResearch(a), (EBAY_CLIENT_ID && EBAY_CLIENT_SECRET) ? compSpecs(a, compsActive) : Promise.resolve(null)]);
  let web = null, comps = null;
  if (w.status === 'fulfilled' && w.value && w.value.conflict) {
    research.errors.push('Possible wrong variant: ' + w.value.conflict);
    research.sources.push(...(w.value.urls || []).slice(0, 3));
  } else if (w.status === 'fulfilled' && w.value) {
    web = w.value; research.web = true; research.notes = web.notes;
    const cited = new Set(Object.values(web.specs).map((s) => s.url).filter(Boolean));
    research.sources.push(...[...cited].map((url) => ({ url, title: url.replace(/^https?:\/\/(www\.)?/, '').slice(0, 60) })));
  } else if (w.status === 'rejected') research.errors.push('Web research: ' + w.reason.message);
  else research.errors.push('Web research skipped — brand and model/reference needed');
  if (c.status === 'fulfilled' && c.value) { comps = c.value; research.compListings = comps.read; research.refDescs = (comps.refDescs || []).slice(0, 4); }
  else if (c.status === 'rejected') research.errors.push('Comp specifics: ' + c.reason.message);
  research.refDescs = [...(research.refDescs || []), ...((web && web.refs) || [])].slice(0, 6);
  { // every page the research touched, as clickable links on the card
    const seen = new Set(), links = [];
    const add = (url, title, kind) => { if (!url || !/^https?:\/\//i.test(url)) return; const k = url.replace(/[#?].*$/, '').replace(/\/$/, ''); if (seen.has(k)) return; seen.add(k); links.push({ url, kind, title: String(title || url).replace(/^https?:\/\/(www\.)?/, '').slice(0, 70) }); };
    if (web) for (const e of Object.values(web.specs || {})) add(e.url, null, 'Spec source');
    for (const r of (web && web.refs) || []) add(r.url, r.title, 'Model description');
    const pages = (w.status === 'fulfilled' && w.value && w.value.urls) || [];
    for (const p of pages) add(p.url, p.title, 'Page found');
    for (const u of (comps && comps.urls) || []) add(u.url, u.title, 'Other seller listing');
    research.links = links.slice(0, 14);
  }
  const specs = mergeSpecs(a, web, comps, existingSpecs);
  const tax = await getTaxonomy();
  const missingRequired = applyTaxonomy(specs, tax);
  research.taxonomy = !!tax;
  return { specs, research, missingRequired };
}

/* ------------------------------------------------------------------ */
/* The B&K guarantee — added deterministically, never left to the AI   */
/* ------------------------------------------------------------------ */
const GUARANTEE = 'Guaranteed Working Condition - Tested by our team at B&K Watches with a new battery, and confirmed to keep accurate time before shipping.';
function guaranteeFor(movement) {
  if (movement === 'Quartz' || movement === 'Digital') return GUARANTEE;
  if (movement === 'Kinetic') return GUARANTEE.replace('a new battery', 'a new capacitor');
  return null;
}
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/** Title + description. Claude writes the title, a hook, an "about" paragraph and the condition paragraph from the researched facts;
 *  the structure, spec list, included items and guarantee line are assembled in code. */
async function writeListing(d) {
  const a = d.analysis, specs = d.specs || {};
  const refs = (d.research?.refDescs || []).filter((r) => r && r.text);
  const facts = Object.entries(specs).filter(([, e]) => e.valid !== false && e.source !== 'store')
    .map(([k, e]) => `${k}: ${e.value}`);
  const prompt = `Write the text for an eBay listing for "B and K Watches". Match this house style exactly (example for a different watch):
"The Gruen Precision 1990's Women's Watch features a classic design with a silver and gold tone stainless steel case and bracelet. The watch has a fluted bezel, luminous hands and indexes, a quartz movement, and a 25mm case size. With Roman numerals and stick indexes on the dial, this vintage timepiece is perfect for both dress/formal occasions and casual wear. The watch also has a snap caseback and is not water resistant. Made in Thailand, this stylish wristwatch is a timeless accessory for any woman's collection."
FACTS (the only facts you may use): ${JSON.stringify(facts)}
Background found by research (may be empty): ${JSON.stringify(d.research?.notes || '')}
${(d.storeRef?.similar || []).length ? `YOUR STORE'S OWN TITLES for similar watches (style guide only — match their word order, abbreviations and conventions such as WR, Day/Date, Mens/Womens, ending in New Battery; do not copy one exactly, this watch's details come from FACTS): ${JSON.stringify(d.storeRef.similar.slice(0, 8).map((x) => x.title))}
` : ''}${refs.length ? `REFERENCE — descriptions other sellers wrote for the same model, for research ONLY. They show what this model is and which details buyers care about. NEVER copy or closely paraphrase their sentences or phrasing; write everything fresh in the house style above. Use a detail from them only if it also appears in FACTS/background, or at least two of them agree on it and it does not contradict FACTS (and never contradict what the photos show):
${JSON.stringify(refs.map((r) => r.text))}` : ''}
Return ONLY JSON: {"title": "", "paragraph": ""}
- paragraph: ONE plain paragraph of 4-6 sentences in that style. Open with "The {Brand} {Model} {decade if vintage} {Men's/Women's} Watch features ...", then case/band material and colors, bezel, lume, movement and case size, dial numerals/indexes, who and what occasions it suits, caseback and water resistance, "Made in {country}" only if Country of Origin is in the FACTS, and close with a "timeless accessory" style sentence. Use only the FACTS. No bullets, no markdown. Do NOT mention flaws, wear, scratches or the watch's condition in the paragraph.
- title: max 80 chars, Mens/Womens without apostrophes. Pattern "${STORE_DEFAULTS.titleTemplate}". Example: "Gruen Precision 1990's Womens Watch Silver Gold Tone Fluted Bezel New Battery". Include the reference number only if there is room. Do not add "New Battery" / "New Capacitor"; the app adds it.
- Do NOT mention testing, batteries being installed, or any guarantee. The app adds that.`;
  let j = null, raw = '', extra = '';
  for (let attempt = 0; attempt < 3 && !j; attempt++) {
    raw = await callClaude(attempt ? prompt + (extra || '\n\nYour previous reply was not valid JSON. Reply with ONLY the JSON object {"title": "...", "paragraph": "..."} and nothing else.') : prompt, 1200);
    try { j = parseJsonLoose(raw); if (!j.paragraph) j = null; } catch { j = null; }
    if (j && refs.length) { const hit = copiesRef(j.paragraph, refs); if (hit) { j = null; raw = `Copied wording from another listing ("${hit}")`; extra = `\n\nYour previous paragraph reused wording from the REFERENCE listings ("${hit}"). Rewrite the whole paragraph in completely fresh wording.`; } }
  }
  if (!j) { const e = new Error('The AI did not return a usable description (tried 3 times).'); e.raw = String(raw).slice(0, 400); throw e; }
  const movement = specs.Movement?.value || a.movement;
  let title = cleanTitle(j.title || a.suggestedTitle, movement);
  const must = d.userInput?.modelNumber || '';
  if (must) title = ensureInTitle(title, must, movement);
  const g = guaranteeFor(movement);
  let html = '';
  const P = 'font-size:16px;font-family:Arial,Helvetica,sans-serif;line-height:1.5;margin:0 0 16px';
  if (g) html += `<p style="${P}">${esc(g)}</p>`;
  html += `<p style="${P}">${esc(j.paragraph || '')}${d.stockNumber ? ' ' + esc(d.stockNumber) : ''}</p>`;
  return { title, description: html };
}

/* ------------------------------------------------------------------ */
/* Comps — keyword search + image search (Browse API)                  */
/*    True SOLD comps need the Marketplace Insights API (needs eBay    */
/*    approval); auto-used if your keyset has access.                  */
/* ------------------------------------------------------------------ */
const median = (arr) => {
  const s = [...arr].sort((a, b) => a - b);
  return s.length ? (s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2) : null;
};
const round99 = (v) => (v >= 20 ? Math.max(7.99, Math.round(v) - 0.01) : Math.max(7.99, Math.round(v * 2) / 2 - 0.01));

function suggestPrice(active, image, sold) {
  if (sold.length >= 3) {
    return { price: round99(median(sold.map((i) => i.price))), basis: `median of ${sold.length} SOLD comps`, confidence: 'high' };
  }
  if (active.length >= 3) {
    // Active asks run high vs realized prices; discount to be competitive.
    return { price: round99(median(active.map((i) => i.price)) * 0.85), basis: `85% of median ask across ${active.length} ACTIVE keyword comps (no sold-data access)`, confidence: 'medium' };
  }
  if (image.length >= 3) {
    return { price: round99(median(image.map((i) => i.price)) * 0.85), basis: `85% of median ask across ${image.length} VISUAL matches (image search; may include look-alikes) — verify`, confidence: 'low' };
  }
  return { price: null, basis: 'insufficient comps — price manually', confidence: 'low' };
}

/* ------------------------------------------------------------------ */
/* Price research beyond eBay's API: Claude web-searches other markets */
/* (Chrono24, WatchCharts, dealers, retailers, marketplaces) for this  */
/* exact reference and returns the prices the pages actually state.    */
/* blendPrice() then weighs every data point — eBay sold/asking/image, */
/* web sold/asking, your own store — into one suggested price.         */
/* ------------------------------------------------------------------ */
async function priceResearch(a, d) {
  if (!a.brand || !(a.modelNumber || a.model)) return { points: [], retail: [], notes: ['Brand and model/reference needed for web price research'] };
  const knownPages = [...(d?.research?.sources || []), ...(d?.research?.links || [])].map((x) => x.url).filter(Boolean).slice(0, 8);
  const ident = [a.brand, a.model, a.modelNumber && `reference ${a.modelNumber}`, a.gender, a.movement, a.caseMaterial, a.dialColor && `${a.dialColor} dial`].filter(Boolean).join(', ');
  const prompt = `PRICE RESEARCH for a pre-owned watch an eBay seller is about to price: ${ident}.
Use web search to find real market prices for this EXACT brand and reference/model (same case material and dial variant) from many different sites: sold or asking prices on Chrono24, WatchCharts, WatchRecon, Etsy, Poshmark, Mercari, Amazon, dealer and resale shops, auction results, collector forums, plus the manufacturer's or an authorized retailer's new price (MSRP).${knownPages.length ? ' Pages already found in earlier research that may list prices: ' + knownPages.join(' , ') : ''}
Rules:
- Include a price ONLY if a page you retrieved states it for this exact watch. Never estimate, average, or fill from general knowledge. Skip different variants and lots/bundles.
- USD only (skip other currencies). Ignore shipping.
- kind: "sold" (completed sale / auction result), "asking" (current listing), or "retail" (new, from manufacturer/retailer).
- condition: "new", "used" or "unknown". Pre-owned/vintage is "used".
- Up to 14 points, from as many different sites as possible (not 14 from one site).
Return ONLY a fenced json block:
\`\`\`json
{"points": [{"site": "Chrono24", "url": "https://...", "price": 129.0, "kind": "asking", "condition": "used", "date": "2026-09", "note": "short"}], "notes": ["plain sentence about gaps or caveats"]}
\`\`\``;
  let parsed = null, raw = null, urls = [];
  try {
    const out = await callClaudeRaw([{ type: 'text', text: prompt }], 3500, { tools: [{ type: 'web_search_20250305', name: 'web_search', max_uses: 8 }] });
    raw = out.text; urls = out.urls || [];
    try { parsed = parseJsonLoose(raw); } catch {
      // The research reply wasn't clean JSON — convert it in a second step without tools.
      const fix = await callClaudeRaw([{ type: 'text', text: `Convert the notes below into ONLY the JSON object {"points":[{"site","url","price"(number),"kind":"sold|asking|retail","condition":"new|used|unknown","date","note"}],"notes":[]}. Keep only prices that the notes attribute to a page. No prose.\n\nNOTES:\n${raw.slice(0, 8000)}` }], 3000);
      parsed = parseJsonLoose(fix.text);
    }
  } catch (e) { return { points: [], retail: [], notes: ['Web price research failed: ' + e.message] }; }
  const pts = (Array.isArray(parsed.points) ? parsed.points : []).map((p) => ({
    site: String(p.site || (p.url ? new URL(p.url, 'https://x.invalid').hostname.replace(/^www\./, '') : 'web')).slice(0, 40), url: String(p.url || ''),
    price: Number(String(p.price).replace(/[^0-9.]/g, '')), kind: ['sold', 'asking', 'retail'].includes(p.kind) ? p.kind : 'asking',
    condition: ['new', 'used', 'unknown'].includes(p.condition) ? p.condition : 'unknown', date: String(p.date || ''), note: String(p.note || '').slice(0, 120),
  })).filter((p) => p.price > 1 && p.price < 100000 && /^https?:/.test(p.url));
  const seen = new Set(), clean = [];
  for (const p of pts) { const k = p.url + '|' + p.price; if (!seen.has(k)) { seen.add(k); clean.push(p); } }
  return { points: clean.filter((p) => p.kind !== 'retail').slice(0, 16), retail: clean.filter((p) => p.kind === 'retail').slice(0, 4), notes: (parsed.notes || []).map(String).slice(0, 4) };
}

/** Weigh every price data point into one suggestion. */
function blendPrice({ comps, web, storeRef, own }) {
  const ev = []; // {v: adjusted $, raw, w: weight, label, kind, url, src}
  const add = (o) => { if (o.raw > 0) ev.push({ ...o, v: o.raw * o.f }); };
  for (const i of (comps?.sold || []).slice(0, 12)) add({ raw: i.price, f: 1, w: 3, label: 'eBay sold', kind: 'sold', url: i.url, src: 'ebay-sold' });
  for (const i of (comps?.active || []).slice(0, 15)) add({ raw: i.price, f: 0.85, w: 1, label: 'eBay asking', kind: 'asking', url: i.url, src: 'ebay-asking' });
  for (const i of (comps?.image || []).slice(0, 10)) add({ raw: i.price, f: 0.85, w: 0.4, label: 'eBay visual match', kind: 'asking', url: i.url, src: 'ebay-image' });
  for (const p of web?.points || []) {
    if (p.condition === 'new') continue; // a new price says little about a pre-owned one — kept only as a ceiling
    if (p.kind === 'sold') add({ raw: p.price, f: 1, w: 2.5, label: p.site + ' sold', kind: 'sold', url: p.url, src: 'web:' + p.site });
    else add({ raw: p.price, f: 0.85, w: p.condition === 'used' ? 1.2 : 0.7, label: p.site + ' asking', kind: 'asking', url: p.url, src: 'web:' + p.site });
  }
  for (const i of (own?.items || []).slice(0, 10)) add({ raw: i.price, f: 1, w: i.strong ? 3.5 : 2, label: 'Your past sale', kind: 'sold', url: '', src: 'own-sale' });
  if (storeRef?.medianPrice > 0) add({ raw: storeRef.medianPrice, f: 1, w: /similar/.test(storeRef.priceBasis || '') ? 1.5 : 0.5, label: 'Your store', kind: 'store', url: '', src: 'store' });
  if (!ev.length) return { price: null, basis: 'insufficient price data — price manually', confidence: 'low', points: [], range: null };
  const sorted = [...ev].sort((a, b) => a.v - b.v), total = sorted.reduce((s, e) => s + e.w, 0);
  let acc = 0, wm = sorted[0].v;
  for (const e of sorted) { acc += e.w; if (acc >= total / 2) { wm = e.v; break; } }
  const q = (p) => sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * p))].v;
  let price = wm, capNote = '';
  const minNew = Math.min(...(web?.retail || []).filter((r) => r.condition !== 'used').map((r) => r.price));
  if (isFinite(minNew) && price > minNew * 0.8) { price = minNew * 0.8; capNote = `; capped at 80% of the $${minNew.toFixed(2)} new price`; }
  price = round99(price);
  const soldN = ev.filter((e) => e.kind === 'sold').length, srcs = new Set(ev.map((e) => e.src.replace(/^web:/, 'web:'))).size;
  const confidence = soldN >= 3 ? 'high' : (ev.length >= 4 && srcs >= 2) || ev.length >= 6 ? 'medium' : 'low';
  const by = {}; for (const e of ev) by[e.label] = (by[e.label] || 0) + 1;
  return {
    price, confidence, range: [round99(q(0.25)), round99(q(0.75))],
    basis: `weighted median of ${ev.length} data points (${Object.entries(by).map(([k, n]) => `${n} ${k}`).join(', ')}); middle range $${round99(q(0.25)).toFixed(2)}–$${round99(q(0.75)).toFixed(2)}${capNote}`,
    points: ev.slice(0, 50).map((e) => ({ label: e.label, kind: e.kind, raw: e.raw, adj: Math.round(e.v * 100) / 100, weight: e.w, url: e.url })),
    retail: (web?.retail || []).map((r) => ({ site: r.site, price: r.price, url: r.url })),
  };
}

async function findComps(a, firstImage) { // firstImage: {buffer, mime} or a base64 string
  const q = [a.brand, a.modelNumber || a.model, a.gender, a.movement === 'Quartz' ? '' : a.movement, 'watch']
    .filter(Boolean).join(' ').trim();
  const token = await getAppToken();
  const H = { Authorization: `Bearer ${token}`, 'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US' };
  const mapItems = (data) => (data.itemSummaries || []).map((i) => ({
    itemId: i.itemId, title: i.title, price: parseFloat(i.price?.value || 0), condition: i.condition, url: i.itemWebUrl, image: i.image?.imageUrl,
  })).filter((i) => i.price > 0);
  const out = { query: q, active: [], image: [], sold: [], notes: [] };

  if (a.brand) {
    try {
      const r = await fetch(`${EBAY_BASE}/buy/browse/v1/item_summary/search?q=${encodeURIComponent(q)}&category_ids=${STORE_DEFAULTS.categoryId}&filter=conditions:{USED}&limit=25&sort=price`, { headers: H });
      const data = await r.json();
      if (data.errors) throw new Error(data.errors[0]?.message || 'Browse search error');
      out.active = mapItems(data);
    } catch (e) { out.notes.push('Keyword search failed: ' + e.message); }
  }

  if (firstImage) {
    try {
      const b64 = typeof firstImage === 'string' ? firstImage : firstImage.buffer.toString('base64');
      const r = await fetch(`${EBAY_BASE}/buy/browse/v1/item_summary/search_by_image?category_ids=${STORE_DEFAULTS.categoryId}&filter=conditions:{USED}&limit=25`, {
        method: 'POST',
        headers: { ...H, 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: b64 }),
      });
      const data = await r.json();
      if (data.errors) throw new Error(data.errors[0]?.message || 'Image search error');
      out.image = mapItems(data);
    } catch (e) { out.notes.push('Image search failed: ' + e.message); }
  }

  try {
    const mi = await fetch(`${EBAY_BASE}/buy/marketplace_insights/v1_beta/item_sales/search?q=${encodeURIComponent(q)}&category_ids=${STORE_DEFAULTS.categoryId}&limit=25`, { headers: H });
    if (mi.ok) {
      const md = await mi.json();
      out.sold = (md.itemSales || []).map((i) => ({ title: i.title, price: parseFloat(i.lastSoldPrice?.value || 0), date: i.lastSoldDate })).filter((i) => i.price > 0);
    }
  } catch { /* no insights access */ }

  out.suggestion = suggestPrice(out.active, out.image, out.sold);
  return out;
}

/* ------------------------------------------------------------------ */
/* Photo hosting — eBay Media API (createImageFromFile -> getImage)    */
/* ------------------------------------------------------------------ */
async function uploadImageToEbay(buffer, filename, mime = 'image/jpeg') {
  const token = await getUserToken();
  const fd = new FormData();
  fd.append('image', new Blob([buffer], { type: mime }), filename);
  const r = await fetch(`${EBAY_MEDIA_BASE}/commerce/media/v1_beta/image/create_image_from_file`, {
    method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd,
  });
  if (r.status !== 201) throw new Error(`eBay photo upload ${r.status}: ${(await r.text()).slice(0, 300)}`);
  const loc = r.headers.get('location');
  if (!loc) throw new Error('eBay photo upload: no Location header returned');
  const g = await fetch(loc, { headers: { Authorization: `Bearer ${token}` } });
  const j = await g.json();
  if (!j.imageUrl) throw new Error('eBay photo upload: getImage returned no imageUrl: ' + JSON.stringify(j).slice(0, 200));
  return j.imageUrl;
}

/* ------------------------------------------------------------------ */
/* Publish — Inventory API: inventory item -> offer -> publish         */
/* ------------------------------------------------------------------ */
function buildAspects(d) {
  const aspects = {};
  for (const [k, e] of Object.entries(d.specs || {})) {
    if (!e.value || e.valid === false) continue;
    aspects[k] = MULTI.has(k) ? splitMulti(e.value) : [String(e.value)];
  }
  return aspects;
}

async function publishListing({ sku, title, description, price, condition, aspects, imageUrls, quantity = 1 }) {
  if (NO_PUBLISH) throw new Error('Publishing is switched off in this test mode.');
  if (!title || title.length > STORE_DEFAULTS.titleMaxLen) throw new Error('Title required, max 80 chars');
  if (!price || price <= 0) throw new Error('Valid price required');
  if (!imageUrls?.length) throw new Error('At least one hosted image URL required');
  const pol = ebayPolicies();
  if (!pol.fulfillment || !pol.payment || !pol.returns) throw new Error('Business policies not chosen yet — open the "eBay connection" page and pick your shipping, payment and returns policies.');
  const token = await getUserToken();
  const H = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Language': 'en-US', 'Accept-Language': 'en-US' };
  // The Wristwatches category only has one pre-owned code (3000), same as the numeric codes in export-settings.json, so all three pre-owned grades map to it.
  const API_COND = { 'Pre-owned - Excellent': 'USED_EXCELLENT', 'Pre-owned - Good': 'USED_EXCELLENT', 'Pre-owned - Fair': 'USED_EXCELLENT' };
  const condEnum = API_COND[condition] || (STORE_DEFAULTS.conditionMap[condition] || STORE_DEFAULTS.conditionMap[STORE_DEFAULTS.conditionDefault]).condition;
  // Same schedule as the CSV route: start N days ahead (exportSettings.scheduleDaysAhead) at 13:00 UTC, so the listing is scheduled, not live. 0 = go live immediately.
  const startDate = (() => { const n = Number(exportSettings().scheduleDaysAhead) || 0; if (n <= 0) return null; const t = new Date(Date.now() + n * 864e5); t.setUTCHours(13, 0, 0, 0); return t.toISOString(); })();

  let r = await fetch(`${EBAY_BASE}/sell/inventory/v1/inventory_item/${encodeURIComponent(sku)}`, {
    method: 'PUT', headers: H,
    body: JSON.stringify({
      product: { title, description, aspects, imageUrls },
      condition: condEnum,
      availability: { shipToLocationAvailability: { quantity } },
    }),
  });
  if (![200, 201, 204].includes(r.status)) throw new Error(`inventory_item ${r.status}: ${await r.text()}`);

  r = await fetch(`${EBAY_BASE}/sell/inventory/v1/offer`, {
    method: 'POST', headers: H,
    body: JSON.stringify({
      sku, marketplaceId: 'EBAY_US', format: 'FIXED_PRICE',
      categoryId: STORE_DEFAULTS.categoryId,
      listingDescription: description,
      pricingSummary: { price: { value: String(price), currency: 'USD' } },
      listingPolicies: {
        fulfillmentPolicyId: pol.fulfillment,
        paymentPolicyId: pol.payment,
        returnPolicyId: pol.returns,
      },
      merchantLocationKey: ebayLocationKey(),
      availableQuantity: quantity,
      listingDuration: 'GTC',
      ...(startDate ? { listingStartDate: startDate } : {}),
    }),
  });
  let offer = await r.json();
  if (!offer.offerId) {
    const existing = offer.errors?.[0]?.parameters?.find((p) => p.name === 'offerId')?.value;
    if (!existing) throw new Error('offer create failed: ' + JSON.stringify(offer));
    offer = { offerId: existing };
  }

  r = await fetch(`${EBAY_BASE}/sell/inventory/v1/offer/${offer.offerId}/publish`, { method: 'POST', headers: H });
  const pub = await r.json();
  if (!pub.listingId) throw new Error('publish failed: ' + JSON.stringify(pub));
  return { listingId: pub.listingId, url: `https://www.ebay.com/itm/${pub.listingId}`, env: EBAY_ENV };
}


/* ================================================================== */
/* Batch queue — drafts persisted on disk (~/BandKListingData/drafts)  */
/* ================================================================== */
const validId = (id) => /^[a-f0-9]{8}$/.test(id);
const draftDir = (id) => path.join(DRAFTS_DIR, id);
function readDraft(id) {
  if (!validId(id)) return null;
  try { return JSON.parse(fs.readFileSync(path.join(draftDir(id), 'draft.json'), 'utf8')); } catch { return null; }
}
function writeDraft(d) { fs.writeFileSync(path.join(draftDir(d.id), 'draft.json'), JSON.stringify(d, null, 2)); }
function updateDraft(id, patch) {
  const d = readDraft(id);
  if (!d) return null;
  Object.assign(d, patch);
  writeDraft(d);
  return d;
}
function listDrafts() {
  return fs.readdirSync(DRAFTS_DIR).filter(validId).map(readDraft).filter(Boolean)
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

const hasBattery = (d) => !!guaranteeFor(d.specs?.Movement?.value || d.analysis?.movement);

function warningsFor(d) {
  const w = [];
  const a = d.analysis || {};
  const c = a.confidence || {};
  if (!d.analysis) return w;
  const mv = d.specs?.Movement?.value || a.movement;
  if (!(c.brand >= 0.7)) w.push({ text: `Brand confidence low (${Math.round((c.brand || 0) * 100)}%) — verify`, blocking: true });
  if (!(c.model >= 0.7)) w.push({ text: `Model confidence low (${Math.round((c.model || 0) * 100)}%) — verify`, blocking: true });
  if (!(d.price > 0)) w.push({ text: 'No price suggested — enter one', blocking: true });
  if (d.title && d.title.length > STORE_DEFAULTS.titleMaxLen) w.push({ text: 'Title is over 80 characters', blocking: true });
  if (!mv || mv === 'Unknown') w.push({ text: 'Movement unknown — set it under Item specifics (decides the guarantee wording)', blocking: true });
  else if (mv === 'Solar') w.push({ text: 'Solar watch — no battery guarantee line added; add your own wording if needed', blocking: false });
  { const g = guaranteeFor(mv); if (g && d.description && !htmlToText(d.description).replace(/\s+/g, ' ').includes(g)) w.push({ text: 'Your guarantee line is missing or changed in the description — restore it exactly', blocking: true }); }
  if (d.suggestion?.confidence === 'low' && d.price > 0) w.push({ text: 'Price based on weak comps — double-check', blocking: false });
  if (d.storeRef?.duplicate) w.push({ text: `You may already list this watch: "${d.storeRef.duplicate.title}" (item ${d.storeRef.duplicate.id}, $${d.storeRef.duplicate.price})`, blocking: false });
  if (!d.authenticity && !d.authError) w.push({ text: 'Authenticity not checked yet — review/enhance the photos, then press "Run authenticity check"', blocking: true });
  { const au = d.authenticity;
    if (au?.risk === 'high') w.push({ text: 'AUTHENTICITY: high risk — ' + (au.redFlags.find((f) => f.severity === 'high')?.detail || au.summary), blocking: true });
    else if (au?.risk === 'elevated') w.push({ text: 'Authenticity: elevated risk — review the Authenticity report before listing', blocking: false });
    else if (au?.risk === 'undetermined') w.push({ text: 'Authenticity could not be judged from these photos — see the report', blocking: false });
    else if (au?.risk === 'low' && au.brandProne) w.push({ text: 'Brand is often counterfeited — "no red flags" is not proof. Check the report.', blocking: false });
    if (d.authError) w.push({ text: 'Authenticity check failed: ' + d.authError, blocking: true }); }
  if (d.compsError) w.push({ text: 'Comps failed: ' + d.compsError, blocking: false });
  if (a.visibleFlaws?.length) w.push({ text: 'Flaws noted: ' + a.visibleFlaws.join('; '), blocking: false });
  if (!a.modelNumber && !d.specs?.['Reference Number']) w.push({ text: 'Reference number not found', blocking: false });
  for (const e of d.research?.errors || []) w.push({ text: e, blocking: false });
  const weak = Object.values(d.specs || {}).filter((e) => e.confidence === 'low' && e.source !== 'photo').length;
  if (weak) w.push({ text: `${weak} researched spec${weak > 1 ? 's are' : ' is'} unconfirmed (amber) — glance before approving`, blocking: false });
  const bad = Object.entries(d.specs || {}).filter(([, e]) => e.valid === false).map(([k]) => k);
  if (bad.length) w.push({ text: `Not accepted by eBay, will be left off: ${bad.join(', ')}`, blocking: false });
  if (d.missingRequired?.length) w.push({ text: `eBay requires: ${d.missingRequired.join(', ')}`, blocking: false });
  if (d.descError) w.push({ text: 'Description not written: ' + d.descError + ' Click Rewrite description.', blocking: true });
  if (d.descStale) w.push({ text: 'Specs changed since the description was written — press Rewrite description (Approve stays locked until you do)', blocking: true });
  return w;
}
const flawsText = (a) => (a?.visibleFlaws || []).length ? a.visibleFlaws.join('. ').replace(/\.?$/, '.') : '';
const decorate = (d) => ({ ...d, sellerNotes: typeof d.sellerNotes === 'string' ? d.sellerNotes : flawsText(d.analysis), warnings: warningsFor(d), hasBattery: hasBattery(d), guarantee: guaranteeFor(d.specs?.Movement?.value || d.analysis?.movement) });
const hardBlock = (d) => warningsFor(d).some((w) => w.blocking && /guarantee line/.test(w.text)) || !!d.descError || !!d.descStale || !(d.price > 0) || !d.title || d.title.length > STORE_DEFAULTS.titleMaxLen;


/* ------------------------------------------------------------------ */
/* eBay upload CSV (Seller Hub bulk upload) — header comes from the     */
/* template you drop in reference/ (any CSV with "template" in its name) */
/* ------------------------------------------------------------------ */
function exportSettings() {
  const base = { action: 'Draft', dispatchTimeMax: '', returnsAcceptedOption: '', returnsWithinOption: '', refundOption: '', shippingCostPaidByOption: '', shippingType: '', shippingService1Option: '', shippingService1Cost: '', format: 'FixedPrice', duration: 'GTC', quantity: 1, location: '', shippingProfileName: '', returnProfileName: '', paymentProfileName: '', conditionIds: {}, conditionIdsNumeric: {}, scheduleDaysAhead: 0, cloudinaryCloudName: '', cloudinaryUploadPreset: '', cloudinaryTransform: '', cloudinaryApiKey: '', cloudinaryApiSecret: '' };
  for (const f of [path.join(__dirname, 'export-settings.json'), path.join(DATA_DIR, 'export-settings.json')]) {
    try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); Object.assign(base, j, { conditionIds: { ...base.conditionIds, ...(j.conditionIds || {}) }, conditionIdsNumeric: { ...base.conditionIdsNumeric, ...(j.conditionIdsNumeric || {}) } }); } catch { /* optional */ }
  }
  return base;
}
function findUploadTemplate() {
  for (const dir of REF_DIRS) {
    try {
      for (const f of fs.readdirSync(dir)) if (/template.*\.csv$/i.test(f)) {
        const rows = reference.parseCsv(fs.readFileSync(path.join(dir, f), 'utf8'));
        const hi = rows.findIndex((r) => r.some((c) => /^\*?\s*title\b/i.test(c.trim())));
        if (hi >= 0) {
          const header = rows[hi].map((c) => c.trim()), sample = rows[hi + 1] || [];
          const ci = header.findIndex((c) => /^\*?\s*condition\s*id/i.test(c));
          const preface = rows.slice(0, hi).filter((r) => r.some((c) => String(c).trim())).map((r) => { let e = r.length; while (e > 1 && !String(r[e - 1]).trim()) e--; return r.slice(0, e); });
          return { file: f, header, preface, forceDraft: /action to draft/i.test(preface.flat().join(' ')), textCondition: ci >= 0 && sample[ci] && !/^\d+$/.test(String(sample[ci]).trim()) };
        }
      }
    } catch { /* none */ }
  }
  return null;
}
const csvCell = (v) => { const t = String(v ?? ''); return /[",\r\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; };

// eBay upload rules for item specifics: multi-value aspects separate values with "|", and every value is at most 65 characters.
const MULTI_ASPECTS = new Set(['features', 'style', 'theme']);
function aspectCell(name, value) {
  let v = String(value || '').trim();
  if (!v) return '';
  const parts = MULTI_ASPECTS.has(name.toLowerCase()) ? v.split(/\s*[,;|]\s*/).filter(Boolean) : [v];
  return parts.map((x) => (x.length > 65 ? x.slice(0, 65).replace(/\s+\S*$/, '') || x.slice(0, 65) : x)).join('|');
}
function buildUploadCsv(list) {
  const st = exportSettings(), notes = [];
  let tpl = findUploadTemplate(), header;
  if (tpl) header = tpl.header;
  else {
    const aspectCols = [...new Set(list.flatMap((d) => Object.entries(d.specs || {}).filter(([, e]) => e.valid !== false && e.value).map(([k]) => k)))]
      .sort((a, b) => (SPEC_ORDER.indexOf(a) + 1 || 999) - (SPEC_ORDER.indexOf(b) + 1 || 999));
    header = ['*Action', 'CustomLabel', '*Category', '*Title', '*ConditionID', ...aspectCols.map((n) => 'C:' + n), 'PicURL', '*Description', '*Format', '*Duration', '*StartPrice', '*Quantity', 'Location', 'ShippingProfileName', 'ReturnProfileName', 'PaymentProfileName'];
    notes.push('No eBay template found in the reference folder, so a standard column layout was used. For a guaranteed match, download the blank listing template from Seller Hub and drop it in the reference folder (see the README).');
  }
  const missingCond = new Set();
  const lines = [...(tpl?.preface || []).map((r) => r.map(csvCell).join(',')), header.map(csvCell).join(',')];
  if (tpl?.forceDraft) st.action = 'Draft';
  for (const d of list) {
    const specs = d.specs || {};
    const spec = (name) => { const k = Object.keys(specs).find((x) => x.toLowerCase() === name.toLowerCase()); const e = k && specs[k]; return e && e.valid !== false ? e.value : ''; };
    const cell = (h) => {
      const raw = h.replace(/\(.*$/, '').trim();
      const key = raw.replace(/^\*/, '').toLowerCase().replace(/[^a-z0-9:]/g, '');
      if (/^c:/.test(key)) { const nm = raw.replace(/^\*?\s*c:\s*/i, ''); return aspectCell(nm, spec(nm) || (/^type$/i.test(nm) ? 'Wristwatch' : '')); }
      switch (key) {
        case 'action': return st.action;
        case 'customlabel': case 'sku': return d.sku || '';
        case 'category': case 'categoryid': case 'ebaycategory': return STORE_DEFAULTS.categoryId;
        case 'title': return d.title || '';
        case 'description': return d.description || '';
        case 'scheduletime': { if (!(st.scheduleDaysAhead > 0)) return ''; const t = new Date(Date.now() + st.scheduleDaysAhead * 864e5); t.setUTCHours(13, 0, 0, 0); return t.toISOString().slice(0, 19).replace('T', ' '); }
        case 'conditionid': { const id = tpl?.textCondition ? (st.conditionIds[d.condition] || (STORE_DEFAULTS.conditionMap[d.condition] || {}).condition) : (st.conditionIdsNumeric[d.condition] || ''); if (!id) missingCond.add(d.condition); return id || ''; }
        case 'condition': return d.condition || '';
        case 'format': case 'listingformat': return st.format;
        case 'duration': case 'listingduration': return st.duration;
        case 'startprice': case 'price': return d.price ? Number(d.price).toFixed(2) : '';
        case 'quantity': return st.quantity;
        case 'picurl': case 'pictureurl': case 'itemphotourl': case 'photourl': return (d.pictureUrls || []).join('|');
        case 'location': return st.location;
        case 'dispatchtimemax': return st.dispatchTimeMax;
        case 'returnsacceptedoption': return st.returnsAcceptedOption;
        case 'returnswithinoption': return st.returnsWithinOption;
        case 'refundoption': return st.refundOption;
        case 'shippingcostpaidbyoption': return st.shippingCostPaidByOption;
        case 'shippingtype': return st.shippingType;
        case 'shippingservice1option': case 'shippingservice1:option': return st.shippingService1Option;
        case 'shippingservice1cost': case 'shippingservice1:cost': return st.shippingService1Cost;
        case 'shippingprofilename': return st.shippingProfileName;
        case 'returnprofilename': return st.returnProfileName;
        case 'paymentprofilename': return st.paymentProfileName;
        default: { const nm = raw.replace(/^\*\s*/, ''); const v = aspectCell(nm, spec(nm)); return v || (/^c:\s*type$/i.test(nm) ? 'Wristwatch' : ''); } // item-specific columns (Brand, Model, Movement...) match a spec by name
      }
    };
    lines.push(header.map((h) => csvCell(cell(h))).join(','));
  }
  if (missingCond.size) notes.push(`ConditionID is blank for: ${[...missingCond].join(', ')}. Fill the codes in export-settings.json (they're listed in eBay's template instructions) or eBay will reject those rows.`);
  if (header.some((h) => /^\*?(pic(ture)?url|item\s*photo\s*url)/i.test(h)) && list.some((d) => !(d.pictureUrls || []).length)) notes.push('PicURL is blank: eBay needs photos hosted online, so add the photos to each listing in Seller Hub after the upload (or turn on automatic photo upload once your eBay keys work).');
  notes.push(tpl ? `Columns follow your template "${tpl.file}".` : '');
  return { csv: '\uFEFF' + lines.join('\r\n') + '\r\n', notes: notes.filter(Boolean), count: list.length };
}

const trimList = (l) => (l || []).slice(0, 8).map(({ title, price, url, date, itemId }) => ({ title, price, url, date, itemId }));
const trimComps = (c) => c && ({ query: c.query, active: trimList(c.active), image: trimList(c.image), sold: trimList(c.sold), notes: c.notes });
const makeSku = (a, id) => `BK-${String(a?.brand || 'W').replace(/\W/g, '').toUpperCase().slice(0, 8) || 'W'}-${id}`;

/* ------------------------------------------------------------------ */
/* Authenticity screen. This is a RED-FLAG SCREEN, not an appraisal:   */
/* photos are read for dial/caseback text, fonts, logos, alignment and */
/* hardware, then compared with what manufacturer / collector / fake-  */
/* spotting pages say about this exact reference. It can raise a flag  */
/* or fail to find one — it can never prove a watch is genuine.        */
/* ------------------------------------------------------------------ */
const FAKE_PRONE = /rolex|omega|cartier|breitling|tag heuer|tudor|patek|audemars|panerai|iwc|hublot|richard mille|longines|zenith|jaeger|vacheron|bulgari|bvlgari|chopard|oris|rado|tissot|hamilton|seiko|grand seiko|citizen|casio|g-shock|invicta|fossil|movado|bulova|michael kors|armani|diesel|nixon|swiss army|victorinox|gucci|chanel|hermes|hermès|breguet|u-boat|bell & ross|ulysse|nomos|sinn|tutima|girard|baume|ebel|raymond weil|maurice lacroix|frederique|certina|mido|rotary/i;
function priceFlag(d) {
  const p = Number(d.price), c = d.comps || {};
  const nums = (l) => (l || []).map((x) => Number(x.price)).filter((n) => n > 0).sort((a, b) => a - b);
  const med = (a) => (a.length ? a[Math.floor(a.length / 2)] : null);
  const sold = med(nums(c.sold)), act = med(nums(c.active));
  const ref = sold || act;
  if (!(p > 0) || !ref || (sold ? nums(c.sold) : nums(c.active)).length < 3) return null;
  if (p < ref * 0.35) return `Your price ($${p.toFixed(2)}) is far below the ${sold ? 'sold' : 'listed'} median ($${ref.toFixed(2)}). Genuine watches rarely trade that low; counterfeits and parts-only watches often do.`;
  return null;
}
async function authenticityCheck(d) {
  const a = d.analysis || {};
  const content = [];
  for (const [i, p] of (d.photos || []).slice(0, 8).entries()) {
    const buf = fs.readFileSync(path.join(draftDir(d.id), p.enhanced || p.file));
    content.push({ type: 'text', text: `Photo ${i + 1}:` }, { type: 'image', source: { type: 'base64', media_type: p.mime, data: buf.toString('base64') } });
  }
  const spec = (k) => d.specs?.[k]?.value;
  const claim = [a.brand, a.model, a.modelNumber && `ref ${a.modelNumber}`, spec('Movement') || a.movement, a.caseMaterial, a.dialColor && `${a.dialColor} dial`, a.caseSizeMm && `${a.caseSizeMm}mm`].filter(Boolean).join(', ');
  const prone = FAKE_PRONE.test(`${a.brand || ''} ${a.model || ''}`);
  const ident = [a.brand, a.model, a.modelNumber && `reference ${a.modelNumber}`].filter(Boolean).join(' ') || 'this watch';
  // Step 1 — web research only (no photos): what does the genuine watch look like, and what are the known fake tells?
  let research = '', rUrls = [];
  try {
    const rr = await callClaudeRaw([{ type: 'text', text: `Use web search to research authenticating this watch: ${claim || ident}.${prone ? ' This brand is heavily counterfeited.' : ''}
Find (from manufacturer pages, dealer/authentication guides, collector forums): (a) what a GENUINE one looks like: dial text and layout, font, logo/applied markers, date window and position, hands, lume, case and caseback engravings, serial/reference formats, crown/clasp logos, movement type, case size; (b) the KNOWN FAKE TELLS and common "frankenwatch" parts swaps for this brand/model.
Reply in plain prose with short bullet lines. Say which page each fact came from (url). Only report what retrieved pages state; if you find nothing for this exact reference, say so.` }], 3000, { tools: [{ type: 'web_search_20250305', name: 'web_search', max_uses: 5 }] });
    research = rr.text.slice(0, 6000); rUrls = rr.urls || [];
  } catch (e) { research = '(web research failed: ' + e.message + ')'; }
  // Step 2 — inspect the photos against that research. No tools, so the reply is the JSON and nothing else.
  const prompt = `AUTHENTICITY SCREEN for a pre-owned watch an eBay seller is about to list. The seller wants to avoid listing counterfeits or "frankenwatches" (genuine case with replaced dial/hands/movement parts).
Claimed identity (from earlier AI reading + seller): ${claim || 'unknown'}.${prone ? '\nThis brand is commonly counterfeited — be thorough.' : ''}
RESEARCH NOTES gathered from the web (use these as the genuine reference; they may be incomplete):
${research || '(none)'}

Do this:
1. TRANSCRIBE every piece of text you can actually read on the watch exactly as printed, letter for letter (dial, subdials, chapter ring, caseback, crown, clasp/buckle, strap/bracelet). Do not autocorrect: if a word is misspelled, transcribe the misspelling. Say "unreadable" for text too small/blurry — never fill in from what it "should" say.
2. Compare the photos with the research notes. Check: spelling/typos and wrong fonts; logo shape; text spacing/alignment and centering; date window/cyclops placement; hands vs. dial alignment; lume consistency; caseback engraving style and whether a caseback exists for this model; serial/reference number format; claimed movement vs. what is visible; crown, clasp and bracelet markings; finishing quality; mismatched parts (dial/hands/bezel/bracelet of different eras or models); signs of redial/aftermarket parts.
Rules: report only what you can see or what the research notes state. If a photo is too blurry or the right photo is missing (e.g. caseback, clasp, movement, crown), put it in "photosNeeded" and "couldNotCheck" — do NOT guess and do NOT say a watch is genuine. A lack of red flags is "low", not "authentic". Cheap price is not evidence either way. Be calibrated: "high" only for concrete evidence (misspelling, wrong font/logo, impossible feature, contradiction with the reference); "elevated" for suspicious or inconsistent details, or a heavily counterfeited brand with key photos missing; "undetermined" if the photos are too poor to judge.
Reply with ONE JSON object only — start with { and end with } — no prose, no code fence:
{"risk": "low|elevated|high|undetermined", "summary": "2-3 plain sentences for a non-expert", "textRead": {"dial": "", "caseback": "", "other": ""},
 "redFlags": [{"check": "e.g. Dial spelling", "detail": "what you saw vs what the genuine one has", "photo": 1, "severity": "high|medium|low"}],
 "passed": ["checks where the photos matched the genuine reference"],
 "couldNotCheck": ["what could not be checked and why"], "photosNeeded": ["e.g. Caseback straight-on, in focus"],
 "knownFakeTells": [{"tell": "tell collectors list for this model", "url": "https://..."}],
 "genuineReference": "1-2 sentences on what the genuine reference looks like", "sources": [{"title": "", "url": ""}]}`;
  let j, last;
  for (let t = 0; t < 3 && !j; t++) {
    try {
      const out = await callClaudeRaw([...content, { type: 'text', text: prompt + (t ? '\n\nYour last reply was not valid JSON. Reply with the single JSON object only, nothing else. Keep every string short.' : '') }], 6000);
      const m = out.text.match(/\{[\s\S]*\}/);
      if (!m) throw new Error(`no JSON in reply (stop: ${out.stop || 'n/a'}): "${(out.text || '(empty)').replace(/\s+/g, ' ').slice(0, 200)}"`);
      j = JSON.parse(m[0]);
    } catch (e) { last = e; }
  }
  if (j) {
    const seen = new Set((j.sources || []).map((s) => s.url));
    for (const u of rUrls.slice(0, 8)) if (!seen.has(u.url)) (j.sources = j.sources || []).push({ title: u.title, url: u.url });
  }
  if (!j) throw new Error('AI did not return usable JSON — ' + (last?.message || 'empty reply') + ' Press "Run authenticity check" to retry.');
  const arr = (x) => (Array.isArray(x) ? x : []);
  const res = {
    risk: ['low', 'elevated', 'high', 'undetermined'].includes(j.risk) ? j.risk : 'undetermined',
    summary: String(j.summary || ''), textRead: j.textRead || {},
    redFlags: arr(j.redFlags).map((f) => ({ check: String(f.check || ''), detail: String(f.detail || ''), photo: f.photo || null, severity: ['high', 'medium', 'low'].includes(f.severity) ? f.severity : 'medium' })),
    passed: arr(j.passed).map(String), couldNotCheck: arr(j.couldNotCheck).map(String), photosNeeded: arr(j.photosNeeded).map(String),
    knownFakeTells: arr(j.knownFakeTells).slice(0, 8), genuineReference: String(j.genuineReference || ''), sources: arr(j.sources).filter((s) => s && s.url).slice(0, 10),
    brandProne: prone, checkedAt: new Date().toISOString(),
  };
  const pf = priceFlag(d);
  if (pf) { res.redFlags.push({ check: 'Price far below market', detail: pf, photo: null, severity: 'medium' }); if (res.risk === 'low') res.risk = 'elevated'; }
  if (prone && res.risk === 'low' && res.photosNeeded.length) res.risk = 'elevated';
  if (res.redFlags.some((f) => f.severity === 'high') && res.risk !== 'high') res.risk = 'high';
  return res;
}

const processDraft = (id) => extras.als.run({ draft: id }, () => processDraftInner(id));
async function processDraftInner(id) {
  const d = updateDraft(id, { status: 'processing', stage: 'analyzing', error: null });
  if (!d) return;
  try {
    const images = d.photos.map((p) => ({ buffer: fs.readFileSync(path.join(draftDir(id), p.file)), mime: p.mime }));
    const u = d.userInput || {};
    const analysis = await analyzeImages(images, u);
    updateDraft(id, { analysis, title: analysis.suggestedTitle || '', stage: 'pricing' });

    let comps = null, compsError = null;
    try { comps = await findComps(analysis, images[0]); } catch (e) { compsError = e.message; }
    updateDraft(id, { comps: trimComps(comps), suggestion: comps?.suggestion || null, compsError, price: comps?.suggestion?.price ?? null, stage: 'researching' });

    const { specs, research, missingRequired } = await runResearch(analysis, comps?.active || [], null);
    let storeRef = null;
    try { storeRef = reference.lookup(REF_DIRS, analysis, specs); } catch { /* reference is optional */ }
    const fresh = readDraft(id) || {};
    const patch = { specs, research, missingRequired, storeRef, stage: 'writing' };
    updateDraft(id, { stage: 'webprice' });
    let web = null;
    try { web = await priceResearch(analysis, { research }); } catch (e) { web = { points: [], retail: [], notes: [e.message] }; }
    const sug = blendPrice({ comps, web, storeRef, own: (() => { try { return extras.soldLookup(analysis, specs); } catch { return null; } })() });
    patch.priceData = web;
    if (sug.price > 0) { patch.suggestion = sug; patch.price = sug.price; }
    if (u.modelNumber || u.model || u.brand) { // owner-typed values win over anything research found
      const sp = { ...specs };
      if (u.brand) sp.Brand = { value: u.brand, source: 'you', confidence: 'high' };
      if (u.modelNumber) sp['Reference Number'] = { value: u.modelNumber, source: 'you', confidence: 'high' };
      if (u.model) sp.Model = { value: u.model, source: 'you', confidence: 'high' };
      patch.specs = sp;
    }
    const withSpecs = updateDraft(id, patch);

    let listing;
    try { listing = await writeListing(withSpecs); } catch (e) {
      // Keep everything researched so far; only the text failed. The user can press "Rewrite description".
      const g = guaranteeFor(withSpecs.specs?.Movement?.value || analysis.movement);
      updateDraft(id, {
        description: g ? `<p style="font-size:16px;font-family:Arial,Helvetica,sans-serif;line-height:1.5;margin:0 0 16px">${esc(g)}</p>` : '',
        descError: e.message + (e.raw ? ` AI said: "${e.raw}"` : ''), descStale: true, tested: false,
        sku: d.sku || makeSku(analysis, id), status: 'ready', stage: null,
      });
      return;
    }
    updateDraft(id, { title: listing.title, description: listing.description, descError: null, descStale: false, tested: false, sku: d.sku || makeSku(analysis, id), status: 'ready', stage: null });
  } catch (e) {
    updateDraft(id, { status: 'error', stage: null, error: e.message });
  }
}


let workerRunning = false;
async function runQueue() {
  if (workerRunning) return;
  workerRunning = true;
  try {
    for (;;) {
      const queued = listDrafts().filter((d) => d.status === 'queued');
      if (!queued.length) break;
      const n = Math.max(1, parseInt(BATCH_CONCURRENCY, 10) || 2);
      await Promise.all(queued.slice(0, n).map((d) => processDraft(d.id)));
    }
  } finally { workerRunning = false; }
}

async function publishDraft(id) {
  let d = updateDraft(id, { status: 'publishing', error: null });
  if (!d) return;
  try {
    { // always upload the CURRENT photos (the enhanced copy when you saved one), never a cached set from an earlier attempt
      const urls = [];
      for (const p of d.photos) {
        const f = p.enhanced || p.file;
        urls.push(await uploadImageToEbay(fs.readFileSync(path.join(draftDir(id), f)), f, p.enhanced ? 'image/jpeg' : p.mime));
      }
      d = updateDraft(id, { imageUrls: urls });
    }
    const out = await publishListing({
      sku: d.sku, title: d.title, description: d.description, price: d.price,
      condition: d.condition, aspects: buildAspects(d), imageUrls: d.imageUrls,
    });
    updateDraft(id, { status: 'published', listingId: out.listingId, listingUrl: out.url, publishedEnv: EBAY_ENV, publishedAt: new Date().toISOString() });
  } catch (e) {
    updateDraft(id, { status: 'publish_error', error: e.message });
  }
}

let publishRunning = false;
async function runPublishQueue() { // one at a time — gentle on eBay rate limits
  if (publishRunning) return;
  publishRunning = true;
  try {
    for (;;) {
      const next = listDrafts().find((d) => d.status === 'publish_queued');
      if (!next) break;
      await publishDraft(next.id);
    }
  } finally { publishRunning = false; }
}

/* ---- routes ---- */
/** Photos dragged in from an eBay page arrive as a URL. Only eBay's own image host is fetched, https only, size-capped. */
async function downloadEbayImage(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('That dropped link is not a valid image address.'); }
  if (u.protocol !== 'https:' || !/(^|\.)ebayimg\.com$/i.test(u.hostname)) throw new Error('Only photos from eBay (ebayimg.com) can be added by dragging a web image. Save other photos to your Mac first.');
  u.pathname = u.pathname.replace(/\/s-l\d+\./, '/s-l1600.'); // ask for the large version
  const r = await fetch(u, { redirect: 'error' });
  if (!r.ok) throw new Error(`Could not download that photo (${r.status}).`);
  if (!/^image\//.test(r.headers.get('content-type') || '')) throw new Error('That link was not an image.');
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length > 15 * 1024 * 1024) throw new Error('That photo is too large.');
  return buf;
}
app.post('/api/drafts', upload.array('photos', 8), async (req, res) => {
  try {
    const urls = [].concat(req.body?.imageUrls || []).filter(Boolean).slice(0, 8);
    if (!req.files?.length && !urls.length) throw new Error('No photos uploaded');
    const photos = [];
    const buffers = [];
    for (const f of req.files || []) buffers.push(await normalizeImage(f.buffer));
    for (const u of urls) buffers.push(await normalizeImage(await downloadEbayImage(u)));
    const id = crypto.randomBytes(4).toString('hex');
    fs.mkdirSync(draftDir(id), { recursive: true });
    buffers.forEach((im, i) => {
      const file = `photo-${i}.${extFor(im.mime)}`;
      fs.writeFileSync(path.join(draftDir(id), file), im.buffer);
      photos.push({ file, mime: im.mime });
    });
    writeDraft({
      id, createdAt: new Date().toISOString(), status: 'queued', stage: null, error: null, photos,
      condition: STORE_DEFAULTS.conditionDefault, approved: false,
    });
    res.json({ ok: true, id });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});

app.get('/api/drafts', (_req, res) => res.json({ ok: true, env: EBAY_ENV, noPublish: NO_PUBLISH, drafts: listDrafts().map(decorate) }));

app.post('/api/drafts/process', (_req, res) => {
  const n = listDrafts().filter((d) => d.status === 'queued').length;
  runQueue().catch(() => {});
  res.json({ ok: true, queued: n });
});

app.post('/api/drafts/approve-clean', (_req, res) => {
  let n = 0;
  for (const d of listDrafts()) {
    if (d.status === 'ready' && !d.approved && !warningsFor(d).some((w) => w.blocking)) { updateDraft(d.id, { approved: true }); n++; }
  }
  res.json({ ok: true, approved: n });
});

app.post('/api/drafts/publish-approved', (_req, res) => {
  if (NO_PUBLISH) return res.status(403).json({ ok: false, error: 'Publishing is switched off in this test mode.' });
  const ready = listDrafts().filter((d) => d.status === 'ready' && d.approved && !hardBlock(d));
  ready.forEach((d) => updateDraft(d.id, { status: 'publish_queued', error: null }));
  runPublishQueue().catch(() => {});
  res.json({ ok: true, queued: ready.length, env: EBAY_ENV });
});

/** One-click "approve and publish" for a single listing (the guided flow). Same checks as approving + publishing. */
app.post('/api/drafts/:id/approve-publish', (req, res) => {
  if (NO_PUBLISH) return res.status(403).json({ ok: false, error: 'Publishing is switched off in this test mode.' });
  const d = readDraft(req.params.id);
  if (!d) return res.status(404).json({ ok: false, error: 'Not found' });
  if (d.status !== 'ready') return res.status(400).json({ ok: false, error: 'This watch is not ready to publish yet.' });
  const blocking = warningsFor(d).filter((w) => w.blocking);
  if (blocking.length || hardBlock(d)) return res.status(400).json({ ok: false, error: 'Fix this first: ' + (blocking[0]?.text || 'the title, price or description needs attention.') });
  const next = updateDraft(d.id, { approved: true, status: 'publish_queued', error: null });
  runPublishQueue().catch(() => {});
  res.json({ ok: true, draft: decorate(next), env: EBAY_ENV });
});

app.get('/api/drafts/:id', (req, res) => {
  const d = readDraft(req.params.id);
  d ? res.json({ ok: true, draft: decorate(d) }) : res.status(404).json({ ok: false, error: 'Not found' });
});

app.get('/api/drafts/:id/photo/:n', (req, res) => {
  const d = readDraft(req.params.id);
  const p = d?.photos?.[parseInt(req.params.n, 10)];
  if (!p) return res.status(404).end();
  const useEnh = p.enhanced && !req.query.orig;
  res.type(useEnh ? 'image/jpeg' : p.mime).set('Cache-Control', 'no-store').sendFile(path.join(draftDir(d.id), useEnh ? p.enhanced : p.file));
});

/** Browser-enhanced copy of one photo (JPEG body). The original is always kept. */
app.post('/api/drafts/:id/photo/:n/enhanced', express.raw({ type: '*/*', limit: '30mb' }), (req, res) => {
  try {
    const d = readDraft(req.params.id), n = parseInt(req.params.n, 10);
    const p = d?.photos?.[n];
    if (!p) return res.status(404).json({ ok: false, error: 'Not found' });
    if (!Buffer.isBuffer(req.body) || sniffMime(req.body) !== 'image/jpeg') throw new Error('Expected a JPEG image');
    const file = `enhanced-${n}.jpg`;
    fs.writeFileSync(path.join(draftDir(d.id), file), req.body);
    d.photos[n] = { ...p, enhanced: file };
    let adj = d.photoAdjust; try { adj = JSON.parse(req.get('X-Adjust') || 'null') || adj; } catch { /* keep old */ }
    res.json({ ok: true, draft: decorate(updateDraft(d.id, { photos: d.photos, photoAdjust: adj, pictureUrls: [], authenticity: null, authError: null })) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
app.post('/api/drafts/:id/photos/reset', (req, res) => {
  const d = readDraft(req.params.id);
  if (!d) return res.status(404).json({ ok: false, error: 'Not found' });
  for (const p of d.photos || []) { if (p.enhanced) { try { fs.rmSync(path.join(draftDir(d.id), p.enhanced), { force: true }); } catch { /* ignore */ } delete p.enhanced; } }
  res.json({ ok: true, draft: decorate(updateDraft(d.id, { photos: d.photos, photoAdjust: null, pictureUrls: [], authenticity: null, authError: null })) });
});

app.patch('/api/drafts/:id', async (req, res) => {
  const d = readDraft(req.params.id);
  if (!d) return res.status(404).json({ ok: false, error: 'Not found' });
  if (['processing', 'queued'].includes(d.status) && !d.analysis) { // before drafting: stock # and the owner's model name / number
    const bb = req.body || {}, af = bb.analysisFields || {};
    const keys = Object.keys(bb).filter((k) => k !== 'analysisFields');
    const okKeys = keys.every((k) => k === 'stockNumber') && Object.keys(af).every((k) => k === 'brand' || k === 'model' || k === 'modelNumber');
    if (okKeys && (keys.length || Object.keys(af).length)) {
      const patch = {};
      if (typeof bb.stockNumber === 'string') patch.stockNumber = bb.stockNumber.trim().slice(0, 60).slice(0, 30);
      if (d.status === 'queued' && Object.keys(af).length) {
        patch.userInput = { ...(d.userInput || {}) };
        for (const k of Object.keys(af)) { const v = String(af[k] ?? '').trim().slice(0, 60); if (v) patch.userInput[k] = v; else delete patch.userInput[k]; }
      } else if (Object.keys(af).length) return res.status(409).json({ ok: false, error: 'Drafting already started. Wait for it to finish, then edit and press Redo research.' });
      return res.json({ ok: true, draft: decorate(updateDraft(d.id, patch)) });
    }
  }
  if (['publishing', 'publish_queued', 'published', 'processing', 'queued'].includes(d.status)) {
    return res.status(409).json({ ok: false, error: `Can't edit while status is "${d.status}"` });
  }
  const b = req.body || {};
  const patch = {};
  const a = d.analysis ? { ...d.analysis, confidence: { ...(d.analysis.confidence || {}) } } : null;
  let afChanged = false; // confirming a value without changing it must not make the description stale
  if (b.analysisFields && a) {
    for (const k of ['brand', 'model', 'modelNumber', 'caseSizeMm']) {
      if (b.analysisFields[k] !== undefined) {
        const before = a[k];
        a[k] = k === 'caseSizeMm' ? (parseFloat(b.analysisFields[k]) || null) : String(b.analysisFields[k]);
        if (String(before ?? '') !== String(a[k] ?? '')) afChanged = true;
        a.confidence[k] = 1; // you verified it
      }
    }
  }
  if (b.specs && d.specs) { // { "Case Thickness": "12 mm", "Bezel Color": "" (remove) }
    const specs = { ...d.specs };
    for (const [k, v] of Object.entries(b.specs)) {
      const val = String(v ?? '').trim();
      if (!val) delete specs[k];
      else specs[k] = { value: val, source: 'you', confidence: 'high' };
      if (k === 'Movement' && a) a.movement = val || 'Unknown';
      if (k === 'Brand' && a) { a.brand = val; a.confidence.brand = 1; }
      if (k === 'Model' && a) { a.model = val; a.confidence.model = 1; }
      if (k === 'Reference Number' && a) a.modelNumber = val;
    }
    patch.missingRequired = applyTaxonomy(specs, await getTaxonomy());
    patch.specs = specs;
    if (d.description) patch.descStale = true;
  }
  if (a) { patch.analysis = a; if (d.specs && !b.specs && b.analysisFields) { /* analysis edits keep specs in step */
    const s = { ...d.specs };
    const sync = (n, v, extra) => { if (v) s[n] = { value: String(v) + (extra || ''), source: 'you', confidence: 'high' }; };
    if (b.analysisFields?.brand !== undefined) sync('Brand', a.brand);
    if (b.analysisFields?.model !== undefined) sync('Model', a.model);
    if (b.analysisFields?.modelNumber !== undefined) sync('Reference Number', a.modelNumber);
    if (b.analysisFields?.caseSizeMm !== undefined) sync('Case Size', a.caseSizeMm, ' mm');
    patch.specs = s; if (d.description && afChanged) patch.descStale = true;
  } }
  const mv = (patch.specs || d.specs)?.Movement?.value || a?.movement;
  if (typeof b.title === 'string') patch.title = cleanTitle(b.title.slice(0, 200), mv);
  if (b.price !== undefined) { const p = parseFloat(b.price); patch.price = p > 0 ? p : null; }
  if (typeof b.condition === 'string' && STORE_DEFAULTS.conditionMap[b.condition]) patch.condition = b.condition;
  if (typeof b.description === 'string') patch.description = b.description;
  if (typeof b.tested === 'boolean') patch.tested = b.tested;
  if (typeof b.sellerNotes === 'string') patch.sellerNotes = b.sellerNotes.slice(0, 2000);
  if (typeof b.stockNumber === 'string') { patch.stockNumber = b.stockNumber.trim().slice(0, 30); if (d.description) patch.descStale = true; }
  let next = updateDraft(d.id, patch);
  if (next.descStale && next.approved) next = updateDraft(d.id, { approved: false });
  if (typeof b.approved === 'boolean') {
    const ok = b.approved && next.status === 'ready' && !warningsFor(next).some((w) => w.blocking);
    return res.json({ ok: true, draft: decorate(updateDraft(d.id, { approved: ok })) });
  }
  if (b.tested === false || (patch.price === null)) updateDraft(d.id, { approved: false });
  res.json({ ok: true, draft: decorate(readDraft(d.id)) });
});

app.post('/api/drafts/:id/retry', (req, res) => {
  const d = readDraft(req.params.id);
  if (!d) return res.status(404).json({ ok: false, error: 'Not found' });
  if (d.status === 'error') { updateDraft(d.id, { status: 'queued', error: null }); runQueue().catch(() => {}); }
  else if (d.status === 'publish_error') { updateDraft(d.id, { status: 'ready', error: null, approved: false }); }
  res.json({ ok: true });
});

app.post('/api/drafts/:id/recomps', async (req, res) => {
  try {
    const d = readDraft(req.params.id);
    if (!d?.analysis) throw new Error('Nothing to price yet');
    const first = { buffer: fs.readFileSync(path.join(draftDir(d.id), d.photos[0].file)), mime: d.photos[0].mime };
    let c = null, compsError = null;
    try { c = await findComps(d.analysis, first); } catch (e) { compsError = e.message; }
    let web; try { web = await priceResearch(d.analysis, d); } catch (e) { web = { points: [], retail: [], notes: [e.message] }; }
    const sug = blendPrice({ comps: c, web, storeRef: d.storeRef, own: (() => { try { return extras.soldLookup(d.analysis, d.specs); } catch { return null; } })() });
    const out = updateDraft(d.id, { comps: c ? trimComps(c) : d.comps, compsError, priceData: web, suggestion: sug.price > 0 ? sug : d.suggestion, price: sug.price ?? d.price });
    res.json({ ok: true, draft: decorate(out) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

/** Re-run web + comp research (keeps anything you typed by hand). */
app.post('/api/drafts/:id/research', async (req, res) => {
  try {
    const d = readDraft(req.params.id);
    if (!d?.analysis) throw new Error('Nothing to research yet');
    const { specs, research, missingRequired } = await runResearch(d.analysis, d.comps?.active || [], d.specs);
    res.json({ ok: true, draft: decorate(updateDraft(d.id, { specs, research, missingRequired, descStale: !!d.description })) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/drafts/:id/rewrite', async (req, res) => {
  try {
    const d = readDraft(req.params.id);
    if (!d?.analysis) throw new Error('Nothing to describe yet');
    const { description, title } = await writeListing(d);
    res.json({ ok: true, draft: decorate(updateDraft(d.id, { description, title: d.title || title, descError: null, descStale: false })) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});


app.post('/api/drafts/:id/authenticity', async (req, res) => {
  try {
    const d = readDraft(req.params.id);
    if (!d?.analysis) throw new Error('Nothing to check yet');
    res.json({ ok: true, draft: decorate(updateDraft(d.id, { authenticity: await authenticityCheck(d), authError: null })) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

/* ------------------------------------------------------------------ */
/* eBay connection page API                                            */
/* ------------------------------------------------------------------ */
const ebayState = new Set();
app.get('/api/ebay/status', (_req, res) => {
  const st = ebaySettings(), tok = readJsonFile(EBAY_TOKEN_FILE, {}), pol = ebayPolicies(), warn = [];
  if (st.runame && /-PRD-/i.test(st.runame) && !IS_PROD) warn.push('Your RuName is a PRODUCTION one but EBAY_ENV is not PRODUCTION in .env — set EBAY_ENV=PRODUCTION and restart.');
  if (st.runame && /-SBX-/i.test(st.runame) && IS_PROD) warn.push('Your RuName is a SANDBOX one but EBAY_ENV is PRODUCTION.');
  res.json({ ok: true, env: EBAY_ENV, noPublish: NO_PUBLISH, hasKeys: !!(EBAY_CLIENT_ID && EBAY_CLIENT_SECRET), hasRuName: !!st.runame, connected: !!ebayRefreshToken(), connectedAt: tok.saved || null,
    policies: { fulfillment: pol.fulfillment || null, payment: pol.payment || null, returns: pol.returns || null }, locationKey: ebayLocationKey(), warn });
});
app.get('/ebay/connect', (_req, res) => {
  const st = ebaySettings();
  if (!EBAY_CLIENT_ID || !EBAY_CLIENT_SECRET) return res.status(400).send('EBAY_CLIENT_ID / EBAY_CLIENT_SECRET are not set in .env');
  if (!st.runame) return res.status(400).send('RuName is not set in ebay-settings.json');
  const state = crypto.randomBytes(8).toString('hex'); ebayState.add(state);
  const u = new URL(EBAY_AUTH_BASE + '/oauth2/authorize');
  u.search = new URLSearchParams({ client_id: EBAY_CLIENT_ID, response_type: 'code', redirect_uri: st.runame, scope: EBAY_USER_SCOPES.join(' '), state }).toString();
  res.redirect(u.toString());
});
const donePage = (ok, msg) => `<!doctype html><meta charset="utf-8"><title>eBay connection</title><body style="font-family:-apple-system,Arial;max-width:560px;margin:60px auto;padding:0 20px"><h2>${ok ? 'eBay connected' : 'Could not connect'}</h2><p>${esc(msg)}</p><p><a href="/ebay.html">Back to the eBay connection page</a></p></body>`;
app.get('/ebay/callback', async (req, res) => {
  try {
    if (req.query.error || req.query.error_id) throw new Error('eBay said: ' + (req.query.error_description || req.query.error || 'access declined'));
    if (!req.query.code) throw new Error('No code in the address.');
    await exchangeEbayCode(String(req.query.code));
    res.send(donePage(true, 'Your seller account is connected. You can close this tab.'));
  } catch (e) { res.status(400).send(donePage(false, e.message)); }
});
app.post('/api/ebay/exchange', async (req, res) => { // fallback: paste the address eBay sent you to (or just the code)
  try {
    let v = String(req.body?.code || '').trim(); if (!v) throw new Error('Paste the address from your browser or the code.');
    try { const c = new URL(v).searchParams.get('code'); if (c) v = c; } catch { /* plain code */ }
    await exchangeEbayCode(decodeURIComponent(v));
    res.json({ ok: true });
  } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
});
app.get('/api/ebay/test', async (_req, res) => {
  const out = [];
  const step = async (name, fn) => { try { out.push({ name, ok: true, detail: String(await fn()) }); } catch (e) { out.push({ name, ok: false, detail: e.message }); } };
  await step('App keys (Client ID / Secret)', async () => { await getAppToken(); return 'eBay accepted your keys'; });
  await step('Search other sellers\' watches (Browse API)', async () => {
    const r = await fetch(`${EBAY_BASE}/buy/browse/v1/item_summary/search?q=${encodeURIComponent('seiko watch')}&category_ids=${STORE_DEFAULTS.categoryId}&limit=3`, { headers: { Authorization: 'Bearer ' + await getAppToken(), 'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US' } });
    const j = await r.json(); if (j.errors) throw new Error(j.errors[0].message); return `${(j.itemSummaries || []).length} results (total ${j.total ?? '?'})`;
  });
  await step('Item-specific rules (Taxonomy API)', async () => { const t = await getTaxonomy(); if (!t) throw new Error('eBay returned no data (check the keys or the category id)'); return `${Object.keys(t).length} item-specific rules loaded`; });
  await step('Sold-price data (Marketplace Insights)', async () => {
    const r = await fetch(`${EBAY_BASE}/buy/marketplace_insights/v1_beta/item_sales/search?q=${encodeURIComponent('seiko watch')}&limit=1`, { headers: { Authorization: 'Bearer ' + await getAppToken(), 'X-EBAY-C-MARKETPLACE-ID': 'EBAY_US' } });
    if (!r.ok) throw new Error(`not available (HTTP ${r.status}) — expected unless eBay approved you for it`); return 'available';
  });
  if (ebayRefreshToken()) {
    await step('Your seller sign-in', async () => { await getUserToken(); return 'token refreshed'; });
    await step('Your business policies', async () => { const p = await ebayUserGet('/sell/account/v1/fulfillment_policy?marketplace_id=EBAY_US'); return `${(p.fulfillmentPolicies || []).length} shipping polic${(p.fulfillmentPolicies || []).length === 1 ? 'y' : 'ies'} found`; });
    await step('Inventory location', async () => { const l = await ebayUserGet('/sell/inventory/v1/location?limit=20'); const keys = (l.locations || []).map((x) => x.merchantLocationKey); return keys.length ? 'found: ' + keys.join(', ') : 'none yet — press "Create Boise location"'; });
  } else out.push({ name: 'Your seller sign-in', ok: false, detail: 'Not connected yet — press Connect eBay.' });
  res.json({ ok: true, env: EBAY_ENV, results: out });
});
app.get('/api/ebay/policies', async (_req, res) => {
  try {
    const [f, p, r] = await Promise.all(['fulfillment_policy', 'payment_policy', 'return_policy'].map((k) => ebayUserGet(`/sell/account/v1/${k}?marketplace_id=EBAY_US`)));
    res.json({ ok: true,
      fulfillment: (f.fulfillmentPolicies || []).map((x) => ({ id: x.fulfillmentPolicyId, name: x.name })),
      payment: (p.paymentPolicies || []).map((x) => ({ id: x.paymentPolicyId, name: x.name })),
      returns: (r.returnPolicies || []).map((x) => ({ id: x.returnPolicyId, name: x.name })), chosen: ebayPolicies() });
  } catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});
app.post('/api/ebay/settings', (req, res) => {
  const b = req.body || {}, cur = ebaySettings(), pick = (k) => (typeof b[k] === 'string' && /^[A-Za-z0-9_-]{0,64}$/.test(b[k]) ? b[k] : cur[k]);
  const next = { ...cur, fulfillmentPolicyId: pick('fulfillmentPolicyId'), paymentPolicyId: pick('paymentPolicyId'), returnPolicyId: pick('returnPolicyId'), merchantLocationKey: pick('merchantLocationKey') };
  fs.writeFileSync(EBAY_SETTINGS_FILE, JSON.stringify(next, null, 2));
  res.json({ ok: true });
});
app.get('/api/ebay/programs', async (_req, res) => {
  try { const p = await ebayUserGet('/sell/account/v1/program/get_opted_in_programs'); res.json({ ok: true, programs: (p.programs || []).map((x) => x.programType), policyManagement: (p.programs || []).some((x) => x.programType === 'SELLING_POLICY_MANAGEMENT') }); }
  catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});
app.post('/api/ebay/optin', async (_req, res) => { // opts the connected seller account in to Business Policies (shipping/payment/returns policies)
  try {
    const token = await getUserToken();
    const r = await fetch(`${EBAY_BASE}/sell/account/v1/program/opt_in`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Language': 'en-US', 'Accept-Language': 'en-US' }, body: JSON.stringify({ programType: 'SELLING_POLICY_MANAGEMENT' }) });
    const t = await r.text();
    if (![200, 201, 204].includes(r.status)) { let j = null; try { j = JSON.parse(t); } catch { /* not json */ } const e0 = j?.errors?.[0]; throw new Error(`${r.status} ${e0 ? [e0.errorId && ('errorId ' + e0.errorId), e0.message, e0.longMessage].filter(Boolean).join(' | ') : t.slice(0, 300)}`); }
    res.json({ ok: true });
  } catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});
app.post('/api/ebay/policies/create', async (_req, res) => { // creates a shipping, payment and returns policy from the CSV export settings (only for types that have none yet)
  try {
    const token = await getUserToken(), ex = exportSettings(), cur = ebaySettings(), done = [], ids = {};
    const call = async (method, p, body) => {
      const r = await fetch(`${EBAY_BASE}${p}`, { method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Language': 'en-US', 'Accept-Language': 'en-US' }, body: body ? JSON.stringify(body) : undefined });
      const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch { /* not json */ }
      if (!r.ok) { const e0 = j?.errors?.[0]; throw new Error(`${r.status} ${e0 ? [e0.errorId && ('errorId ' + e0.errorId), e0.message, e0.longMessage, (e0.parameters || []).map((q) => q.name + '=' + q.value).join(', ')].filter(Boolean).join(' | ') : t.slice(0, 300)}`); }
      return j;
    };
    const cat = [{ name: 'ALL_EXCLUDING_MOTORS_VEHICLES', default: true }], mk = 'EBAY_US';
    const [f, p, r] = await Promise.all(['fulfillment_policy', 'payment_policy', 'return_policy'].map((k) => ebayUserGet(`/sell/account/v1/${k}?marketplace_id=${mk}`)));
    if (!(f.fulfillmentPolicies || []).length) {
      const j = await call('POST', '/sell/account/v1/fulfillment_policy', { name: 'BK Flat Rate USPS', marketplaceId: mk, categoryTypes: cat, handlingTime: { unit: 'DAY', value: Number(ex.dispatchTimeMax) || 3 },
        shippingOptions: [{ optionType: 'DOMESTIC', costType: 'FLAT_RATE', shippingServices: [{ sortOrder: 1, shippingCarrierCode: 'USPS', shippingServiceCode: ex.shippingService1Option || 'USPSParcel', shippingCost: { currency: 'USD', value: String(ex.shippingService1Cost || '6.49') }, freeShipping: false }] }] });
      ids.fulfillmentPolicyId = j.fulfillmentPolicyId; done.push('shipping policy created');
    } else done.push('shipping policy already exists — left alone');
    if (!(p.paymentPolicies || []).length) {
      const j = await call('POST', '/sell/account/v1/payment_policy', { name: 'BK Payment', marketplaceId: mk, categoryTypes: cat, immediatePay: true });
      ids.paymentPolicyId = j.paymentPolicyId; done.push('payment policy created');
    } else done.push('payment policy already exists — left alone');
    if (!(r.returnPolicies || []).length) {
      const j = await call('POST', '/sell/account/v1/return_policy', { name: 'BK No Returns', marketplaceId: mk, categoryTypes: cat, returnsAccepted: false });
      ids.returnPolicyId = j.returnPolicyId; done.push('returns policy created');
    } else done.push('returns policy already exists — left alone');
    const next = { ...cur }; for (const [k, v] of Object.entries(ids)) if (v && !cur[k]) next[k] = v;
    fs.writeFileSync(EBAY_SETTINGS_FILE, JSON.stringify(next, null, 2));
    res.json({ ok: true, done });
  } catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});
app.get('/api/ebay/location', async (_req, res) => {
  try { const key = ebayLocationKey(), l = await ebayUserGet(`/sell/inventory/v1/location/${encodeURIComponent(key)}`); res.json({ ok: true, key, name: l.name, address: l.location?.address || {}, status: l.merchantLocationStatus }); }
  catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});
app.post('/api/ebay/location/nozip', async (_req, res) => { // keeps city/state/country, removes the postal code from the saved ship-from location
  try {
    const key = ebayLocationKey(), token = await getUserToken();
    const r = await fetch(`${EBAY_BASE}/sell/inventory/v1/location/${encodeURIComponent(key)}/update_location_details`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Language': 'en-US', 'Accept-Language': 'en-US' },
      body: JSON.stringify({ location: { address: { city: 'Boise', stateOrProvince: 'ID', country: 'US' } }, name: 'B and K Watches' }),
    });
    if (![200, 201, 204].includes(r.status)) { const t = await r.text(); throw new Error(`${r.status} ${t.slice(0, 300)}`); }
    const l = await ebayUserGet(`/sell/inventory/v1/location/${encodeURIComponent(key)}`);
    res.json({ ok: true, address: l.location?.address || {} });
  } catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});
app.post('/api/ebay/location', async (req, res) => {
  try {
    const key = ebayLocationKey(), token = await getUserToken(), zip = String(req.body?.postalCode || '').trim();
    const address = { city: 'Boise', stateOrProvince: 'ID', country: 'US', ...(zip ? { postalCode: zip } : {}) };
    const r = await fetch(`${EBAY_BASE}/sell/inventory/v1/location/${encodeURIComponent(key)}`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'Content-Language': 'en-US', 'Accept-Language': 'en-US' },
      body: JSON.stringify({ location: { address }, name: 'B and K Watches', merchantLocationStatus: 'ENABLED', locationTypes: ['WAREHOUSE'] }),
    });
    if (![200, 201, 204].includes(r.status)) { const t = await r.text(); if (/25803/.test(t)) return res.json({ ok: true, key, existed: true }); throw new Error(`${r.status} ${t.slice(0, 300)}`); }
    res.json({ ok: true, key });
  } catch (e) { res.status(502).json({ ok: false, error: e.message }); }
});

/* ------------------------------------------------------------------ */
/* Background-removal model (IS-Net "general use", ONNX). Downloaded    */
/* once to your data folder, then served to the page, which runs it     */
/* locally in the browser — your photos never leave your computer.     */
/* ------------------------------------------------------------------ */
const BG_MODEL_URL = 'https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx';
const BG_MODEL_FILE = path.join(DATA_DIR, 'models', 'isnet-general-use.onnx');
const bgState = { downloading: false, bytes: 0, total: 0, error: null };
const bgReady = () => { try { return fs.statSync(BG_MODEL_FILE).size > 150e6; } catch { return false; } };
async function downloadBgModel() {
  if (bgState.downloading || bgReady()) return;
  Object.assign(bgState, { downloading: true, bytes: 0, total: 0, error: null });
  try {
    fs.mkdirSync(path.dirname(BG_MODEL_FILE), { recursive: true });
    const r = await fetch(BG_MODEL_URL);
    if (!r.ok) throw new Error('Download failed: HTTP ' + r.status);
    bgState.total = Number(r.headers.get('content-length')) || 0;
    const part = BG_MODEL_FILE + '.part', out = fs.createWriteStream(part);
    const reader = r.body.getReader();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      bgState.bytes += value.length;
      if (!out.write(value)) await new Promise((res) => out.once('drain', res));
    }
    await new Promise((res, rej) => { out.end(); out.on('finish', res); out.on('error', rej); });
    if (fs.statSync(part).size < 150e6) throw new Error('Downloaded file looks incomplete');
    fs.renameSync(part, BG_MODEL_FILE);
  } catch (e) { bgState.error = e.message; }
  bgState.downloading = false;
}
app.get('/api/bgmodel', (_req, res) => res.json({ ok: true, ready: bgReady(), ...bgState }));
app.post('/api/bgmodel/download', (_req, res) => { downloadBgModel(); res.json({ ok: true, ready: bgReady(), ...bgState, downloading: !bgReady() }); });
app.get('/models/isnet-general-use.onnx', (_req, res) => bgReady() ? res.set('Cache-Control', 'max-age=86400').sendFile(BG_MODEL_FILE) : res.status(404).end());

app.post('/api/drafts/:id/cleanup-photos', async (req, res) => {
  try {
    const d = readDraft(req.params.id);
    if (!d) return res.status(404).json({ ok: false, error: 'Not found' });
    res.json({ ok: true, draft: decorate(await cleanupPhotos(d, exportSettings())) });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.delete('/api/drafts/:id', (req, res) => {
  const d = readDraft(req.params.id);
  if (!d) return res.status(404).json({ ok: false, error: 'Not found' });
  if (['processing', 'publishing', 'publish_queued'].includes(d.status)) return res.status(409).json({ ok: false, error: 'Busy — try again in a moment' });
  fs.rmSync(draftDir(d.id), { recursive: true, force: true });
  res.json({ ok: true });
});

function lanUrls(port) {
  return Object.values(os.networkInterfaces()).flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => `http://${i.address}:${port}`);
}



/* Free photo hosting (Cloudinary, unsigned preset) so the upload CSV can carry photo links without eBay API keys. */
async function hostPhotos(d, st, notes) {
  if (d.pictureUrls?.length) return d.pictureUrls;
  const cloud = process.env.CLOUDINARY_CLOUD_NAME || st.cloudinaryCloudName, preset = process.env.CLOUDINARY_UPLOAD_PRESET || st.cloudinaryUploadPreset;
  if (!cloud || !preset) return [];
  const urls = [], ids = [];
  for (const p of d.photos || []) {
    const form = new FormData();
    form.append('file', new Blob([fs.readFileSync(path.join(draftDir(d.id), p.enhanced || p.file))], { type: p.enhanced ? 'image/jpeg' : (p.mime || 'image/jpeg') }), p.enhanced || p.file);
    form.append('upload_preset', preset);
    form.append('folder', 'bandk');
    const r = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/image/upload`, { method: 'POST', body: form });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.secure_url) throw new Error(`Photo hosting failed for ${d.sku || d.id}: ${j.error?.message || r.status}`);
    urls.push(j.secure_url); ids.push(j.public_id);
  }
  if (urls.length) updateDraft(d.id, { pictureUrls: urls, pictureIds: ids, photosCleanedAt: null });
  return urls;
}
// Mild auto-enhance is applied through the picture link, so the stored originals stay untouched.
function enhanceUrl(url, st) {
  const t = String(st.cloudinaryTransform || '').trim().replace(/^\/|\/$/g, '');
  return t && /\/image\/upload\//.test(url) ? url.replace('/image/upload/', `/image/upload/${t}/`) : url;
}
async function cleanupPhotos(d, st) {
  const cloud = process.env.CLOUDINARY_CLOUD_NAME || st.cloudinaryCloudName;
  const key = process.env.CLOUDINARY_API_KEY || st.cloudinaryApiKey, secret = process.env.CLOUDINARY_API_SECRET || st.cloudinaryApiSecret;
  if (!cloud || !key || !secret) throw new Error('Cloudinary API key and secret are not set yet. Add them to export-settings.json (cloudinaryApiKey / cloudinaryApiSecret) and restart the app.');
  const ids = d.pictureIds || [];
  if (!ids.length) throw new Error('No hosted photos to clean up for this listing.');
  const qs = ids.map((i) => 'public_ids[]=' + encodeURIComponent(i)).join('&') + '&invalidate=true';
  const r = await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/resources/image/upload?${qs}`, { method: 'DELETE', headers: { Authorization: 'Basic ' + Buffer.from(`${key}:${secret}`).toString('base64') } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Cloudinary said: ${j.error?.message || r.status}`);
  const bad = Object.entries(j.deleted || {}).filter(([, v]) => v !== 'deleted' && v !== 'not_found');
  if (bad.length) throw new Error('Cloudinary could not delete: ' + bad.map(([k, v]) => `${k} (${v})`).join(', '));
  return updateDraft(d.id, { pictureUrls: [], pictureIds: [], photosCleanedAt: new Date().toISOString() });
}
app.get('/api/export.csv', async (req, res) => {
  const ids = String(req.query.ids || '').split(',').filter(Boolean);
  const list = listDrafts().filter((d) => d.status === 'ready' && (ids.length ? ids.includes(d.id) : d.approved)).filter((d) => !hardBlock(decorate(d)));
  if (!list.length) return res.status(400).json({ ok: false, error: 'No approved listings to export.' });
  let out;
  try {
    const st = exportSettings(), hostNotes = [];
    for (const d of list) d.pictureUrls = (await hostPhotos(d, st, hostNotes)).map((u) => enhanceUrl(u, st));
    out = buildUploadCsv(list.map(decorate));
  } catch (e) { return res.status(502).json({ ok: false, error: e.message }); }
  for (const d of list) updateDraft(d.id, { exportedAt: new Date().toISOString() });
  const name = `BandK-upload-${new Date().toISOString().slice(0, 10)}-${list.length}.csv`;
  try { // keep a copy somewhere easy to find
    const outDir = path.join(os.homedir(), 'Desktop', 'BandK eBay Uploads'); fs.mkdirSync(outDir, { recursive: true });
    for (const f of fs.readdirSync(outDir)) { // only the newest upload CSV stays in this folder
      if (/\.csv$/i.test(f)) { try { const p = path.join(outDir, f); if (fs.statSync(p).isFile()) fs.unlinkSync(p); } catch { /* skip files that can't be removed */ } }
    }
    const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
    fs.writeFileSync(path.join(outDir, `BandK-upload-${stamp}.csv`), out.csv);
    out.notes.unshift('Saved on your Desktop in "BandK eBay Uploads" (older CSVs in that folder were deleted).');
  } catch { /* browser download still works */ }
  res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${name}"`, 'X-Export-Notes': encodeURIComponent(JSON.stringify(out.notes)), 'Access-Control-Expose-Headers': 'X-Export-Notes' });
  res.send(out.csv);
});
app.get('/api/reference', (_req, res) => res.json({ ok: true, ...reference.summary(REF_DIRS), folders: REF_DIRS }));
app.get('/api/config', (_req, res) => res.json({
  version: extras.APP_VERSION,
  env: EBAY_ENV,
  noPublish: NO_PUBLISH,
  model: ANTHROPIC_MODEL,
  hasAnthropicKey: !!ANTHROPIC_API_KEY,
  hasEbayKeys: !!(EBAY_CLIENT_ID && EBAY_CLIENT_SECRET),
  hasUserToken: !!ebayRefreshToken(),
  hasPolicies: (() => { const p = ebayPolicies(); return !!(p.fulfillment && p.payment && p.returns); })(),
  dataDir: DATA_DIR,
  defaults: STORE_DEFAULTS,
  guarantee: GUARANTEE,
}));

require('./listedit').install(app, { getUserToken, uploadImageToEbay, DATA_DIR, EBAY_BASE, noPublish: NO_PUBLISH });

app.use((err, _req, res, _next) => res.status(400).json({ ok: false, error: err.message || 'Request failed' }));

/* ---- startup: recover anything interrupted by a restart ---- */
for (const d of listDrafts()) {
  if (d.status === 'processing') updateDraft(d.id, { status: 'queued', stage: null });
  if (d.status === 'publishing' || d.status === 'publish_queued') {
    updateDraft(d.id, { status: 'publish_error', error: 'Interrupted by a restart — check Seller Hub before retrying so you do not double-list.' });
  }
}

const PORT = process.env.PORT || 3456;
const HOST = process.env.HOST || (extras.lanEnabled() ? '0.0.0.0' : '127.0.0.1'); // Settings page → iPad access turns this on (with a PIN)
process.env.__BK_LISTEN_HOST = HOST;
function listenWithRetry(n) {
  const srv = app.listen(PORT, HOST, onListening);
  srv.on('error', (e) => { if (e.code === 'EADDRINUSE' && n < 20) setTimeout(() => listenWithRetry(n + 1), 500); else throw e; }); // a restart waits for the old copy to let go of the port
}
function onListening() {
  console.log(`B and K Listing Builder → http://localhost:${PORT}  [eBay: ${EBAY_ENV}]  [model: ${ANTHROPIC_MODEL}]`);
  if (HOST === '0.0.0.0') lanUrls(PORT).forEach((u) => console.log('   iPad / other device on your Wi-Fi →', u));
  console.log('   Drafts saved in', DATA_DIR);
}
listenWithRetry(0);
