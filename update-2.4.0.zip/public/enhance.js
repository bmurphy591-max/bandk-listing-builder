/* Shared photo enhancer (copied from the Watch queue page): auto-levels, brightness/contrast/colour/sharpness, optional AI white background. */
const DEF_ADJ={auto:true,b:40,c:0,s:0,sh:100,wb:false,wt:10},PE={};
/* ---------- AI background removal (IS-Net via onnxruntime-web, all local) ---------- */
const ORT_BASE='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.22.0/dist/',MASKS=new WeakMap(),MASK_SCALED=new WeakMap();let ortSession=null;
async function bgEngine(say){
  if(ortSession)return ortSession;
  say('Loading the cut-out engine…');
  if(!window.ort)await new Promise((res,rej)=>{const s=document.createElement('script');s.src=ORT_BASE+'ort.wasm.min.js';s.onload=res;s.onerror=()=>rej(new Error('Could not load the cut-out engine (internet needed the first time).'));document.head.appendChild(s)});
  ort.env.wasm.wasmPaths=ORT_BASE;
  let st=await(await fetch('/api/bgmodel')).json();
  if(!st.ready){st=await(await fetch('/api/bgmodel/download',{method:'POST'})).json();
    while(!st.ready){if(st.error)throw new Error(st.error);say(`Downloading the cut-out model, one time only… ${Math.round((st.bytes||0)/1e6)} of ${st.total?Math.round(st.total/1e6):'~175'} MB`);await new Promise(r=>setTimeout(r,1000));st=await(await fetch('/api/bgmodel')).json()}}
  say('Loading the cut-out model…');
  const buf=await(await fetch('/models/isnet-general-use.onnx')).arrayBuffer();
  ortSession=await ort.InferenceSession.create(buf,{executionProviders:['wasm']});return ortSession;
}
async function runMask(img){
  const S=1024,cv=document.createElement('canvas');cv.width=cv.height=S;const cx=cv.getContext('2d',{willReadFrequently:true});cx.drawImage(img,0,0,S,S);
  const d=cx.getImageData(0,0,S,S).data,n=S*S,f=new Float32Array(3*n);let mx=1;for(let i=0;i<d.length;i+=4)for(let c=0;c<3;c++)if(d[i+c]>mx)mx=d[i+c];
  for(let i=0;i<n;i++){f[i]=d[i*4]/mx-.5;f[n+i]=d[i*4+1]/mx-.5;f[2*n+i]=d[i*4+2]/mx-.5}
  const out=await ortSession.run({[ortSession.inputNames[0]]:new ort.Tensor('float32',f,[1,3,S,S])});
  const o=out[ortSession.outputNames[0]].data;let lo=1e9,hi=-1e9;for(let i=0;i<n;i++){if(o[i]<lo)lo=o[i];if(o[i]>hi)hi=o[i]}
  const m=new Float32Array(n),r=hi-lo||1;for(let i=0;i<n;i++)m[i]=(o[i]-lo)/r;return m;
}
function scaledMask(img,w,h){
  let c=MASK_SCALED.get(img);if(!c){c=new Map();MASK_SCALED.set(img,c)}const k=w+'x'+h;if(c.has(k))return c.get(k);
  const m=MASKS.get(img),S=1024,mc=document.createElement('canvas');mc.width=mc.height=S;const mx=mc.getContext('2d'),id=mx.createImageData(S,S);
  for(let i=0;i<S*S;i++){const v=Math.round(m[i]*255);id.data[i*4]=v;id.data[i*4+1]=v;id.data[i*4+2]=v;id.data[i*4+3]=255}mx.putImageData(id,0,0);
  const sc=document.createElement('canvas');sc.width=w;sc.height=h;const sx=sc.getContext('2d',{willReadFrequently:true});sx.imageSmoothingQuality='high';sx.drawImage(mc,0,0,w,h);
  const d=sx.getImageData(0,0,w,h).data,out=new Float32Array(w*h);for(let i=0;i<w*h;i++)out[i]=d[i*4]/255;c.set(k,out);return out;
}
function enhanceCanvas(img,adj,maxW){
  const sc=Math.min(1,maxW/img.naturalWidth),w=Math.max(1,Math.round(img.naturalWidth*sc)),hh=Math.max(1,Math.round(img.naturalHeight*sc));
  const cv=document.createElement('canvas');cv.width=w;cv.height=hh;const ctx=cv.getContext('2d',{willReadFrequently:true});
  ctx.drawImage(img,0,0,w,hh);const id=ctx.getImageData(0,0,w,hh),px=id.data,n=w*hh;
  let lo=0,hi=255;
  if(adj.auto){const hist=new Uint32Array(256);for(let i=0;i<px.length;i+=4)hist[(px[i]*299+px[i+1]*587+px[i+2]*114)/1000|0]++;
    let a=0;while(lo<255&&(a+=hist[lo])<n*.01)lo++;a=0;hi=255;while(hi>0&&(a+=hist[hi])<n*.01)hi--;
    lo=Math.min(lo,50);hi=Math.max(hi,205);}
  const k=1+adj.c/100,bAdd=adj.b*1.28,sat=1+adj.s/100,stretch=255/(hi-lo),mix=adj.auto?.7:0;
  for(let i=0;i<px.length;i+=4){
    let r=px[i],g=px[i+1],b=px[i+2];
    if(mix){r+=((r-lo)*stretch-r)*mix;g+=((g-lo)*stretch-g)*mix;b+=((b-lo)*stretch-b)*mix}
    if(sat!==1){const l=.299*r+.587*g+.114*b;r=l+(r-l)*sat;g=l+(g-l)*sat;b=l+(b-l)*sat}
    px[i]=(r-128)*k+128+bAdd;px[i+1]=(g-128)*k+128+bAdd;px[i+2]=(b-128)*k+128+bAdd;
  }
  if(adj.sh>0){ // unsharp mask against a 3x3 box blur
    const src=new Uint8ClampedArray(px),tmp=new Uint8ClampedArray(px.length),amt=adj.sh/100*1.5;
    for(let y=0;y<hh;y++)for(let x=0;x<w;x++){const o=(y*w+x)*4,xl=(x>0?o-4:o),xr=(x<w-1?o+4:o);for(let c=0;c<3;c++)tmp[o+c]=(src[xl+c]+src[o+c]+src[xr+c])/3}
    for(let y=0;y<hh;y++){const yu=y>0?y-1:y,yd=y<hh-1?y+1:y;for(let x=0;x<w;x++){const o=(y*w+x)*4,u=(yu*w+x)*4,d=(yd*w+x)*4;
      for(let c=0;c<3;c++){const bl=(tmp[u+c]+tmp[o+c]+tmp[d+c])/3;px[o+c]=src[o+c]+(src[o+c]-bl)*amt}}}
  }
  if(adj.wb&&MASKS.has(img)){const m=scaledMask(img,w,hh),c0=(adj.wt||0)/100,den=Math.max(.2,.92-c0);
    for(let i=0,p=0;i<n;i++,p+=4){let a=(m[i]-c0)/den;a=a<0?0:a>1?1:a;a=a*a*(3-2*a);if(a<1){const b=1-a;px[p]=px[p]*a+255*b;px[p+1]=px[p+1]*a+255*b;px[p+2]=px[p+2]*a+255*b}}}
  ctx.putImageData(id,0,0);return cv;
}
