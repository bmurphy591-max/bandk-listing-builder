/**
 * Store reference — reads eBay "active listings" CSV reports dropped into the  reference/  folder
 * (the app folder's own reference/ plus  <data folder>/reference/ ) and offers:
 *   - similar listings (same brand / model / reference number) for title STYLE and as research
 *   - price benchmarks from the store's own listings
 *   - duplicate warnings
 * It is one source among several; nothing here overrides photos, web research or eBay data.
 */
const fs = require('fs');
const path = require('path');

function parseCsv(text) {
  const rows = []; let row = [], f = '', q = false;
  text = text.replace(/^﻿/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(f); f = ''; }
    else if (c === '\n' || (c === '\r' && text[i + 1] !== '\n')) { row.push(f); rows.push(row); row = []; f = ''; }
    else if (c !== '\r') f += c;
  }
  if (f || row.length) { row.push(f); rows.push(row); }
  return rows;
}

const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
const words = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9' ]+/g, ' ').split(/\s+/).filter((w) => w.length > 1);
const median = (a) => { const s = [...a].sort((x, y) => x - y); const m = s.length >> 1; return s.length ? (s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2) : null; };

let cache = { key: '', listings: [], files: [] };

function load(dirs) {
  const files = [];
  for (const d of dirs) { try { for (const f of fs.readdirSync(d)) if (/\.csv$/i.test(f) && !/template/i.test(f)) files.push(path.join(d, f)); } catch { /* folder missing */ } }
  const key = files.map((f) => { try { const s = fs.statSync(f); return f + s.size + s.mtimeMs; } catch { return f; } }).join('|');
  if (key === cache.key) return cache;
  const seen = new Set(), listings = [];
  for (const f of files) {
    let rows; try { rows = parseCsv(fs.readFileSync(f, 'utf8')); } catch { continue; }
    if (!rows.length) continue;
    const h = rows[0].map((x) => x.trim().toLowerCase());
    const col = (name) => h.indexOf(name);
    const iT = col('title'), iId = col('item number'), iP = col('current price') >= 0 ? col('current price') : col('start price'), iC = col('condition'), iSku = col('custom label (sku)'), iD = col('start date');
    if (iT < 0) continue; // not a listings report
    for (const r of rows.slice(1)) {
      const title = (r[iT] || '').trim(); if (!title) continue;
      const id = iId >= 0 ? r[iId] : '';
      if (id && seen.has(id)) continue; if (id) seen.add(id);
      listings.push({ id, title, price: parseFloat(r[iP]) || null, condition: iC >= 0 ? r[iC] : '', sku: iSku >= 0 ? r[iSku] : '', start: iD >= 0 ? r[iD] : '', t: norm(title), w: new Set(words(title)) });
    }
  }
  cache = { key, listings, files: files.map((f) => path.basename(f)) };
  return cache;
}

/** Find the store's own listings most like this watch. a = analysis {brand, model, modelNumber, gender} */
function lookup(dirs, a, specs) {
  const { listings, files } = load(dirs);
  const brand = norm(a.brand), ref = norm(a.modelNumber || specs?.['Reference Number']?.value), model = words(a.model || specs?.Model?.value);
  if (!listings.length || !brand) return { available: listings.length > 0, files, n: listings.length, similar: [], sameBrand: 0 };
  const bw = words(a.brand);
  const scored = [];
  let sameBrand = 0;
  for (const l of listings) {
    const isBrand = l.t.startsWith(brand) || (bw.length && bw.every((w) => l.w.has(w)));
    if (!isBrand) continue;
    sameBrand++;
    let s = 1;
    const refHit = ref.length >= 3 && l.t.includes(ref);
    if (refHit) s += 6;
    for (const w of model) if (w.length > 2 && l.w.has(w)) s += 2;
    if (/women/i.test(a.gender || '') ? l.w.has('womens') || l.w.has('women') || l.w.has('ladies') : /^men/i.test(a.gender || '') ? l.w.has('mens') || l.w.has('men') : false) s += 1;
    scored.push({ l, s, refHit });
  }
  scored.sort((x, y) => y.s - x.s);
  const similar = scored.slice(0, 8).map(({ l, s, refHit }) => ({ id: l.id, title: l.title, price: l.price, condition: l.condition, score: s, refHit }));
  const prices = (arr) => arr.map((x) => x.l.price).filter((p) => p > 0);
  const strong = scored.filter((x) => x.s >= 4), brandPrices = prices(scored);
  const out = { available: true, files, n: listings.length, sameBrand, similar };
  if (strong.length >= 2) out.medianPrice = median(prices(strong)), out.priceBasis = `${strong.length} similar ${a.brand} listings in your store`;
  else if (brandPrices.length >= 4) out.medianPrice = median(brandPrices), out.priceBasis = `${brandPrices.length} ${a.brand} listings in your store`;
  const dup = scored.find((x) => x.refHit);
  if (dup) out.duplicate = { id: dup.l.id, title: dup.l.title, price: dup.l.price };
  return out;
}

function summary(dirs) { const { listings, files } = load(dirs); return { listings: listings.length, files }; }

module.exports = { lookup, summary, parseCsv };
