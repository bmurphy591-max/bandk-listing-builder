/**
 * Edit existing listings — step 1: enhance photos, review, then update.
 * Uses eBay's Trading API (GetMyeBaySelling / GetItem / ReviseFixedPriceItem) for listings made in Seller Hub or by CSV.
 * Listings created through the Inventory API (this app's Publish button) cannot be revised this way; eBay refuses them.
 * Originals are always kept on disk, and every change can be put back with Restore.
 */
const fs = require('fs');
const path = require('path');

const unesc = (s) => String(s ?? '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tag = (x, name) => { const m = x.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`)); return m ? unesc(m[1].trim()) : ''; };
const tags = (x, name) => [...x.matchAll(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'g'))].map((m) => unesc(m[1].trim()));
const blocks = (x, name) => [...x.matchAll(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'g'))].map((m) => m[1]);

function install(app, ctx) {
  const { getUserToken, uploadImageToEbay, DATA_DIR, EBAY_BASE, noPublish } = ctx;
  const TRADING_URL = process.env.BANDK_TRADING_URL || (EBAY_BASE.includes('sandbox') ? 'https://api.sandbox.ebay.com/ws/api.dll' : 'https://api.ebay.com/ws/api.dll');
  const EDIT_DIR = path.join(DATA_DIR, 'listing-edits');
  const dirOf = (id) => path.join(EDIT_DIR, id);
  const validId = (id) => /^\d{9,15}$/.test(id);
  const readEdit = (id) => { try { return JSON.parse(fs.readFileSync(path.join(dirOf(id), 'edit.json'), 'utf8')); } catch { return null; } };
  const writeEdit = (e) => { fs.mkdirSync(dirOf(e.itemId), { recursive: true }); fs.writeFileSync(path.join(dirOf(e.itemId), 'edit.json'), JSON.stringify(e, null, 2)); return e; };

  async function trading(call, inner) {
    const token = await getUserToken();
    const body = `<?xml version="1.0" encoding="utf-8"?><${call}Request xmlns="urn:ebay:apis:eBLBaseComponents"><ErrorLanguage>en_US</ErrorLanguage><WarningLevel>High</WarningLevel>${inner}</${call}Request>`;
    const r = await fetch(TRADING_URL, { method: 'POST', headers: { 'Content-Type': 'text/xml', 'X-EBAY-API-SITEID': '0', 'X-EBAY-API-COMPATIBILITY-LEVEL': '1451', 'X-EBAY-API-CALL-NAME': call, 'X-EBAY-API-IAF-TOKEN': token }, body });
    const x = await r.text();
    const ack = tag(x, 'Ack');
    if (!r.ok && !ack) throw new Error(`eBay Trading API HTTP ${r.status}: ${x.slice(0, 200)}`);
    if (ack === 'Failure' || ack === 'PartialFailure') {
      const errs = blocks(x, 'Errors').filter((b) => tag(b, 'SeverityCode') !== 'Warning').map((b) => `${tag(b, 'ErrorCode')}: ${tag(b, 'LongMessage') || tag(b, 'ShortMessage')}`);
      if (ack === 'Failure' || errs.length) throw new Error(errs.join(' | ') || 'eBay returned a failure with no message');
    }
    return x;
  }

  app.get('/api/listings', async (req, res) => {
    try {
      const page = Math.max(1, parseInt(req.query.page, 10) || 1);
      const x = await trading('GetMyeBaySelling', `<ActiveList><Sort>TimeLeft</Sort><Pagination><EntriesPerPage>100</EntriesPerPage><PageNumber>${page}</PageNumber></Pagination></ActiveList>`);
      const active = tag(x, 'ActiveList');
      const items = blocks(tag(active, 'ItemArray') || tag(x, 'ItemArray'), 'Item').map((b) => ({
        itemId: tag(b, 'ItemID'), title: tag(b, 'Title'), price: parseFloat(tag(tag(b, 'SellingStatus') || b, 'CurrentPrice')) || null,
        gallery: tag(b, 'GalleryURL'), quantity: parseInt(tag(b, 'QuantityAvailable') || tag(b, 'Quantity'), 10) || null,
        type: tag(b, 'ListingType'), variations: /<Variations[\s>]/.test(b), sku: tag(b, 'SKU'),
      }));
      const pag = tag(active, 'PaginationResult');
      res.json({ ok: true, page, pages: parseInt(tag(pag, 'TotalNumberOfPages'), 10) || 1, total: parseInt(tag(pag, 'TotalNumberOfEntries'), 10) || items.length, items });
    } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
  });

  app.get('/api/listings/edits', (_req, res) => {
    let ids = []; try { ids = fs.readdirSync(EDIT_DIR).filter(validId); } catch { /* none */ }
    res.json({ ok: true, edits: ids.map(readEdit).filter(Boolean).map(({ itemId, title, status, photoCount, updatedAt, error, excluded, variations }) => ({ itemId, title, status, photoCount, updatedAt, error, excluded: !!excluded, variations: !!variations })) });
  });
  app.get('/api/listings/:id/edit', (req, res) => { const e = validId(req.params.id) && readEdit(req.params.id); res.json(e ? { ok: true, edit: e } : { ok: false }); });

  // Load a listing: read its photos from eBay and keep copies of the originals
  app.post('/api/listings/:id/load', async (req, res) => {
    try {
      const id = req.params.id; if (!validId(id)) throw new Error('Bad item number');
      const x = await trading('GetItem', `<ItemID>${id}</ItemID><DetailLevel>ReturnAll</DetailLevel>`);
      const urls = tags(tag(x, 'PictureDetails'), 'PictureURL');
      if (!urls.length) throw new Error('eBay shows no photos on that listing.');
      const variations = /<Variations[\s>]/.test(x);
      const e0 = readEdit(id);
      if (e0 && e0.status === 'updated') return res.json({ ok: true, edit: e0 }); // keep the saved originals safe
      if (e0 && e0.origUrls && JSON.stringify(e0.origUrls) === JSON.stringify(urls) && e0.photoCount === urls.length && e0.status !== 'updated') return res.json({ ok: true, edit: e0 });
      fs.rmSync(dirOf(id), { recursive: true, force: true }); fs.mkdirSync(dirOf(id), { recursive: true });
      for (let i = 0; i < urls.length; i++) {
        const r = await fetch(urls[i]); if (!r.ok) throw new Error(`Could not download photo ${i + 1} (HTTP ${r.status}).`);
        fs.writeFileSync(path.join(dirOf(id), `orig-${i}.jpg`), Buffer.from(await r.arrayBuffer()));
      }
      const e = writeEdit({ itemId: id, title: tag(x, 'Title'), listingType: tag(x, 'ListingType'), sku: tag(x, 'SKU'), variations, origUrls: urls, photoCount: urls.length, status: 'loaded', loadedAt: new Date().toISOString(), updatedAt: new Date().toISOString(), enhanced: [] });
      res.json({ ok: true, edit: e });
    } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
  });

  app.get('/api/listings/:id/photo/:n', (req, res) => {
    const id = req.params.id, n = parseInt(req.params.n, 10), e = validId(id) && readEdit(id);
    if (!e || !(n >= 0 && n < e.photoCount)) return res.status(404).end();
    const f = path.join(dirOf(id), req.query.which === 'enh' ? `enh-${n}.jpg` : `orig-${n}.jpg`);
    if (!fs.existsSync(f)) return res.status(404).end();
    res.setHeader('Content-Type', 'image/jpeg'); res.setHeader('Cache-Control', 'no-store'); fs.createReadStream(f).pipe(res);
  });
  app.post('/api/listings/:id/photo/:n/enhanced', require('express').raw({ type: '*/*', limit: '30mb' }), (req, res) => {
    try {
      const id = req.params.id, n = parseInt(req.params.n, 10), e = validId(id) && readEdit(id);
      if (!e || !(n >= 0 && n < e.photoCount)) return res.status(404).json({ ok: false, error: 'Not found' });
      const b = req.body; if (!Buffer.isBuffer(b) || b.length < 1000 || b[0] !== 0xff || b[1] !== 0xd8) throw new Error('Expected a JPEG image');
      fs.writeFileSync(path.join(dirOf(id), `enh-${n}.jpg`), b);
      e.enhanced = [...new Set([...(e.enhanced || []), n])].sort((a, c) => a - c);
      try { e.adjust = JSON.parse(req.get('X-Adjust') || 'null') || e.adjust; } catch { /* keep */ }
      e.status = e.enhanced.length === e.photoCount ? 'ready' : 'loaded'; e.approved = false; e.updatedAt = new Date().toISOString(); writeEdit(e);
      res.json({ ok: true, status: e.status, saved: e.enhanced.length, of: e.photoCount });
    } catch (err) { res.status(400).json({ ok: false, error: err.message }); }
  });
  app.post('/api/listings/:id/approve', (req, res) => {
    const e = validId(req.params.id) && readEdit(req.params.id);
    if (!e) return res.status(404).json({ ok: false, error: 'Not found' });
    if (req.body?.approved && e.status !== 'ready' && e.status !== 'update_error') return res.status(400).json({ ok: false, error: 'Save the enhanced photos first.' });
    e.approved = !!req.body?.approved; writeEdit(e); res.json({ ok: true, approved: e.approved });
  });
  app.post('/api/listings/:id/exclude', (req, res) => {
    const e = validId(req.params.id) && readEdit(req.params.id);
    if (!e) return res.status(404).json({ ok: false, error: 'Not found' });
    e.excluded = !!req.body?.excluded; if (e.excluded) e.approved = false; writeEdit(e); res.json({ ok: true, excluded: e.excluded });
  });
  app.delete('/api/listings/:id/edit', (req, res) => { if (validId(req.params.id)) fs.rmSync(dirOf(req.params.id), { recursive: true, force: true }); res.json({ ok: true }); });

  async function pushPhotos(e, fileOf, verify = true) { // upload local JPEGs to eBay, replace the listing's picture set, then read the listing back to verify
    const urls = [];
    for (let i = 0; i < e.photoCount; i++) urls.push(await uploadImageToEbay(fs.readFileSync(path.join(dirOf(e.itemId), fileOf(i))), `listing-${e.itemId}-${i}.jpg`, 'image/jpeg'));
    await trading('ReviseFixedPriceItem', `<Item><ItemID>${e.itemId}</ItemID><PictureDetails>${urls.map((u) => `<PictureURL>${esc(u)}</PictureURL>`).join('')}</PictureDetails></Item>`);
    if (!verify) return { urls, nowUrls: urls }; // bulk runs skip the read-back to save eBay calls; eBay's success reply is still required
    const x = await trading('GetItem', `<ItemID>${e.itemId}</ItemID><DetailLevel>ReturnAll</DetailLevel>`);
    const now = tags(tag(x, 'PictureDetails'), 'PictureURL');
    if (now.length !== urls.length) throw new Error(`eBay accepted the change but now shows ${now.length} photos instead of ${urls.length}. Check the listing on eBay.`);
    return { urls, nowUrls: now };
  }
  const guard = (e) => {
    if (!e) throw new Error('Not found');
    if (noPublish) throw new Error('Updating eBay is switched off in this test mode.');
    if (e.variations) throw new Error('This listing has variations. Photo updates for variation listings are not supported yet.');
    if (!/FixedPrice|StoresFixedPrice/i.test(e.listingType || 'FixedPriceItem')) throw new Error('Only fixed-price listings can be updated here.');
  };
  const explain = (m) => /inventory api|21919|can not be revised|cannot be revised/i.test(m) ? m + ' (This listing was probably created through the app\'s Publish button. eBay only lets those be edited through the Inventory API, which is not built yet.)' : m;

  app.post('/api/listings/:id/apply', async (req, res) => {
    const e = validId(req.params.id) && readEdit(req.params.id);
    try {
      guard(e);
      if (e.excluded) throw new Error('This listing is excluded from the update.');
      if (req.body?.approve && (e.status === 'ready' || e.status === 'update_error')) { e.approved = true; }
      if (!e.approved) throw new Error('Approve the enhanced photos first.');
      if (e.status !== 'ready' && e.status !== 'update_error') throw new Error('Nothing ready to update.');
      const r = await pushPhotos(e, (i) => `enh-${i}.jpg`, req.body?.verify !== false);
      Object.assign(e, { status: 'updated', approved: false, appliedAt: new Date().toISOString(), updatedAt: new Date().toISOString(), newUrls: r.nowUrls, error: null }); writeEdit(e);
      res.json({ ok: true, edit: e });
    } catch (err) {
      if (e) { e.error = explain(err.message); if (e.status === 'ready') e.status = 'update_error'; writeEdit(e); }
      res.status(400).json({ ok: false, error: explain(err.message) });
    }
  });
  app.post('/api/listings/:id/restore', async (req, res) => {
    const e = validId(req.params.id) && readEdit(req.params.id);
    try {
      guard(e);
      if (e.status !== 'updated') throw new Error('This listing has not been updated by the app.');
      const r = await pushPhotos(e, (i) => `orig-${i}.jpg`, req.body?.verify !== false);
      Object.assign(e, { status: 'restored', approved: false, restoredAt: new Date().toISOString(), updatedAt: new Date().toISOString(), newUrls: r.nowUrls, error: null }); writeEdit(e);
      res.json({ ok: true, edit: e });
    } catch (err) { res.status(400).json({ ok: false, error: explain(err.message) }); }
  });
}

module.exports = { install };
