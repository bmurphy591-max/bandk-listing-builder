#!/bin/bash
# B and K Listing Builder - launcher (lives inside the .app).
# Double-click the app: it starts the program quietly in the background and opens it in your browser.
# Written for the macOS default bash (3.2), so no fancy features.

HERE="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$(cd "$HERE/../Resources/app" && pwd)"
DATA_DIR="${BANDK_DATA_DIR:-$HOME/BandKListingData}"
KEYS="$DATA_DIR/API-KEYS.txt"
LOG="$DATA_DIR/app.log"
PIDFILE="$DATA_DIR/app.pid"
PORT="${BANDK_PORT:-3456}"
URL="http://localhost:$PORT/batch.html"
TITLE="B and K Listing Builder"
mkdir -p "$DATA_DIR"
export PATH="/usr/local/bin:/opt/homebrew/bin:/opt/homebrew/opt/node/bin:$HOME/.volta/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
for d in "$HOME"/.nvm/versions/node/*/bin; do [ -d "$d" ] && PATH="$d:$PATH"; done
export PATH

# ---------- little dialog helpers (plain Mac dialog boxes) ----------
say() { # say "message"
  osascript -e 'on run argv' -e 'display dialog (item 1 of argv) with title "'"$TITLE"'" buttons {"OK"} default button "OK" with icon note' -e 'end run' "$1" >/dev/null 2>&1
}
choose3() { # choose3 "message" "Button1" "Button2" "Button3"  -> prints the button clicked, or nothing if cancelled
  osascript -e 'on run argv' -e 'try' -e 'set r to display dialog (item 1 of argv) with title "'"$TITLE"'" buttons {item 2 of argv, item 3 of argv, item 4 of argv} default button (item 2 of argv) with icon note' -e 'return button returned of r' -e 'on error' -e 'return ""' -e 'end try' -e 'end run' "$@" 2>/dev/null
}
choose2() { # choose2 "message" "Button1" "Button2"  -> prints the button clicked, or nothing if cancelled
  osascript -e 'on run argv' -e 'try' -e 'set r to display dialog (item 1 of argv) with title "'"$TITLE"'" buttons {item 2 of argv, item 3 of argv} default button (item 2 of argv) with icon note' -e 'return button returned of r' -e 'on error' -e 'return ""' -e 'end try' -e 'end run' "$@" 2>/dev/null
}
ask_key() { # ask_key "message" -> prints what was typed or pasted; prints __CANCEL__ if cancelled
  osascript -e 'on run argv' -e 'try' -e 'set r to display dialog (item 1 of argv) with title "'"$TITLE"'" default answer "" buttons {"Cancel", "Save"} default button "Save" with icon note' -e 'return text returned of r' -e 'on error' -e 'return "__CANCEL__"' -e 'end try' -e 'end run' "$1" 2>/dev/null
}

# ---------- keys file (NAME=value lines) ----------
load_keys() {
  [ -f "$KEYS" ] || return 0
  local line k v
  while IFS= read -r line || [ -n "$line" ]; do
    line="${line%$'\r'}"
    case "$line" in ''|'#'*) continue ;; esac
    k="${line%%=*}"; v="${line#*=}"
    k="$(printf '%s' "$k" | tr -d ' \t')"
    case "$k" in # only these names are accepted from the file
      ANTHROPIC_API_KEY|ANTHROPIC_MODEL|EBAY_ENV|EBAY_CLIENT_ID|EBAY_CLIENT_SECRET|EBAY_REFRESH_TOKEN|EBAY_MERCHANT_LOCATION_KEY) ;;
      *) continue ;;
    esac
    v="$(printf '%s' "$v" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e "s/^[\"']//" -e "s/[\"']\$//")"
    [ -n "$v" ] && export "$k=$v"
  done < "$KEYS"
}
has_key_line() { [ -f "$KEYS" ] && grep -Eq "^[[:space:]]*$1[[:space:]]*=[[:space:]]*[^[:space:]]" "$KEYS"; }
set_key() { # set_key NAME VALUE  (replaces the line if it exists)
  local tmp="$KEYS.tmp"
  [ -f "$KEYS" ] || write_template
  grep -Ev "^[[:space:]]*$1[[:space:]]*=" "$KEYS" > "$tmp" 2>/dev/null
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  mv "$tmp" "$KEYS"; chmod 600 "$KEYS"
}
write_template() {
  cat > "$KEYS" <<'EOF'
# B and K Listing Builder - keys file.
# One setting per line, written NAME=value  (no quotes, no spaces around the = sign).
# Lines starting with # are ignored. Save the file after editing, then open the app again.
ANTHROPIC_API_KEY=
EBAY_ENV=PRODUCTION
EBAY_CLIENT_ID=
EBAY_CLIENT_SECRET=
EBAY_REFRESH_TOKEN=
EOF
  chmod 600 "$KEYS"
}
adopt_keys_file() { # a keys file that arrived by AirDrop/Messages/email lands in Downloads or Desktop; pick it up once
  has_key_line EBAY_CLIENT_ID && return 0
  local f newest=""
  for f in "$HOME"/Downloads/API-KEYS*.txt "$HOME"/Desktop/API-KEYS*.txt; do
    [ -f "$f" ] || continue
    [ "$f" = "$KEYS" ] && continue
    if [ -z "$newest" ] || [ "$f" -nt "$newest" ]; then newest="$f"; fi
  done
  if [ -z "$newest" ]; then # macOS may hide Downloads from this app, so ask her to pick the file herself
    [ -f "$KEYS.asked" ] && return 0
    local pick
    pick="$(osascript -e 'try' -e 'set f to choose file with prompt "Choose the file API-KEYS.txt that Brian sent you (look in Downloads)." of type {"public.plain-text","txt"}' -e 'return POSIX path of f' -e 'on error' -e 'return ""' -e 'end try' 2>/dev/null)"
    [ -n "$pick" ] && [ -f "$pick" ] || { touch "$KEYS.asked"; return 0; }
    newest="$pick"
  fi
  grep -Eq '^[[:space:]]*EBAY_CLIENT_ID[[:space:]]*=[[:space:]]*[^[:space:]]' "$newest" || return 0
  [ -f "$KEYS" ] && cp "$KEYS" "$KEYS.bak"
  mv "$newest" "$KEYS" && chmod 600 "$KEYS"
}

# ---------- Anthropic key: ask once with a normal dialog, check it, save it ----------
check_anthropic() { # prints the HTTP code, 000 if there is no internet
  curl -s -o /dev/null -w '%{http_code}' --max-time 12 https://api.anthropic.com/v1/models \
    -H "x-api-key: $1" -H "anthropic-version: 2023-06-01" 2>/dev/null
}
get_anthropic_key() { # returns 0 when a good key is saved and exported
  local msg tries=0 k code
  msg=$'Paste your Anthropic API key below, then click Save.\n\nTo paste: click inside the white box, then press Command + V on the keyboard.\n\nYou only need to do this once.'
  while [ $tries -lt 3 ]; do
    tries=$((tries + 1))
    k="$(ask_key "$msg")"
    [ "$k" = "__CANCEL__" ] && return 1
    k="$(printf '%s' "$k" | tr -d '[:space:]"'"'")"
    case "$k" in
      sk-ant-*) ;;
      *) msg=$'That does not look like an Anthropic key. It should start with  sk-ant-\n\nPaste it again below (click in the box, then Command + V).'; continue ;;
    esac
    code="$(check_anthropic "$k")"
    if [ "$code" = "401" ] || [ "$code" = "403" ]; then
      msg=$'Anthropic did not accept that key. Check that you copied all of it, then paste it again below.'
      continue
    fi
    set_key ANTHROPIC_API_KEY "$k"
    export ANTHROPIC_API_KEY="$k"
    return 0
  done
  say "That key still did not work. Ask Brian for a new key, then open the app again."
  return 1
}

# ---------- is the program already running? ----------
running() { curl -sf --max-time 2 "http://localhost:$PORT/api/config" >/dev/null 2>&1; }
stop_server() {
  local pid pids p
  pid="$(cat "$PIDFILE" 2>/dev/null)"
  pids="$pid $(lsof -ti "tcp:$PORT" -sTCP:LISTEN 2>/dev/null | tr '\n' ' ')"
  for p in $pids; do
    [ -n "$p" ] || continue
    ps -p "$p" -o command= 2>/dev/null | grep -q 'server.js' && kill "$p" 2>/dev/null
  done
  sleep 1
  rm -f "$PIDFILE"
}

# ---------- Node.js must be installed ----------
need_node() {
  if ! command -v node >/dev/null 2>&1; then
    local b; b="$(choose2 $'Node.js is not installed on this Mac yet. The listing builder needs it (it is a free one-time install).\n\nClick "Open nodejs.org", download the LTS installer, open it and click Continue until it finishes. Then open this app again.' 'Open nodejs.org' 'Close')"
    [ "$b" = "Open nodejs.org" ] && open "https://nodejs.org/en/download"
    exit 1
  fi
  if ! node -e 'process.exit(parseInt(process.versions.node,10)>=18?0:1)' 2>/dev/null; then
    local b; b="$(choose2 $'The Node.js on this Mac is too old (the listing builder needs version 18 or newer).\n\nClick "Open nodejs.org", download the LTS installer and run it, then open this app again.' 'Open nodejs.org' 'Close')"
    [ "$b" = "Open nodejs.org" ] && open "https://nodejs.org/en/download"
    exit 1
  fi
}

start_server() {
  need_node
  [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 5000000 ] && : > "$LOG"
  export DATA_DIR PORT
  export BANDK_LOG="$LOG"
  export EBAY_TOKEN_FILE="$DATA_DIR/.ebay-token.json"
  export EBAY_SETTINGS_FILE="$DATA_DIR/ebay-settings.json"
  [ -f "$EBAY_SETTINGS_FILE" ] || cp "$APP_DIR/ebay-settings.json" "$EBAY_SETTINGS_FILE" 2>/dev/null
  cd "$APP_DIR" || exit 1
  { echo; echo "=== started $(date) ==="; } >> "$LOG"
  nohup node "$APP_DIR/server.js" >> "$LOG" 2>&1 &
  echo $! > "$PIDFILE"
  disown 2>/dev/null
  local i=0
  while [ $i -lt 40 ]; do running && return 0; sleep 0.5; i=$((i + 1)); done
  say "The listing builder did not start. Something else may be using port $PORT. Please send Brian the file  app.log  from the BandKListingData folder in your home folder."
  return 1
}

# ---------- main ----------
adopt_keys_file
[ -f "$KEYS" ] || write_template
load_keys

if running; then
  B="$(choose3 $'The listing builder is already running.' 'Open' 'Change API Key' 'Stop')"
  case "$B" in
    Open) open "$URL" ;;
    Stop) stop_server; say "The listing builder has been stopped." ;;
    "Change API Key")
      if get_anthropic_key; then stop_server; start_server && open "$URL"; fi ;;
  esac
  exit 0
fi

if [ -z "$ANTHROPIC_API_KEY" ]; then
  get_anthropic_key || exit 0
fi
start_server && open "$URL"
exit 0
