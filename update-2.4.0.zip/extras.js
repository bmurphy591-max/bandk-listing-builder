/**
 * Extras: cost tracking, your own sales history (for pricing), iPad/LAN access with a PIN, and self-update.
 * Kept in one file so server.js only needs a few small hooks.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const { AsyncLocalStorage } = require('async_hooks');
const reference = require('./reference');

const als = new AsyncLocalStorage(); // remembers which draft an AI call belongs to
const APP_DIR = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), 'BandKListingData');
const file = (n) => path.join(DATA_DIR, n);
const readJson = (p, d) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return d; } };
const writeJson = (p, o) => { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, JSON.stringify(o, null, 2), { mode: 0o600 }); };
const APP_VERSION = (readJson(path.join(APP_DIR, 'package.json'), {}).version) || '0.0.0';
const isLocal = (req) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
const words = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9' ]+/g, ' ').split(/\s+/).filter((w) => w.length > 1);

/* ------------------------------------------------------------------ */
/* 1. Cost tracking                                                    */
/* ------------------------------------------------------------------ */
// Prices are US dollars per million tokens. Source: Anthropic pricing page, checked 2026-10-20. Edit pricing.json in the data folder if they change.
const PRICE_DEFAULTS = {
  note: 'US$ per million tokens; web search per 1,000 searches. Checked 2026-10-20 at platform.claude.com pricing page. Haiku 5.5 has a higher rate above 100k-token prompts that is not modelled here.',
  webSearchPer1000: 10,
  models: {
    'claude-sonnet-5-5': { in: 2, out: 10 }, 'claude-opus-5-5': { in: 4, out: 20 },
    'claude-haiku-5-5': { in: 0.1, out: 0.5 }, 'claude-fable-5-1': { in: 10, out: 50 },
  },
};
const prices = () => { const u = readJson(file('pricing.json'), {}); return { ...PRICE_DEFAULTS, ...u, models: { ...PRICE_DEFAULTS.models, ...(u.models || {}) } }; };
function recordUsage(model, usage) {
  try {
    if (!usage) return;
    const rec = { t: new Date().toISOString(), draft: (als.getStore() || {}).draft || null, model, in: usage.input_tokens || 0, out: usage.output_tokens || 0, search: usage.server_tool_use?.web_search_requests || 0 };
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.appendFileSync(file('usage.jsonl'), JSON.stringify(rec) + '\n');
  } catch { /* cost tracking must never break a listing */ }
}
function costOf(r, P) {
  const m = P.models[r.model];
  if (!m) return null; // unknown model: tokens counted, cost not known
  return (r.in * m.in + r.out * m.out) / 1e6 + (r.search * P.webSearchPer1000) / 1000;
}
function usageSummary(labelOf) {
  const P = prices(); let lines = [];
  try { lines = fs.readFileSync(file('usage.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)); } catch { /* none yet */ }
  const total = { calls: 0, cost: 0, unpriced: 0 }, byMonth = {}, byDraft = {};
  for (const r of lines) {
    const c = costOf(r, P); total.calls++;
    if (c == null) total.unpriced++; else total.cost += c;
    const mo = r.t.slice(0, 7); (byMonth[mo] ||= { calls: 0, cost: 0, tokensIn: 0, tokensOut: 0, searches: 0 });
    byMonth[mo].calls++; byMonth[mo].cost += c || 0; byMonth[mo].tokensIn += r.in; byMonth[mo].tokensOut += r.out; byMonth[mo].searches += r.search;
    if (r.draft) { (byDraft[r.draft] ||= { cost: 0, calls: 0, last: r.t }); byDraft[r.draft].cost += c || 0; byDraft[r.draft].calls++; byDraft[r.draft].last = r.t; }
  }
  const drafts = Object.entries(byDraft).map(([id, v]) => ({ id, label: labelOf ? labelOf(id) : id, ...v })).sort((a, b) => b.last.localeCompare(a.last)).slice(0, 40);
  const perWatch = Object.values(byDraft).filter((v) => v.cost > 0);
  return { total, months: Object.entries(byMonth).sort((a, b) => b[0].localeCompare(a[0])).map(([month, v]) => ({ month, ...v })), drafts, avgPerWatch: perWatch.length ? perWatch.reduce((s, v) => s + v.cost, 0) / perWatch.length : null, prices: P };
}
const draftCost = (id) => usageSummary().drafts.find((d) => d.id === id)?.cost ?? 0;

/* ------------------------------------------------------------------ */
/* 2. Your own sales history                                           */
/* ------------------------------------------------------------------ */
const SOLD_DIR = () => file('sold-history');
let soldCache = { key: '', sales: [], files: [] };
const money = (v) => { const n = parseFloat(String(v || '').replace(/[^0-9.\-]/g, '')); return isFinite(n) ? n : null; };
function parseSoldCsv(text) { // returns {sales:[{title,price,date}], cols} or throws
  const rows = reference.parseCsv(text);
  let hi = -1, h = [];
  for (let i = 0; i < Math.min(rows.length, 40); i++) {
    const cells = rows[i].map((x) => x.trim().toLowerCase());
    if (cells.some((c) => /^(item title|title|item name)$/.test(c)) && cells.some((c) => /^(sold for|sale price|item price|gross transaction amount|total price|price)$/.test(c))) { hi = i; h = cells; break; }
  }
  if (hi < 0) throw new Error('This does not look like an eBay sold-orders or transaction report (needs an "Item Title" column and a "Sold For" or price column).');
  const find = (re) => h.findIndex((c) => re.test(c));
  const iT = find(/^(item title|title|item name)$/), iP = find(/^(sold for|sale price|item price|gross transaction amount|total price|price)$/),
    iD = find(/^(sale date|transaction creation date|order creation date|paid on date|date)$/), iType = find(/^type$/), iQ = find(/^quantity$/);
  const sales = [];
  for (const r of rows.slice(hi + 1)) {
    const title = (r[iT] || '').trim(), price = money(r[iP]);
    if (!title || !(price > 0)) continue;
    if (iType >= 0 && r[iType] && !/^(order|sale)$/i.test(r[iType].trim())) continue;
    const q = iQ >= 0 ? parseInt(r[iQ], 10) : 1;
    sales.push({ title, price: q > 1 ? price / q : price, date: iD >= 0 ? (r[iD] || '').trim() : '' });
  }
  return { sales, cols: { title: rows[hi][iT], price: rows[hi][iP], date: iD >= 0 ? rows[hi][iD] : null } };
}
function loadSold() {
  let files = []; try { files = fs.readdirSync(SOLD_DIR()).filter((f) => /\.csv$/i.test(f)); } catch { /* none */ }
  const key = files.map((f) => { try { const s = fs.statSync(path.join(SOLD_DIR(), f)); return f + s.size + s.mtimeMs; } catch { return f; } }).join('|');
  if (key === soldCache.key) return soldCache;
  const seen = new Set(), sales = [];
  for (const f of files) {
    try { for (const s of parseSoldCsv(fs.readFileSync(path.join(SOLD_DIR(), f), 'utf8')).sales) { const k = s.title + '|' + s.price + '|' + s.date; if (seen.has(k)) continue; seen.add(k); sales.push({ ...s, t: norm(s.title), w: new Set(words(s.title)) }); } } catch { /* skip bad file */ }
  }
  soldCache = { key, sales, files }; return soldCache;
}
/** Your past sales of this watch. a = analysis {brand, model, modelNumber}. Only returns confident matches. */
function soldLookup(a, specs) {
  const { sales } = loadSold(); const brand = norm(a?.brand);
  if (!sales.length || !brand) return { n: 0, items: [] };
  const ref = norm(a.modelNumber || specs?.['Reference Number']?.value), model = words(a.model || specs?.Model?.value).filter((w) => w.length > 2), bw = words(a.brand);
  const hits = [];
  for (const s of sales) {
    if (!(s.t.startsWith(brand) || (bw.length && bw.every((w) => s.w.has(w))))) continue;
    const refHit = ref.length >= 3 && s.t.includes(ref), mh = model.filter((w) => s.w.has(w)).length;
    if (refHit) hits.push({ ...s, strong: true });
    else if (model.length && mh >= Math.min(2, model.length)) hits.push({ ...s, strong: false });
  }
  const ts = (d) => Date.parse(d) || 0;
  hits.sort((x, y) => (y.strong - x.strong) || (ts(y.date) - ts(x.date)));
  return { n: hits.length, items: hits.slice(0, 12).map(({ title, price, date, strong }) => ({ title, price, date, strong })) };
}

/* ------------------------------------------------------------------ */
/* 3. iPad / Wi-Fi access with a PIN                                   */
/* ------------------------------------------------------------------ */
const netCfg = () => readJson(file('network.json'), { lan: false, pin: '', secret: '' });
const lanEnabled = () => { const c = netCfg(); return !!(c.lan && c.pin); };
const tokenFor = (c) => crypto.createHmac('sha256', c.secret).update('bk|' + c.pin).digest('hex');
const cookieOf = (req, name) => { const m = (req.headers.cookie || '').split(/;\s*/).find((x) => x.startsWith(name + '=')); return m ? decodeURIComponent(m.slice(name.length + 1)) : ''; };
const tries = new Map();
function lanUrls(port) {
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => `http://${i.address}:${port}/batch.html`);
  return [`http://${os.hostname().replace(/\.local$/, '')}.local:${port}/batch.html`, ...ips];
}

/* ------------------------------------------------------------------ */
/* 4. Self-update                                                      */
/* ------------------------------------------------------------------ */
const PROTECTED = new Set(['reference', 'ebay-settings.json', 'export-settings.json', '.env', 'update-source.json', '.old-update']);
const updateRepo = () => readJson(file('update.json'), {}).repo || process.env.BANDK_UPDATE_REPO || readJson(path.join(APP_DIR, 'update-source.json'), {}).repo || '';
const updateBase = () => process.env.BANDK_UPDATE_BASE || `https://raw.githubusercontent.com/${updateRepo()}/main`;
const cmpVer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
async function fetchManifest() {
  if (!updateRepo() && !process.env.BANDK_UPDATE_BASE) throw new Error('No update source set yet. Enter the GitHub repo (name/repo) below.');
  const r = await fetch(`${updateBase()}/latest.json?t=${Date.now()}`, { headers: { 'Cache-Control': 'no-cache' } });
  if (!r.ok) throw new Error(`Could not read the update list (HTTP ${r.status}). Check the repo name, that the repo is public, and that latest.json was uploaded.`);
  const m = await r.json();
  if (!m.version || !m.file) throw new Error('The update list is missing version or file.');
  if (!/^[\w.\-]+$/.test(m.file)) throw new Error('Bad update file name.');
  return m;
}
const run = (cmd, args, opts = {}) => new Promise((res, rej) => execFile(cmd, args, { maxBuffer: 20e6, ...opts }, (e, so, se) => (e ? rej(new Error((se || e.message).toString().slice(0, 300))) : res(so))));
async function selfTest(dir) { // start the new code on a spare port with a throwaway data folder, make sure it answers
  const port = 39000 + Math.floor(Math.random() * 900), tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-selftest-'));
  const child = spawn(process.execPath, [path.join(dir, 'server.js')], { cwd: dir, env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', DATA_DIR: tmp, NODE_PATH: path.join(APP_DIR, 'node_modules'), BANDK_SELFTEST: '1' }, stdio: 'ignore' });
  let ok = false;
  for (let i = 0; i < 40 && !ok; i++) { await new Promise((r) => setTimeout(r, 400)); try { ok = (await fetch(`http://127.0.0.1:${port}/api/config`)).ok; } catch { /* not up yet */ } }
  child.kill(); fs.rmSync(tmp, { recursive: true, force: true });
  if (!ok) throw new Error('The new version did not start in a test run, so it was NOT installed. Your current version is unchanged.');
}
function relaunch() {
  const logFd = process.env.BANDK_LOG ? fs.openSync(process.env.BANDK_LOG, 'a') : 'ignore';
  const child = spawn(process.execPath, process.argv.slice(1), { cwd: APP_DIR, detached: true, stdio: ['ignore', logFd, logFd], env: process.env });
  try { fs.writeFileSync(file('app.pid'), String(child.pid) + '\n'); } catch { /* ok */ }
  child.unref();
  setTimeout(() => process.exit(0), 400);
}
async function installUpdate() {
  const m = await fetchManifest();
  if (cmpVer(m.version, APP_VERSION) <= 0) throw new Error('You already have the newest version.');
  const stage = path.join(DATA_DIR, 'update-staging'); fs.rmSync(stage, { recursive: true, force: true }); fs.mkdirSync(stage, { recursive: true });
  const r = await fetch(`${updateBase()}/${m.file}`); if (!r.ok) throw new Error(`Download failed (HTTP ${r.status}).`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (m.sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== String(m.sha256).toLowerCase()) throw new Error('The downloaded update did not match its checksum, so it was NOT installed.');
  const zip = path.join(stage, 'update.zip'); fs.writeFileSync(zip, buf);
  const ex = path.join(stage, 'x'); fs.mkdirSync(ex);
  await run('unzip', ['-q', '-o', zip, '-d', ex]);
  let root = ex; if (!fs.existsSync(path.join(root, 'server.js'))) { const d = fs.readdirSync(ex).filter((n) => fs.statSync(path.join(ex, n)).isDirectory()); if (d.length === 1 && fs.existsSync(path.join(ex, d[0], 'server.js'))) root = path.join(ex, d[0]); }
  for (const must of ['server.js', 'package.json', 'public']) if (!fs.existsSync(path.join(root, must))) throw new Error('The update file is incomplete (missing ' + must + ').');
  if (readJson(path.join(root, 'package.json'), {}).version !== m.version) throw new Error('The update file version does not match its list entry.');
  try { await run(process.execPath, ['--check', path.join(root, 'server.js')]); } catch { throw new Error('The update file has a code error, so it was NOT installed. Your current version is unchanged.'); }
  await selfTest(root);
  // swap in: move the old copies aside (inside the app folder), copy the new ones in; roll back if anything fails
  const old = path.join(APP_DIR, '.old-update'); fs.rmSync(old, { recursive: true, force: true }); fs.mkdirSync(old);
  const moved = [], added = [];
  try {
    for (const n of fs.readdirSync(root)) {
      if (PROTECTED.has(n) || n === 'launcher.sh') continue;
      const dst = path.join(APP_DIR, n);
      if (fs.existsSync(dst)) { fs.renameSync(dst, path.join(old, n)); moved.push(n); }
      fs.cpSync(path.join(root, n), dst, { recursive: true }); added.push(n);
    }
    const lau = path.join(root, 'launcher.sh'), lauDst = path.join(APP_DIR, '..', '..', 'MacOS', 'BandKListingBuilder');
    if (fs.existsSync(lau) && fs.existsSync(path.dirname(lauDst))) { fs.copyFileSync(lau, lauDst + '.new'); fs.chmodSync(lauDst + '.new', 0o755); fs.renameSync(lauDst + '.new', lauDst); }
  } catch (e) {
    for (const n of added) fs.rmSync(path.join(APP_DIR, n), { recursive: true, force: true });
    for (const n of moved) { try { fs.renameSync(path.join(old, n), path.join(APP_DIR, n)); } catch { /* best effort */ } }
    throw new Error('Could not write the update into the app folder (' + e.message + '). Your old version was put back.');
  }
  fs.rmSync(stage, { recursive: true, force: true });
  return m.version;
}

/* ------------------------------------------------------------------ */
/* Install into the Express app                                        */
/* ------------------------------------------------------------------ */
function install(app, hooks = {}) {
  const express = require('express');
  // PIN gate for anything that is not this Mac
  app.use((req, res, next) => {
    if (isLocal(req)) return next();
    const c = netCfg();
    if (!c.lan || !c.pin) return res.status(403).send('Network access is turned off on this Mac.');
    if (req.path === '/pin' && req.method === 'POST') return next();
    if (req.path === '/pin.html' || req.path === '/style.css') return next();
    if (c.secret && cookieOf(req, 'bk_auth') === tokenFor(c)) return next();
    if (req.path.startsWith('/api')) return res.status(401).json({ ok: false, error: 'PIN required' });
    return res.redirect('/pin.html');
  });
  app.use(express.json({ limit: '25mb' }));
  app.post('/pin', (req, res) => {
    const c = netCfg(), ip = req.socket.remoteAddress, t = tries.get(ip) || { n: 0, until: 0 };
    if (Date.now() < t.until) return res.status(429).json({ ok: false, error: 'Too many tries. Wait a minute.' });
    if (isLocal(req) || (c.pin && String(req.body?.pin || '') === c.pin)) {
      tries.delete(ip);
      res.setHeader('Set-Cookie', `bk_auth=${tokenFor(c)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${60 * 60 * 24 * 90}`);
      return res.json({ ok: true });
    }
    t.n++; if (t.n >= 5) { t.until = Date.now() + 60000; t.n = 0; } tries.set(ip, t);
    res.status(401).json({ ok: false, error: 'Wrong PIN' });
  });
  // remember which draft an AI call belongs to (for per-watch cost)
  app.use('/api/drafts/:id', (req, _res, next) => als.run({ draft: req.params.id }, next));
  const localOnly = (req, res, next) => (isLocal(req) ? next() : res.status(403).json({ ok: false, error: 'Do this on the Mac itself.' }));

  app.get('/api/usage', (_req, res) => res.json({ ok: true, ...usageSummary(hooks.draftLabel) }));
  app.get('/api/version', (_req, res) => res.json({ ok: true, version: APP_VERSION }));

  app.get('/api/sold-history', (_req, res) => {
    const { sales, files } = loadSold(); const dates = sales.map((s) => s.date).filter(Boolean);
    res.json({ ok: true, files, sales: sales.length, folder: SOLD_DIR(), example: sales.slice(0, 3).map(({ title, price, date }) => ({ title, price, date })), dates: dates.length ? [dates[dates.length - 1], dates[0]] : null });
  });
  app.post('/api/sold-history', (req, res) => {
    try {
      const { name, text } = req.body || {}; if (!text) throw new Error('Empty file.');
      const parsed = parseSoldCsv(String(text)); if (!parsed.sales.length) throw new Error('No sales with a price were found in that file.');
      const safe = (String(name || 'sold.csv').replace(/[^\w.\- ]+/g, '_').replace(/\.csv$/i, '') || 'sold') + '.csv';
      fs.mkdirSync(SOLD_DIR(), { recursive: true }); fs.writeFileSync(path.join(SOLD_DIR(), safe), String(text));
      res.json({ ok: true, file: safe, imported: parsed.sales.length, cols: parsed.cols });
    } catch (e) { res.status(400).json({ ok: false, error: e.message }); }
  });
  app.delete('/api/sold-history/:name', (req, res) => { try { fs.rmSync(path.join(SOLD_DIR(), path.basename(req.params.name)), { force: true }); res.json({ ok: true }); } catch (e) { res.status(400).json({ ok: false, error: e.message }); } });

  app.get('/api/network', (req, res) => { const c = netCfg(); res.json({ ok: true, lan: !!c.lan, pin: isLocal(req) ? c.pin : undefined, listening: process.env.__BK_LISTEN_HOST || '', urls: lanUrls(process.env.PORT || 3456), local: isLocal(req) }); });
  app.post('/api/network', localOnly, (req, res) => {
    const c = netCfg(), lan = !!req.body?.lan; let pin = String(req.body?.pin ?? c.pin ?? '').trim();
    if (lan && !/^\d{4,8}$/.test(pin)) return res.status(400).json({ ok: false, error: 'The PIN must be 4 to 8 digits.' });
    writeJson(file('network.json'), { lan, pin, secret: c.secret || crypto.randomBytes(24).toString('hex') });
    res.json({ ok: true, restart: true });
  });
  app.post('/api/restart', localOnly, (_req, res) => { res.json({ ok: true }); setTimeout(relaunch, 300); });

  app.get('/api/update/check', async (_req, res) => {
    try { const m = await fetchManifest(); res.json({ ok: true, current: APP_VERSION, latest: m.version, newer: cmpVer(m.version, APP_VERSION) > 0, notes: m.notes || '', repo: updateRepo() }); }
    catch (e) { res.json({ ok: false, current: APP_VERSION, repo: updateRepo(), error: e.message }); }
  });
  app.post('/api/update/source', localOnly, (req, res) => {
    const repo = String(req.body?.repo || '').trim().replace(/^https?:\/\/github\.com\//, '').replace(/\/+$/, '');
    if (!/^[\w.\-]+\/[\w.\-]+$/.test(repo)) return res.status(400).json({ ok: false, error: 'Enter it as  yourname/repo-name' });
    writeJson(file('update.json'), { repo }); res.json({ ok: true, repo });
  });
  app.post('/api/update/install', localOnly, async (_req, res) => {
    try { const v = await installUpdate(); res.json({ ok: true, version: v }); setTimeout(relaunch, 600); }
    catch (e) { res.status(400).json({ ok: false, error: e.message }); }
  });
}

module.exports = { install, als, recordUsage, draftCost, soldLookup, lanEnabled, lanUrls, APP_VERSION, DATA_DIR };
