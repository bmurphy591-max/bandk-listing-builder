/* Shared photo pipeline (same code as the draft editor). */
const DEF_ADJ={auto:true,b:40,c:0,s:0,sh:100,wb:true,wt:40,crop:true,ds:true,sq:false,cut:false},PE={};
/* ---------- AI background removal (IS-Net via onnxruntime-web, all local) ---------- */
const ORT_BASE='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.22.0/dist/',MASKS=new WeakMap(),MASK_SCALED=new WeakMap();let ortSession=null;
async function bgEngine(say){
  if(ortSession)return ortSession;
  say('Loading the cut-out engine…');
  if(!window.ort)await new Promise((res,rej)=>{const s=document.createElement('script');s.src=ORT_BASE+'ort.wasm.min.js';s.onload=res;s.onerror=()=>rej(new Error('Could not load the cut-out engine (internet needed the first time).'));document.head.appendChild(s)});
  ort.env.wasm.wasmPaths=ORT_BASE;
  let st=await(await fetch('/api/bgmodel')).json();
  if(!st.ready){st=await(await fetch('/api/bgmodel/download',{method:'POST'})).json();
    while(!st.ready){if(st.error)throw new Error(st.error);say(`Downloading the cut-out model, one time only… ${Math.round((st.bytes||0)/1e6)} of ${st.total?Math.round(st.total/1e6):'~175'} MB`);await new Promise(r=>setTimeout(r,1000));st=await(await fetch('/api/bgmodel')).json()}}
  say('Loading the cut-out model…');
  const buf=await(await fetch('/models/isnet-general-use.onnx')).arrayBuffer();
  ortSession=await ort.InferenceSession.create(buf,{executionProviders:['wasm']});return ortSession;
}
async function runMask(img){
  const S=1024,cv=document.createElement('canvas');cv.width=cv.height=S;const cx=cv.getContext('2d',{willReadFrequently:true});cx.drawImage(img,0,0,S,S);
  const d=cx.getImageData(0,0,S,S).data,n=S*S,f=new Float32Array(3*n);let mx=1;for(let i=0;i<d.length;i+=4)for(let c=0;c<3;c++)if(d[i+c]>mx)mx=d[i+c];
  for(let i=0;i<n;i++){f[i]=d[i*4]/mx-.5;f[n+i]=d[i*4+1]/mx-.5;f[2*n+i]=d[i*4+2]/mx-.5}
  const out=await ortSession.run({[ortSession.inputNames[0]]:new ort.Tensor('float32',f,[1,3,S,S])});
  const o=out[ortSession.outputNames[0]].data;let lo=1e9,hi=-1e9;for(let i=0;i<n;i++){if(o[i]<lo)lo=o[i];if(o[i]>hi)hi=o[i]}
  const m=new Float32Array(n),r=hi-lo||1;for(let i=0;i<n;i++)m[i]=(o[i]-lo)/r;return m;
}
function scaledMask(img,w,h){
  let c=MASK_SCALED.get(img);if(!c){c=new Map();MASK_SCALED.set(img,c)}const k=w+'x'+h;if(c.has(k))return c.get(k);
  const m=MASKS.get(img),S=1024,mc=document.createElement('canvas');mc.width=mc.height=S;const mx=mc.getContext('2d'),id=mx.createImageData(S,S);
  for(let i=0;i<S*S;i++){const v=Math.round(m[i]*255);id.data[i*4]=v;id.data[i*4+1]=v;id.data[i*4+2]=v;id.data[i*4+3]=255}mx.putImageData(id,0,0);
  const sc=document.createElement('canvas');sc.width=w;sc.height=h;const sx=sc.getContext('2d',{willReadFrequently:true});sx.imageSmoothingQuality='high';sx.drawImage(mc,0,0,w,h);
  const d=sx.getImageData(0,0,w,h).data,out=new Float32Array(w*h);for(let i=0;i<w*h;i++)out[i]=d[i*4]/255;c.set(k,out);return out;
}
/** The AI cut-out sometimes lets a dim strap fade out. Anything clearly darker than the background that sits right next to the watch is part of the watch: put it back. */
function rescueMask(px,m,w,h){
  const n=w*h,hist=new Uint32Array(256);let cnt=0;
  for(let i=0,p=0;i<n;i++,p+=4)if(m[i]<.03){hist[(px[p]*299+px[p+1]*587+px[p+2]*114)/1000|0]++;cnt++}
  if(cnt<.01*n)return m;
  let a=0,bgL=255;for(let v=0;v<256;v++){a+=hist[v];if(a>=cnt*.5){bgL=v;break}}
  if(bgL<150)return m;
  const g=8,gw=Math.ceil(w/g),gh=Math.ceil(h/g),lo=new Uint8Array(gw*gh),near=new Uint8Array(gw*gh),r=Math.max(2,Math.ceil(.03*Math.max(w,h)/g));
  for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(m[y*w+x]>.1)lo[(y/g|0)*gw+(x/g|0)]=1;
  for(let y=0;y<gh;y++)for(let x=0;x<gw;x++){let f=0;for(let dy=-r;dy<=r&&!f;dy++){const yy=y+dy;if(yy<0||yy>=gh)continue;for(let dx=-r;dx<=r;dx++){const xx=x+dx;if(xx>=0&&xx<gw&&lo[yy*gw+xx]){f=1;break}}}near[y*gw+x]=f}
  const o=new Float32Array(m),hiL=.7*bgL,span=.1*bgL,D=new Float32Array(n);
  for(let y=0;y<h;y++){const row=(y/g|0)*gw;for(let x=0;x<w;x++){const i=y*w+x;if(m[i]>=.9||!near[row+(x/g|0)])continue;
    const p=i*4,L=(px[p]*299+px[p+1]*587+px[p+2]*114)/1000;D[i]=Math.min(1,Math.max(0,(hiL-L)/span))}}
  /* smooth it so cork speckle and tiny flecks do not matter: only a solid dark area counts */
  const R=Math.max(3,Math.round(.005*Math.max(w,h))),T=new Float32Array(n),B=new Float32Array(n);
  for(let y=0;y<h;y++){let acc=0;for(let x=-R;x<=R;x++)acc+=D[y*w+Math.min(w-1,Math.max(0,x))];for(let x=0;x<w;x++){T[y*w+x]=acc/(2*R+1);acc+=D[y*w+Math.min(w-1,x+R+1)]-D[y*w+Math.max(0,x-R)]}}
  for(let x=0;x<w;x++){let acc=0;for(let y=-R;y<=R;y++)acc+=T[Math.min(h-1,Math.max(0,y))*w+x];for(let y=0;y<h;y++){B[y*w+x]=acc/(2*R+1);acc+=T[Math.min(h-1,y+R+1)*w+x]-T[Math.max(0,y-R)*w+x]}}
  for(let i=0;i<n;i++){if(D[i]>0||B[i]>.3){const v=Math.min(1,Math.max(0,(B[i]-.35)/.35))*.97;if(v>o[i]&&m[i]<.9)o[i]=v}}
  return o;
}
/** Makes the plain BACKGROUND white: evens out shadows and removes yellow/orange colour casts in them. The watch itself is not touched, and a faint grey shadow right beside it is kept so it still looks like a real photo, not a cut-out. */
function flattenShadows(px,w,h,amt){
  const sc=Math.min(1,220/Math.max(w,h)),sw=Math.max(8,Math.round(w*sc)),sh=Math.max(8,Math.round(h*sc));
  const full=document.createElement('canvas');full.width=w;full.height=h;full.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(px),w,h),0,0);
  const sm=document.createElement('canvas');sm.width=sw;sm.height=sh;const sx=sm.getContext('2d',{willReadFrequently:true});sx.drawImage(full,0,0,sw,sh);
  const d=sx.getImageData(0,0,sw,sh).data,N=sw*sh,lum=new Float32Array(N);
  for(let i=0;i<N;i++)lum[i]=.299*d[i*4]+.587*d[i*4+1]+.114*d[i*4+2];
  const sorted=Float32Array.from(lum).sort(),p90=sorted[Math.floor(N*.9)]||255;
  if(p90<170)return; /* not a light background: leave the photo alone */
  const dil=(a,r)=>{const o=new Float32Array(N);for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){let m=0;for(let dy=-r;dy<=r&&!m;dy++){const yy=y+dy;if(yy<0||yy>=sh)continue;for(let dx=-r;dx<=r;dx++){const xx=x+dx;if(xx>=0&&xx<sw&&a[yy*sw+xx]){m=1;break}}}o[y*sw+x]=m}return o};
  const box=(a,r)=>{const t=new Float32Array(N),o=new Float32Array(N);
    for(let y=0;y<sh;y++){let acc=0;for(let x=-r;x<=r;x++)acc+=a[y*sw+Math.min(sw-1,Math.max(0,x))];for(let x=0;x<sw;x++){t[y*sw+x]=acc/(2*r+1);acc+=a[y*sw+Math.min(sw-1,x+r+1)]-a[y*sw+Math.max(0,x-r)]}}
    for(let x=0;x<sw;x++){let acc=0;for(let y=-r;y<=r;y++)acc+=t[Math.min(sh-1,Math.max(0,y))*sw+x];for(let y=0;y<sh;y++){o[y*sw+x]=acc/(2*r+1);acc+=t[Math.min(sh-1,y+r+1)*sw+x]-t[Math.max(0,y-r)*sw+x]}}return o};
  /* the watch: dark things and anything with strong edges (measured on a slightly smoothed copy so paper texture does not count) */
  const ls=box(lum,1);const M=new Float32Array(N);
  for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){const i=y*sw+x,gx=ls[y*sw+Math.min(sw-1,x+1)]-ls[y*sw+Math.max(0,x-1)],gy=ls[Math.min(sh-1,y+1)*sw+x]-ls[Math.max(0,y-1)*sw+x];
    /* an edge only counts as "the watch" if something dark or colourful is right there; the sharp edge of a cast shadow (grey on white) is background */
    let mn=255,sat=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const yy=Math.min(sh-1,Math.max(0,y+dy)),xx=Math.min(sw-1,Math.max(0,x+dx)),j=yy*sw+xx;if(lum[j]<mn)mn=lum[j];const s2=Math.max(d[j*4],d[j*4+1],d[j*4+2])-Math.min(d[j*4],d[j*4+1],d[j*4+2]);if(s2>sat)sat=s2}
    M[i]=(lum[i]<.6*p90||(Math.hypot(gx,gy)>26&&(mn<125||sat>70)))?1:0}
  const core=dil(M,2);                                      /* the watch and its edge: never touched */
  const bgw=box(core,2);for(let i=0;i<N;i++)bgw[i]=1-Math.min(1,bgw[i]*1.0); /* 1 = plain background, 0 = watch */
  const near=Math.max(3,Math.round(Math.max(sw,sh)*.022));
  const prot=box(dil(M,near),2);                            /* 1 right beside the watch: that is where the natural contact shadow lives */
  /* smooth map of how bright the plain background is at each point (watch area filled in from around it) */
  const wgt=new Float32Array(N),num=new Float32Array(N);for(let i=0;i<N;i++){wgt[i]=core[i]?0:1;num[i]=wgt[i]*lum[i]}
  const R=Math.max(6,Math.round(Math.max(sw,sh)*.06));let nb=num,wb=wgt;for(let pass=0;pass<3;pass++){nb=box(nb,R);wb=box(wb,R)}
  const G=new Float32Array(N); /* lightening gain; far from the watch it takes the background all the way to white, beside it only part way */
  for(let i=0;i<N;i++){const L=wb[i]>.02?nb[i]/wb[i]:255,g=Math.min(1.9,Math.max(1,255/Math.max(60,L)));G[i]=1+(g-1)*amt*(1-.5*prot[i])*bgw[i]}
  const Gs=box(G,2),Bs=box(bgw,1);
  const tw=(x0,x1,x)=>{const t=Math.min(1,Math.max(0,(x-x0)/(x1-x0)));return t*t*(3-2*t)};
  for(let y=0;y<h;y++){const fy=Math.min(sh-1.001,Math.max(0,y/h*sh-.5)),y0=fy|0,ty=fy-y0;
    for(let x=0;x<w;x++){const fx=Math.min(sw-1.001,Math.max(0,x/w*sw-.5)),x0=fx|0,tx=fx-x0,a=y0*sw+x0,o=(y*w+x)*4;
      const bl=(m)=>(m[a]*(1-tx)+m[a+1]*tx)*(1-ty)+(m[a+sw]*(1-tx)+m[a+sw+1]*tx)*ty,gg=bl(Gs),bw=bl(Bs);
      if(bw<=.02)continue;
      let r=px[o],g=px[o+1],b=px[o+2];
      const l=.299*r+.587*g+.114*b,desat=.9*bw*amt;           /* take the yellow / orange out of the background */
      r+=(l-r)*desat;g+=(l-g)*desat;b+=(l-b)*desat;
      r*=gg;g*=gg;b*=gg;
      const wl=.299*r+.587*g+.114*b,k=tw(222,248,wl)*bw*amt*(1-.6*bl(prot)); /* almost-white becomes clean white */
      px[o]=Math.min(255,r+(255-r)*k);px[o+1]=Math.min(255,g+(255-g)*k);px[o+2]=Math.min(255,b+(255-b)*k)}}
}
function enhanceCanvas(img,adj,maxW){
  const sc=Math.min(1,maxW/img.naturalWidth),w=Math.max(1,Math.round(img.naturalWidth*sc)),hh=Math.max(1,Math.round(img.naturalHeight*sc));
  const cv=document.createElement('canvas');cv.width=w;cv.height=hh;const ctx=cv.getContext('2d',{willReadFrequently:true});
  ctx.drawImage(img,0,0,w,hh);const id=ctx.getImageData(0,0,w,hh),px=id.data,n=w*hh;
  let lo=0,hi=255;
  if(adj.auto){const hist=new Uint32Array(256);for(let i=0;i<px.length;i+=4)hist[(px[i]*299+px[i+1]*587+px[i+2]*114)/1000|0]++;
    let a=0;while(lo<255&&(a+=hist[lo])<n*.01)lo++;a=0;hi=255;while(hi>0&&(a+=hist[hi])<n*.01)hi--;
    lo=Math.min(lo,50);hi=Math.max(hi,205);}
  const k=1+adj.c/100,bAdd=adj.b*1.28,sat=1+adj.s/100,stretch=255/(hi-lo),mix=adj.auto?.7:0;
  for(let i=0;i<px.length;i+=4){
    let r=px[i],g=px[i+1],b=px[i+2];
    if(mix){r+=((r-lo)*stretch-r)*mix;g+=((g-lo)*stretch-g)*mix;b+=((b-lo)*stretch-b)*mix}
    if(sat!==1){const l=.299*r+.587*g+.114*b;r=l+(r-l)*sat;g=l+(g-l)*sat;b=l+(b-l)*sat}
    px[i]=(r-128)*k+128+bAdd;px[i+1]=(g-128)*k+128+bAdd;px[i+2]=(b-128)*k+128+bAdd;
  }
  if(adj.ds!==false&&!(adj.wb&&MASKS.has(img)))flattenShadows(px,w,hh,adj.ds===undefined||adj.ds===true?1:+adj.ds);
  if(adj.sh>0){ // unsharp mask against a 3x3 box blur
    const src=new Uint8ClampedArray(px),tmp=new Uint8ClampedArray(px.length),amt=adj.sh/100*1.5;
    for(let y=0;y<hh;y++)for(let x=0;x<w;x++){const o=(y*w+x)*4,xl=(x>0?o-4:o),xr=(x<w-1?o+4:o);for(let c=0;c<3;c++)tmp[o+c]=(src[xl+c]+src[o+c]+src[xr+c])/3}
    for(let y=0;y<hh;y++){const yu=y>0?y-1:y,yd=y<hh-1?y+1:y;for(let x=0;x<w;x++){const o=(y*w+x)*4,u=(yu*w+x)*4,d=(yd*w+x)*4;
      for(let c=0;c<3;c++){const bl=(tmp[u+c]+tmp[o+c]+tmp[d+c])/3;px[o+c]=src[o+c]+(src[o+c]-bl)*amt}}}
  }
  if(adj.wb&&MASKS.has(img)&&!adj.cut){ /* natural look: keep the real background and its shadows, but lighten them and take the colour cast out; the watch is not touched */
    const m=rescueMask(px,scaledMask(img,w,hh),w,hh),S=Math.min(1,Math.max(0,(adj.wt==null?40:adj.wt)/40)),hist=new Uint32Array(256);let cnt=0;
    for(let i=0,p=0;i<n;i++,p+=4)if(m[i]<.03){hist[(px[p]*299+px[p+1]*587+px[p+2]*114)/1000|0]++;cnt++}
    let acc=0,bgL=235;if(cnt>.01*n)for(let v=0;v<256;v++){acc+=hist[v];if(acc>=cnt*.5){bgL=Math.max(v,120);break}}
    const gain=Math.min(1.3,250/bgL),k=1-.66*S,ds=.65*S;
    for(let i=0,p=0;i<n;i++,p+=4){let a=(m[i]-.15)/.6;a=a<0?0:a>1?1:a;a=a*a*(3-2*a);if(a>=1)continue;
      let r=Math.min(255,px[p]*gain),g=Math.min(255,px[p+1]*gain),b=Math.min(255,px[p+2]*gain);
      const l=.299*r+.587*g+.114*b;r+=(l-r)*ds;g+=(l-g)*ds;b+=(l-b)*ds;
      r=255-(255-r)*k;g=255-(255-g)*k;b=255-(255-b)*k;
      px[p]=px[p]*a+r*(1-a);px[p+1]=px[p+1]*a+g*(1-a);px[p+2]=px[p+2]*a+b*(1-a)}}
  else if(adj.wb&&MASKS.has(img)){const m=rescueMask(px,scaledMask(img,w,hh),w,hh),c0=(adj.wt||0)/100,den=Math.max(.2,.92-c0);
    for(let i=0,p=0;i<n;i++,p+=4){let a=(m[i]-c0)/den;a=a<0?0:a>1?1:a;a=a*a*(3-2*a);if(a<1){const b=1-a;px[p]=px[p]*a+255*b;px[p+1]=px[p+1]*a+255*b;px[p+2]=px[p+2]*a+255*b}}}
  ctx.putImageData(id,0,0);return cv;
}

/* ---------- crop: auto (tight, square-ish, like the store's other listings) + by hand ---------- */
/** Finds the watch against a plain background. Returns {x,y,w,h} (0..1), or {skip:'tight'|'plain'|'none'} when it should be left alone. */
function findWatchBox(img){
  const W=img.naturalWidth,H=img.naturalHeight,s=Math.min(1,240/Math.max(W,H)),w=Math.max(8,Math.round(W*s)),h=Math.max(8,Math.round(H*s));
  const cv=document.createElement('canvas');cv.width=w;cv.height=h;const cx=cv.getContext('2d',{willReadFrequently:true});cx.drawImage(img,0,0,w,h);
  const d=cx.getImageData(0,0,w,h).data,N=w*h,lum=new Float32Array(N);
  for(let i=0;i<N;i++)lum[i]=.299*d[i*4]+.587*d[i*4+1]+.114*d[i*4+2];
  const ls=new Float32Array(N);for(let y=0;y<h;y++)for(let x=0;x<w;x++){let a=0,c=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const yy=y+dy,xx=x+dx;if(yy>=0&&yy<h&&xx>=0&&xx<w){a+=lum[yy*w+xx];c++}}ls[y*w+x]=a/c}
  /* the watch = very dark parts (bezel, strap, dial) and sharp edges; a soft shadow or a gradient is neither */
  const seed=new Uint8Array(N);
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x,gx=ls[i+1]-ls[i-1],gy=ls[i+w]-ls[i-w];seed[i]=(lum[i]<70||(Math.hypot(gx,gy)>30&&lum[i]<175))?1:0}
  const r=3,dil=new Uint8Array(N);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(seed[y*w+x])for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const yy=y+dy,xx=x+dx;if(yy>=0&&yy<h&&xx>=0&&xx<w)dil[yy*w+xx]=1}
  const lab=new Int32Array(N),comps=[];
  for(let i0=0;i0<N;i0++){if(!dil[i0]||lab[i0])continue;const id=comps.length+1,q=[i0];lab[i0]=id;let cnt=0,dk=0,l=w,rr=0,t=h,b=0;
    for(let qi=0;qi<q.length;qi++){const i=q[qi],x=i%w,y=(i/w)|0;if(seed[i]){cnt++;if(lum[i]<70)dk++}if(x<l)l=x;if(x>rr)rr=x;if(y<t)t=y;if(y>b)b=y;
      if(x>0&&dil[i-1]&&!lab[i-1]){lab[i-1]=id;q.push(i-1)}if(x<w-1&&dil[i+1]&&!lab[i+1]){lab[i+1]=id;q.push(i+1)}if(y>0&&dil[i-w]&&!lab[i-w]){lab[i-w]=id;q.push(i-w)}if(y<h-1&&dil[i+w]&&!lab[i+w]){lab[i+w]=id;q.push(i+w)}}
    comps.push({cnt,dk,l,r:rr,t,b})}
  /* a real watch has genuinely dark parts (bezel, strap, digits); the outline of a cast shadow or a wall edge has only edges, so it scores low */
  const sc=c=>c.dk+.12*c.cnt,thin=Math.max(w,h)*.06,good=comps.filter(c=>c.cnt>=15&&c.dk>=6&&Math.min(c.r-c.l,c.b-c.t)>=thin);
  if(!good.length)return null;
  good.sort((p,q)=>sc(q)-sc(p));const m=good[0],padx=(m.r-m.l)*.12,pady=(m.b-m.t)*.12;
  let l=m.l,rr=m.r,t=m.t,b=m.b;
  const comps2=comps.filter(c=>c!==m&&c.cnt>=15&&c.dk>=3&&!(c.dk<6&&c.cnt<.05*m.cnt)),px2=(m.r-m.l)*.45,py2=(m.b-m.t)*.45;  /* pieces of the same watch further away (a long strap, the buckle) */
  for(const c of comps2){if(c.l<=m.r+px2&&c.r>=m.l-px2&&c.t<=m.b+py2&&c.b>=m.t-py2){l=Math.min(l,c.l);rr=Math.max(rr,c.r);t=Math.min(t,c.t);b=Math.max(b,c.b)}}
  for(const c of good.slice(1)){if(sc(c)>=.1*sc(m)&&c.l<=m.r+padx&&c.r>=m.l-padx&&c.t<=m.b+pady&&c.b>=m.t-pady){l=Math.min(l,c.l);rr=Math.max(rr,c.r);t=Math.min(t,c.t);b=Math.max(b,c.b)}}
  return{l:l,r:rr+1,t:t,b:b+1,w:w,h:h};
}
/** Bounding box (0..1) of everything the AI cut-out says is the watch (shadows are not part of it). */
function maskBox(img){
  const m=MASKS.get(img),S=1024;let x0=S,x1=-1,y0=S,y1=-1;const colN=new Uint16Array(S),rowN=new Uint16Array(S);
  for(let y=0;y<S;y++)for(let x=0;x<S;x++)if(m[y*S+x]>.5){colN[x]++;rowN[y]++}
  const T=3;for(let x=0;x<S;x++)if(colN[x]>=T){if(x<x0)x0=x;x1=x}for(let y=0;y<S;y++)if(rowN[y]>=T){if(y<y0)y0=y;y1=y}
  if(x1<0||y1<0)return null;return{x0:x0/S,x1:(x1+1)/S,y0:y0/S,y1:(y1+1)/S};
}
/** Crop window of the photo's own shape (or square) centred on the watch so it fills about 86% of the frame; white padding is added when the watch is too long to fit. */
function maskCrop(img,sq){
  const W=img.naturalWidth,H=img.naturalHeight,b=maskBox(img);if(!b)return{skip:'none'};
  const bw=(b.x1-b.x0)*W,bh=(b.y1-b.y0)*H;if(bw<.04*W||bh<.04*H)return{skip:'none'};
  const A=sq?1:W/H,F=.86;let ww=Math.max(bw/F,bh/F*A),wh=ww/A;
  const cx=(b.x0+b.x1)/2*W,cy=(b.y0+b.y1)/2*H;
  let x=cx-ww/2,y=cy-wh/2;
  if(ww<=W)x=Math.min(Math.max(x,0),W-ww);if(wh<=H)y=Math.min(Math.max(y,0),H-wh);   /* inside the photo: nudge it in rather than pad */
  if(!sq&&ww>=.97*W&&ww<=1.03*W&&wh>=.97*H&&wh<=1.03*H&&Math.abs(cx-W/2)/W<.03&&Math.abs(cy-H/2)/H<.03)return{skip:'tight'};
  return{x:x/W,y:y/H,w:ww/W,h:wh/H,pad:ww>W||wh>H};
}
function autoCropRect(img,sq){
  if(MASKS.has(img))return maskCrop(img,sq);
  const W=img.naturalWidth,H=img.naturalHeight,bx=findWatchBox(img);
  if(!bx)return{skip:'none'};
  const fr=((bx.r-bx.l)*(bx.b-bx.t))/(bx.w*bx.h);
  if(fr<.02||fr>.97)return{skip:'none'};
  let x0=bx.l/bx.w,x1=bx.r/bx.w,y0=bx.t/bx.h,y1=bx.b/bx.h;
  const ocx=(x0+x1)/2*W,ocy=(y0+y1)/2*H;               /* centre of the watch, in pixels */
  const mx=.12*Math.max((x1-x0)*W,(y1-y0)*H);          /* breathing room around the watch */
  const need=Math.max((x1-x0)*W,(y1-y0)*H)+2*mx;       /* side of the square that holds the watch with its margin */
  if(need>Math.min(W,H)*1.02)return{skip:'long'};      /* a long strap or anything that does not fit a square: keep the whole photo so nothing is cut off */
  /* a square CENTRED on the watch; if the watch is near an edge, shrink the square so it stays centred, as long as the whole watch still fits */
  const room=2*Math.min(ocx,W-ocx,ocy,H-ocy);
  let side=Math.min(need,Math.min(W,H));
  const fit=Math.max((x1-x0)*W,(y1-y0)*H)*1.02;
  if(side>room)side=Math.max(room,Math.min(fit,Math.min(W,H)));
  let px=ocx-side/2,py=ocy-side/2;px=Math.min(Math.max(px,0),W-side);py=Math.min(Math.max(py,0),H-side);
  const rect={x:px/W,y:py/H,w:side/W,h:side/H};
  const off=Math.abs(ocx-W/2)/W>.03||Math.abs(ocy-H/2)/H>.03;
  if(rect.w*rect.h>.85&&!off)return{skip:'tight'}; /* already cropped and centred: leave it */
  return rect;
}
function enhanceCropped(img,adj,maxW,rect){
  if(!rect)return enhanceCanvas(img,adj,maxW);
  const full=enhanceCanvas(img,adj,Math.min(img.naturalWidth,Math.round(maxW/Math.min(rect.w,1)))),W=full.width,H=full.height;
  const ow=Math.max(1,Math.round(W*rect.w)),oh=Math.max(1,Math.round(H*rect.h)),out=document.createElement('canvas');out.width=ow;out.height=oh;
  const o=out.getContext('2d');o.fillStyle='#fff';o.fillRect(0,0,ow,oh);
  const sx=Math.round(rect.x*W),sy=Math.round(rect.y*H),cx0=Math.max(0,sx),cy0=Math.max(0,sy),cx1=Math.min(W,sx+ow),cy1=Math.min(H,sy+oh);
  if(cx1>cx0&&cy1>cy0)o.drawImage(full,cx0,cy0,cx1-cx0,cy1-cy0,cx0-sx,cy0-sy,cx1-cx0,cy1-cy0);return out;
}
